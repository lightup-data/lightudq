window.pdocSearch = (function () {
  /** elasticlunr - http://weixsong.github.io * Copyright (C) 2017 Oliver Nightingale * Copyright (C) 2017 Wei Song * MIT Licensed */ !(function () {
    function e(e) {
      if (null === e || "object" != typeof e) return e;
      var t = e.constructor();
      for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
      return t;
    }
    var t = function (e) {
      var n = new t.Index();
      return (
        n.pipeline.add(t.trimmer, t.stopWordFilter, t.stemmer), e && e.call(n, n), n
      );
    };
    (t.version = "0.9.5"),
      (lunr = t),
      (t.utils = {}),
      (t.utils.warn = (function (e) {
        return function (t) {
          e.console && console.warn && console.warn(t);
        };
      })(this)),
      (t.utils.toString = function (e) {
        return void 0 === e || null === e ? "" : e.toString();
      }),
      (t.EventEmitter = function () {
        this.events = {};
      }),
      (t.EventEmitter.prototype.addListener = function () {
        var e = Array.prototype.slice.call(arguments),
          t = e.pop(),
          n = e;
        if ("function" != typeof t)
          throw new TypeError("last argument must be a function");
        n.forEach(function (e) {
          this.hasHandler(e) || (this.events[e] = []), this.events[e].push(t);
        }, this);
      }),
      (t.EventEmitter.prototype.removeListener = function (e, t) {
        if (this.hasHandler(e)) {
          var n = this.events[e].indexOf(t);
          -1 !== n &&
            (this.events[e].splice(n, 1),
            0 == this.events[e].length && delete this.events[e]);
        }
      }),
      (t.EventEmitter.prototype.emit = function (e) {
        if (this.hasHandler(e)) {
          var t = Array.prototype.slice.call(arguments, 1);
          this.events[e].forEach(function (e) {
            e.apply(void 0, t);
          }, this);
        }
      }),
      (t.EventEmitter.prototype.hasHandler = function (e) {
        return e in this.events;
      }),
      (t.tokenizer = function (e) {
        if (!arguments.length || null === e || void 0 === e) return [];
        if (Array.isArray(e)) {
          var n = e.filter(function (e) {
            return null === e || void 0 === e ? !1 : !0;
          });
          n = n.map(function (e) {
            return t.utils.toString(e).toLowerCase();
          });
          var i = [];
          return (
            n.forEach(function (e) {
              var n = e.split(t.tokenizer.seperator);
              i = i.concat(n);
            }, this),
            i
          );
        }
        return e.toString().trim().toLowerCase().split(t.tokenizer.seperator);
      }),
      (t.tokenizer.defaultSeperator = /[\s\-]+/),
      (t.tokenizer.seperator = t.tokenizer.defaultSeperator),
      (t.tokenizer.setSeperator = function (e) {
        null !== e &&
          void 0 !== e &&
          "object" == typeof e &&
          (t.tokenizer.seperator = e);
      }),
      (t.tokenizer.resetSeperator = function () {
        t.tokenizer.seperator = t.tokenizer.defaultSeperator;
      }),
      (t.tokenizer.getSeperator = function () {
        return t.tokenizer.seperator;
      }),
      (t.Pipeline = function () {
        this._queue = [];
      }),
      (t.Pipeline.registeredFunctions = {}),
      (t.Pipeline.registerFunction = function (e, n) {
        n in t.Pipeline.registeredFunctions &&
          t.utils.warn("Overwriting existing registered function: " + n),
          (e.label = n),
          (t.Pipeline.registeredFunctions[n] = e);
      }),
      (t.Pipeline.getRegisteredFunction = function (e) {
        return e in t.Pipeline.registeredFunctions != !0
          ? null
          : t.Pipeline.registeredFunctions[e];
      }),
      (t.Pipeline.warnIfFunctionNotRegistered = function (e) {
        var n = e.label && e.label in this.registeredFunctions;
        n ||
          t.utils.warn(
            "Function is not registered with pipeline. This may cause problems when serialising the index.\n",
            e
          );
      }),
      (t.Pipeline.load = function (e) {
        var n = new t.Pipeline();
        return (
          e.forEach(function (e) {
            var i = t.Pipeline.getRegisteredFunction(e);
            if (!i) throw new Error("Cannot load un-registered function: " + e);
            n.add(i);
          }),
          n
        );
      }),
      (t.Pipeline.prototype.add = function () {
        var e = Array.prototype.slice.call(arguments);
        e.forEach(function (e) {
          t.Pipeline.warnIfFunctionNotRegistered(e), this._queue.push(e);
        }, this);
      }),
      (t.Pipeline.prototype.after = function (e, n) {
        t.Pipeline.warnIfFunctionNotRegistered(n);
        var i = this._queue.indexOf(e);
        if (-1 === i) throw new Error("Cannot find existingFn");
        this._queue.splice(i + 1, 0, n);
      }),
      (t.Pipeline.prototype.before = function (e, n) {
        t.Pipeline.warnIfFunctionNotRegistered(n);
        var i = this._queue.indexOf(e);
        if (-1 === i) throw new Error("Cannot find existingFn");
        this._queue.splice(i, 0, n);
      }),
      (t.Pipeline.prototype.remove = function (e) {
        var t = this._queue.indexOf(e);
        -1 !== t && this._queue.splice(t, 1);
      }),
      (t.Pipeline.prototype.run = function (e) {
        for (var t = [], n = e.length, i = this._queue.length, o = 0; n > o; o++) {
          for (
            var r = e[o], s = 0;
            i > s && ((r = this._queue[s](r, o, e)), void 0 !== r && null !== r);
            s++
          );
          void 0 !== r && null !== r && t.push(r);
        }
        return t;
      }),
      (t.Pipeline.prototype.reset = function () {
        this._queue = [];
      }),
      (t.Pipeline.prototype.get = function () {
        return this._queue;
      }),
      (t.Pipeline.prototype.toJSON = function () {
        return this._queue.map(function (e) {
          return t.Pipeline.warnIfFunctionNotRegistered(e), e.label;
        });
      }),
      (t.Index = function () {
        (this._fields = []),
          (this._ref = "id"),
          (this.pipeline = new t.Pipeline()),
          (this.documentStore = new t.DocumentStore()),
          (this.index = {}),
          (this.eventEmitter = new t.EventEmitter()),
          (this._idfCache = {}),
          this.on(
            "add",
            "remove",
            "update",
            function () {
              this._idfCache = {};
            }.bind(this)
          );
      }),
      (t.Index.prototype.on = function () {
        var e = Array.prototype.slice.call(arguments);
        return this.eventEmitter.addListener.apply(this.eventEmitter, e);
      }),
      (t.Index.prototype.off = function (e, t) {
        return this.eventEmitter.removeListener(e, t);
      }),
      (t.Index.load = function (e) {
        e.version !== t.version &&
          t.utils.warn(
            "version mismatch: current " + t.version + " importing " + e.version
          );
        var n = new this();
        (n._fields = e.fields),
          (n._ref = e.ref),
          (n.documentStore = t.DocumentStore.load(e.documentStore)),
          (n.pipeline = t.Pipeline.load(e.pipeline)),
          (n.index = {});
        for (var i in e.index) n.index[i] = t.InvertedIndex.load(e.index[i]);
        return n;
      }),
      (t.Index.prototype.addField = function (e) {
        return this._fields.push(e), (this.index[e] = new t.InvertedIndex()), this;
      }),
      (t.Index.prototype.setRef = function (e) {
        return (this._ref = e), this;
      }),
      (t.Index.prototype.saveDocument = function (e) {
        return (this.documentStore = new t.DocumentStore(e)), this;
      }),
      (t.Index.prototype.addDoc = function (e, n) {
        if (e) {
          var n = void 0 === n ? !0 : n,
            i = e[this._ref];
          this.documentStore.addDoc(i, e),
            this._fields.forEach(function (n) {
              var o = this.pipeline.run(t.tokenizer(e[n]));
              this.documentStore.addFieldLength(i, n, o.length);
              var r = {};
              o.forEach(function (e) {
                e in r ? (r[e] += 1) : (r[e] = 1);
              }, this);
              for (var s in r) {
                var u = r[s];
                (u = Math.sqrt(u)), this.index[n].addToken(s, { ref: i, tf: u });
              }
            }, this),
            n && this.eventEmitter.emit("add", e, this);
        }
      }),
      (t.Index.prototype.removeDocByRef = function (e) {
        if (
          e &&
          this.documentStore.isDocStored() !== !1 &&
          this.documentStore.hasDoc(e)
        ) {
          var t = this.documentStore.getDoc(e);
          this.removeDoc(t, !1);
        }
      }),
      (t.Index.prototype.removeDoc = function (e, n) {
        if (e) {
          var n = void 0 === n ? !0 : n,
            i = e[this._ref];
          this.documentStore.hasDoc(i) &&
            (this.documentStore.removeDoc(i),
            this._fields.forEach(function (n) {
              var o = this.pipeline.run(t.tokenizer(e[n]));
              o.forEach(function (e) {
                this.index[n].removeToken(e, i);
              }, this);
            }, this),
            n && this.eventEmitter.emit("remove", e, this));
        }
      }),
      (t.Index.prototype.updateDoc = function (e, t) {
        var t = void 0 === t ? !0 : t;
        this.removeDocByRef(e[this._ref], !1),
          this.addDoc(e, !1),
          t && this.eventEmitter.emit("update", e, this);
      }),
      (t.Index.prototype.idf = function (e, t) {
        var n = "@" + t + "/" + e;
        if (Object.prototype.hasOwnProperty.call(this._idfCache, n))
          return this._idfCache[n];
        var i = this.index[t].getDocFreq(e),
          o = 1 + Math.log(this.documentStore.length / (i + 1));
        return (this._idfCache[n] = o), o;
      }),
      (t.Index.prototype.getFields = function () {
        return this._fields.slice();
      }),
      (t.Index.prototype.search = function (e, n) {
        if (!e) return [];
        e = "string" == typeof e ? { any: e } : JSON.parse(JSON.stringify(e));
        var i = null;
        null != n && (i = JSON.stringify(n));
        for (
          var o = new t.Configuration(i, this.getFields()).get(),
            r = {},
            s = Object.keys(e),
            u = 0;
          u < s.length;
          u++
        ) {
          var a = s[u];
          r[a] = this.pipeline.run(t.tokenizer(e[a]));
        }
        var l = {};
        for (var c in o) {
          var d = r[c] || r.any;
          if (d) {
            var f = this.fieldSearch(d, c, o),
              h = o[c].boost;
            for (var p in f) f[p] = f[p] * h;
            for (var p in f) p in l ? (l[p] += f[p]) : (l[p] = f[p]);
          }
        }
        var v,
          g = [];
        for (var p in l)
          (v = { ref: p, score: l[p] }),
            this.documentStore.hasDoc(p) && (v.doc = this.documentStore.getDoc(p)),
            g.push(v);
        return (
          g.sort(function (e, t) {
            return t.score - e.score;
          }),
          g
        );
      }),
      (t.Index.prototype.fieldSearch = function (e, t, n) {
        var i = n[t].bool,
          o = n[t].expand,
          r = n[t].boost,
          s = null,
          u = {};
        return 0 !== r
          ? (e.forEach(function (e) {
              var n = [e];
              1 == o && (n = this.index[t].expandToken(e));
              var r = {};
              n.forEach(function (n) {
                var o = this.index[t].getDocs(n),
                  a = this.idf(n, t);
                if (s && "AND" == i) {
                  var l = {};
                  for (var c in s) c in o && (l[c] = o[c]);
                  o = l;
                }
                n == e && this.fieldSearchStats(u, n, o);
                for (var c in o) {
                  var d = this.index[t].getTermFrequency(n, c),
                    f = this.documentStore.getFieldLength(c, t),
                    h = 1;
                  0 != f && (h = 1 / Math.sqrt(f));
                  var p = 1;
                  n != e && (p = 0.15 * (1 - (n.length - e.length) / n.length));
                  var v = d * a * h * p;
                  c in r ? (r[c] += v) : (r[c] = v);
                }
              }, this),
                (s = this.mergeScores(s, r, i));
            }, this),
            (s = this.coordNorm(s, u, e.length)))
          : void 0;
      }),
      (t.Index.prototype.mergeScores = function (e, t, n) {
        if (!e) return t;
        if ("AND" == n) {
          var i = {};
          for (var o in t) o in e && (i[o] = e[o] + t[o]);
          return i;
        }
        for (var o in t) o in e ? (e[o] += t[o]) : (e[o] = t[o]);
        return e;
      }),
      (t.Index.prototype.fieldSearchStats = function (e, t, n) {
        for (var i in n) i in e ? e[i].push(t) : (e[i] = [t]);
      }),
      (t.Index.prototype.coordNorm = function (e, t, n) {
        for (var i in e)
          if (i in t) {
            var o = t[i].length;
            e[i] = (e[i] * o) / n;
          }
        return e;
      }),
      (t.Index.prototype.toJSON = function () {
        var e = {};
        return (
          this._fields.forEach(function (t) {
            e[t] = this.index[t].toJSON();
          }, this),
          {
            version: t.version,
            fields: this._fields,
            ref: this._ref,
            documentStore: this.documentStore.toJSON(),
            index: e,
            pipeline: this.pipeline.toJSON(),
          }
        );
      }),
      (t.Index.prototype.use = function (e) {
        var t = Array.prototype.slice.call(arguments, 1);
        t.unshift(this), e.apply(this, t);
      }),
      (t.DocumentStore = function (e) {
        (this._save = null === e || void 0 === e ? !0 : e),
          (this.docs = {}),
          (this.docInfo = {}),
          (this.length = 0);
      }),
      (t.DocumentStore.load = function (e) {
        var t = new this();
        return (
          (t.length = e.length),
          (t.docs = e.docs),
          (t.docInfo = e.docInfo),
          (t._save = e.save),
          t
        );
      }),
      (t.DocumentStore.prototype.isDocStored = function () {
        return this._save;
      }),
      (t.DocumentStore.prototype.addDoc = function (t, n) {
        this.hasDoc(t) || this.length++,
          (this.docs[t] = this._save === !0 ? e(n) : null);
      }),
      (t.DocumentStore.prototype.getDoc = function (e) {
        return this.hasDoc(e) === !1 ? null : this.docs[e];
      }),
      (t.DocumentStore.prototype.hasDoc = function (e) {
        return e in this.docs;
      }),
      (t.DocumentStore.prototype.removeDoc = function (e) {
        this.hasDoc(e) && (delete this.docs[e], delete this.docInfo[e], this.length--);
      }),
      (t.DocumentStore.prototype.addFieldLength = function (e, t, n) {
        null !== e &&
          void 0 !== e &&
          0 != this.hasDoc(e) &&
          (this.docInfo[e] || (this.docInfo[e] = {}), (this.docInfo[e][t] = n));
      }),
      (t.DocumentStore.prototype.updateFieldLength = function (e, t, n) {
        null !== e &&
          void 0 !== e &&
          0 != this.hasDoc(e) &&
          this.addFieldLength(e, t, n);
      }),
      (t.DocumentStore.prototype.getFieldLength = function (e, t) {
        return null === e || void 0 === e
          ? 0
          : e in this.docs && t in this.docInfo[e]
          ? this.docInfo[e][t]
          : 0;
      }),
      (t.DocumentStore.prototype.toJSON = function () {
        return {
          docs: this.docs,
          docInfo: this.docInfo,
          length: this.length,
          save: this._save,
        };
      }),
      (t.stemmer = (function () {
        var e = {
            ational: "ate",
            tional: "tion",
            enci: "ence",
            anci: "ance",
            izer: "ize",
            bli: "ble",
            alli: "al",
            entli: "ent",
            eli: "e",
            ousli: "ous",
            ization: "ize",
            ation: "ate",
            ator: "ate",
            alism: "al",
            iveness: "ive",
            fulness: "ful",
            ousness: "ous",
            aliti: "al",
            iviti: "ive",
            biliti: "ble",
            logi: "log",
          },
          t = {
            icate: "ic",
            ative: "",
            alize: "al",
            iciti: "ic",
            ical: "ic",
            ful: "",
            ness: "",
          },
          n = "[^aeiou]",
          i = "[aeiouy]",
          o = n + "[^aeiouy]*",
          r = i + "[aeiou]*",
          s = "^(" + o + ")?" + r + o,
          u = "^(" + o + ")?" + r + o + "(" + r + ")?$",
          a = "^(" + o + ")?" + r + o + r + o,
          l = "^(" + o + ")?" + i,
          c = new RegExp(s),
          d = new RegExp(a),
          f = new RegExp(u),
          h = new RegExp(l),
          p = /^(.+?)(ss|i)es$/,
          v = /^(.+?)([^s])s$/,
          g = /^(.+?)eed$/,
          m = /^(.+?)(ed|ing)$/,
          y = /.$/,
          S = /(at|bl|iz)$/,
          x = new RegExp("([^aeiouylsz])\\1$"),
          w = new RegExp("^" + o + i + "[^aeiouwxy]$"),
          I = /^(.+?[^aeiou])y$/,
          b =
            /^(.+?)(ational|tional|enci|anci|izer|bli|alli|entli|eli|ousli|ization|ation|ator|alism|iveness|fulness|ousness|aliti|iviti|biliti|logi)$/,
          E = /^(.+?)(icate|ative|alize|iciti|ical|ful|ness)$/,
          D =
            /^(.+?)(al|ance|ence|er|ic|able|ible|ant|ement|ment|ent|ou|ism|ate|iti|ous|ive|ize)$/,
          F = /^(.+?)(s|t)(ion)$/,
          _ = /^(.+?)e$/,
          P = /ll$/,
          k = new RegExp("^" + o + i + "[^aeiouwxy]$"),
          z = function (n) {
            var i, o, r, s, u, a, l;
            if (n.length < 3) return n;
            if (
              ((r = n.substr(0, 1)),
              "y" == r && (n = r.toUpperCase() + n.substr(1)),
              (s = p),
              (u = v),
              s.test(n)
                ? (n = n.replace(s, "$1$2"))
                : u.test(n) && (n = n.replace(u, "$1$2")),
              (s = g),
              (u = m),
              s.test(n))
            ) {
              var z = s.exec(n);
              (s = c), s.test(z[1]) && ((s = y), (n = n.replace(s, "")));
            } else if (u.test(n)) {
              var z = u.exec(n);
              (i = z[1]),
                (u = h),
                u.test(i) &&
                  ((n = i),
                  (u = S),
                  (a = x),
                  (l = w),
                  u.test(n)
                    ? (n += "e")
                    : a.test(n)
                    ? ((s = y), (n = n.replace(s, "")))
                    : l.test(n) && (n += "e"));
            }
            if (((s = I), s.test(n))) {
              var z = s.exec(n);
              (i = z[1]), (n = i + "i");
            }
            if (((s = b), s.test(n))) {
              var z = s.exec(n);
              (i = z[1]), (o = z[2]), (s = c), s.test(i) && (n = i + e[o]);
            }
            if (((s = E), s.test(n))) {
              var z = s.exec(n);
              (i = z[1]), (o = z[2]), (s = c), s.test(i) && (n = i + t[o]);
            }
            if (((s = D), (u = F), s.test(n))) {
              var z = s.exec(n);
              (i = z[1]), (s = d), s.test(i) && (n = i);
            } else if (u.test(n)) {
              var z = u.exec(n);
              (i = z[1] + z[2]), (u = d), u.test(i) && (n = i);
            }
            if (((s = _), s.test(n))) {
              var z = s.exec(n);
              (i = z[1]),
                (s = d),
                (u = f),
                (a = k),
                (s.test(i) || (u.test(i) && !a.test(i))) && (n = i);
            }
            return (
              (s = P),
              (u = d),
              s.test(n) && u.test(n) && ((s = y), (n = n.replace(s, ""))),
              "y" == r && (n = r.toLowerCase() + n.substr(1)),
              n
            );
          };
        return z;
      })()),
      t.Pipeline.registerFunction(t.stemmer, "stemmer"),
      (t.stopWordFilter = function (e) {
        return e && t.stopWordFilter.stopWords[e] !== !0 ? e : void 0;
      }),
      (t.clearStopWords = function () {
        t.stopWordFilter.stopWords = {};
      }),
      (t.addStopWords = function (e) {
        null != e &&
          Array.isArray(e) !== !1 &&
          e.forEach(function (e) {
            t.stopWordFilter.stopWords[e] = !0;
          }, this);
      }),
      (t.resetStopWords = function () {
        t.stopWordFilter.stopWords = t.defaultStopWords;
      }),
      (t.defaultStopWords = {
        "": !0,
        a: !0,
        able: !0,
        about: !0,
        across: !0,
        after: !0,
        all: !0,
        almost: !0,
        also: !0,
        am: !0,
        among: !0,
        an: !0,
        and: !0,
        any: !0,
        are: !0,
        as: !0,
        at: !0,
        be: !0,
        because: !0,
        been: !0,
        but: !0,
        by: !0,
        can: !0,
        cannot: !0,
        could: !0,
        dear: !0,
        did: !0,
        do: !0,
        does: !0,
        either: !0,
        else: !0,
        ever: !0,
        every: !0,
        for: !0,
        from: !0,
        get: !0,
        got: !0,
        had: !0,
        has: !0,
        have: !0,
        he: !0,
        her: !0,
        hers: !0,
        him: !0,
        his: !0,
        how: !0,
        however: !0,
        i: !0,
        if: !0,
        in: !0,
        into: !0,
        is: !0,
        it: !0,
        its: !0,
        just: !0,
        least: !0,
        let: !0,
        like: !0,
        likely: !0,
        may: !0,
        me: !0,
        might: !0,
        most: !0,
        must: !0,
        my: !0,
        neither: !0,
        no: !0,
        nor: !0,
        not: !0,
        of: !0,
        off: !0,
        often: !0,
        on: !0,
        only: !0,
        or: !0,
        other: !0,
        our: !0,
        own: !0,
        rather: !0,
        said: !0,
        say: !0,
        says: !0,
        she: !0,
        should: !0,
        since: !0,
        so: !0,
        some: !0,
        than: !0,
        that: !0,
        the: !0,
        their: !0,
        them: !0,
        then: !0,
        there: !0,
        these: !0,
        they: !0,
        this: !0,
        tis: !0,
        to: !0,
        too: !0,
        twas: !0,
        us: !0,
        wants: !0,
        was: !0,
        we: !0,
        were: !0,
        what: !0,
        when: !0,
        where: !0,
        which: !0,
        while: !0,
        who: !0,
        whom: !0,
        why: !0,
        will: !0,
        with: !0,
        would: !0,
        yet: !0,
        you: !0,
        your: !0,
      }),
      (t.stopWordFilter.stopWords = t.defaultStopWords),
      t.Pipeline.registerFunction(t.stopWordFilter, "stopWordFilter"),
      (t.trimmer = function (e) {
        if (null === e || void 0 === e)
          throw new Error("token should not be undefined");
        return e.replace(/^\W+/, "").replace(/\W+$/, "");
      }),
      t.Pipeline.registerFunction(t.trimmer, "trimmer"),
      (t.InvertedIndex = function () {
        this.root = { docs: {}, df: 0 };
      }),
      (t.InvertedIndex.load = function (e) {
        var t = new this();
        return (t.root = e.root), t;
      }),
      (t.InvertedIndex.prototype.addToken = function (e, t, n) {
        for (var n = n || this.root, i = 0; i <= e.length - 1; ) {
          var o = e[i];
          o in n || (n[o] = { docs: {}, df: 0 }), (i += 1), (n = n[o]);
        }
        var r = t.ref;
        n.docs[r]
          ? (n.docs[r] = { tf: t.tf })
          : ((n.docs[r] = { tf: t.tf }), (n.df += 1));
      }),
      (t.InvertedIndex.prototype.hasToken = function (e) {
        if (!e) return !1;
        for (var t = this.root, n = 0; n < e.length; n++) {
          if (!t[e[n]]) return !1;
          t = t[e[n]];
        }
        return !0;
      }),
      (t.InvertedIndex.prototype.getNode = function (e) {
        if (!e) return null;
        for (var t = this.root, n = 0; n < e.length; n++) {
          if (!t[e[n]]) return null;
          t = t[e[n]];
        }
        return t;
      }),
      (t.InvertedIndex.prototype.getDocs = function (e) {
        var t = this.getNode(e);
        return null == t ? {} : t.docs;
      }),
      (t.InvertedIndex.prototype.getTermFrequency = function (e, t) {
        var n = this.getNode(e);
        return null == n ? 0 : t in n.docs ? n.docs[t].tf : 0;
      }),
      (t.InvertedIndex.prototype.getDocFreq = function (e) {
        var t = this.getNode(e);
        return null == t ? 0 : t.df;
      }),
      (t.InvertedIndex.prototype.removeToken = function (e, t) {
        if (e) {
          var n = this.getNode(e);
          null != n && t in n.docs && (delete n.docs[t], (n.df -= 1));
        }
      }),
      (t.InvertedIndex.prototype.expandToken = function (e, t, n) {
        if (null == e || "" == e) return [];
        var t = t || [];
        if (void 0 == n && ((n = this.getNode(e)), null == n)) return t;
        n.df > 0 && t.push(e);
        for (var i in n) "docs" !== i && "df" !== i && this.expandToken(e + i, t, n[i]);
        return t;
      }),
      (t.InvertedIndex.prototype.toJSON = function () {
        return { root: this.root };
      }),
      (t.Configuration = function (e, n) {
        var e = e || "";
        if (void 0 == n || null == n) throw new Error("fields should not be null");
        this.config = {};
        var i;
        try {
          (i = JSON.parse(e)), this.buildUserConfig(i, n);
        } catch (o) {
          t.utils.warn(
            "user configuration parse failed, will use default configuration"
          ),
            this.buildDefaultConfig(n);
        }
      }),
      (t.Configuration.prototype.buildDefaultConfig = function (e) {
        this.reset(),
          e.forEach(function (e) {
            this.config[e] = { boost: 1, bool: "OR", expand: !1 };
          }, this);
      }),
      (t.Configuration.prototype.buildUserConfig = function (e, n) {
        var i = "OR",
          o = !1;
        if (
          (this.reset(),
          "bool" in e && (i = e.bool || i),
          "expand" in e && (o = e.expand || o),
          "fields" in e)
        )
          for (var r in e.fields)
            if (n.indexOf(r) > -1) {
              var s = e.fields[r],
                u = o;
              void 0 != s.expand && (u = s.expand),
                (this.config[r] = {
                  boost: s.boost || 0 === s.boost ? s.boost : 1,
                  bool: s.bool || i,
                  expand: u,
                });
            } else
              t.utils.warn(
                "field name in user configuration not found in index instance fields"
              );
        else this.addAllFields2UserConfig(i, o, n);
      }),
      (t.Configuration.prototype.addAllFields2UserConfig = function (e, t, n) {
        n.forEach(function (n) {
          this.config[n] = { boost: 1, bool: e, expand: t };
        }, this);
      }),
      (t.Configuration.prototype.get = function () {
        return this.config;
      }),
      (t.Configuration.prototype.reset = function () {
        this.config = {};
      }),
      (lunr.SortedSet = function () {
        (this.length = 0), (this.elements = []);
      }),
      (lunr.SortedSet.load = function (e) {
        var t = new this();
        return (t.elements = e), (t.length = e.length), t;
      }),
      (lunr.SortedSet.prototype.add = function () {
        var e, t;
        for (e = 0; e < arguments.length; e++)
          (t = arguments[e]),
            ~this.indexOf(t) || this.elements.splice(this.locationFor(t), 0, t);
        this.length = this.elements.length;
      }),
      (lunr.SortedSet.prototype.toArray = function () {
        return this.elements.slice();
      }),
      (lunr.SortedSet.prototype.map = function (e, t) {
        return this.elements.map(e, t);
      }),
      (lunr.SortedSet.prototype.forEach = function (e, t) {
        return this.elements.forEach(e, t);
      }),
      (lunr.SortedSet.prototype.indexOf = function (e) {
        for (
          var t = 0,
            n = this.elements.length,
            i = n - t,
            o = t + Math.floor(i / 2),
            r = this.elements[o];
          i > 1;

        ) {
          if (r === e) return o;
          e > r && (t = o),
            r > e && (n = o),
            (i = n - t),
            (o = t + Math.floor(i / 2)),
            (r = this.elements[o]);
        }
        return r === e ? o : -1;
      }),
      (lunr.SortedSet.prototype.locationFor = function (e) {
        for (
          var t = 0,
            n = this.elements.length,
            i = n - t,
            o = t + Math.floor(i / 2),
            r = this.elements[o];
          i > 1;

        )
          e > r && (t = o),
            r > e && (n = o),
            (i = n - t),
            (o = t + Math.floor(i / 2)),
            (r = this.elements[o]);
        return r > e ? o : e > r ? o + 1 : void 0;
      }),
      (lunr.SortedSet.prototype.intersect = function (e) {
        for (
          var t = new lunr.SortedSet(),
            n = 0,
            i = 0,
            o = this.length,
            r = e.length,
            s = this.elements,
            u = e.elements;
          ;

        ) {
          if (n > o - 1 || i > r - 1) break;
          s[n] !== u[i]
            ? s[n] < u[i]
              ? n++
              : s[n] > u[i] && i++
            : (t.add(s[n]), n++, i++);
        }
        return t;
      }),
      (lunr.SortedSet.prototype.clone = function () {
        var e = new lunr.SortedSet();
        return (e.elements = this.toArray()), (e.length = e.elements.length), e;
      }),
      (lunr.SortedSet.prototype.union = function (e) {
        var t, n, i;
        this.length >= e.length ? ((t = this), (n = e)) : ((t = e), (n = this)),
          (i = t.clone());
        for (var o = 0, r = n.toArray(); o < r.length; o++) i.add(r[o]);
        return i;
      }),
      (lunr.SortedSet.prototype.toJSON = function () {
        return this.toArray();
      }),
      (function (e, t) {
        "function" == typeof define && define.amd
          ? define(t)
          : "object" == typeof exports
          ? (module.exports = t())
          : (e.elasticlunr = t());
      })(this, function () {
        return t;
      });
  })();
  /** pdoc search index */ const docs = {
    version: "0.9.5",
    fields: [
      "qualname",
      "fullname",
      "annotation",
      "default_value",
      "signature",
      "bases",
      "doc",
    ],
    ref: "fullname",
    documentStore: {
      docs: {
        lightudq: {
          fullname: "lightudq",
          modulename: "lightudq",
          kind: "module",
          doc: '<p>A Python library for unstructured data quality assessment. It provides tools to evaluate the quality of unstructured\ndocuments, including checks for consistency, completeness, accuracy and PII contamination. The library can be used to\nanalyze documents such as PDFs, text files, and markdowns.</p>\n\n<h2 id="installation">Installation</h2>\n\n<div class="pdoc-code codehilite">\n<pre><span></span><code><span class="n">pip</span> <span class="n">install</span> <span class="n">lightudq</span>\n</code></pre>\n</div>\n\n<h2 id="usage">Usage</h2>\n\n<h3 id="quality-check-of-a-document">Quality check of a document</h3>\n\n<div class="pdoc-code codehilite">\n<pre><span></span><code><span class="kn">from</span><span class="w"> </span><span class="nn">lightudq</span><span class="w"> </span><span class="kn">import</span> <span class="n">DocumentQuality</span>\n<span class="n">dq</span> <span class="o">=</span> <span class="n">DocumentQuality</span><span class="p">(</span><span class="s1">&#39;tests/doc_samples/corrupt_description.txt&#39;</span><span class="p">)</span>\n<span class="n">res</span> <span class="o">=</span> <span class="n">dq</span><span class="o">.</span><span class="n">run</span><span class="p">()</span>\n<span class="nb">print</span><span class="p">(</span><span class="n">res</span><span class="o">.</span><span class="n">profile</span><span class="p">)</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="sd">{&#39;title&#39;: &#39;corrupt_description.txt&#39;, &#39;wordCount&#39;: 310, &#39;qnaPairs&#39;: {&#39;qna_pairs&#39;: [{&#39;question&#39;: &#39;What is Fict.AI known for in the tech industry?&#39;,</span>\n<span class="sd">&#39;answer&#39;: &#39;Fict.AI is known as an emerging pioneer in the tech industry, primarily driven by advanced AI solutions, and headquartered in the</span>\n<span class="sd">vibrant city of Austin.&#39;}, {&#39;question&#39;: &#39;Who is responsible for overseeing the financial milestones at Fict.AI?&#39;,</span>\n<span class="sd">&#39;answer&#39;: &#39;The CFO, James Smith, is responsible for overseeing the financial milestones at Fict.AI. He has been with</span>\n<span class="sd"> the company since his appointment in 2015 and has over two decades of experience in finance.&#39;}, {&#39;question&#39;: &#39;What is</span>\n<span class="sd"> the revenue of Fict.AI and how is it utilized?&#39;, &#39;answer&#39;: &#39;The revenue of Fict.AI is $100,000. This impressive revenue</span>\n<span class="sd"> allows them to invest aggressively in research and development and indicates a high return on investment.&#39;},</span>\n<span class="sd"> {&#39;question&#39;: &#39;What advantages does the location of Fict.AI provide?&#39;, &#39;answer&#39;: &quot;Fict.AI&#39;s strategic location in Austin</span>\n<span class="sd">  provides easy access to a plethora of tech firms and talent, creating a conducive environment for collaborations and</span>\n<span class="sd">  partnerships.&quot;}, {&#39;question&#39;: &#39;What plans does Fict.AI have for the future?&#39;, &#39;answer&#39;: &#39;Fict.AI plans to steer the</span>\n<span class="sd">  future of AI technology while providing exceptional solutions and transforming the tech industry standard, supported</span>\n<span class="sd">  by their notable revenue of $120,000.&#39;}]}, &#39;summary&#39;: &quot;Fict.AI, based in Austin, is a burgeoning tech industry leader</span>\n<span class="sd">  with a compact team of 12 employees and impressive revenue of $120,000. Their growth is fueled by advanced AI</span>\n<span class="sd">  solutions and a high return on investment, enabling significant investment in research and development. CFO James</span>\n<span class="sd">  Smith, with over two decades of financial experience, has been instrumental in achieving financial stability since</span>\n<span class="sd">  2015. The company&#39;s strategic Austin location fosters partnerships and access to tech talent. Fict.AI&#39;s innovative</span>\n<span class="sd">  strategies and efficient operations position it as a formidable contender in the AI market, setting industry standards.&quot;,</span>\n<span class="sd">   &#39;fileType&#39;: &#39;.txt&#39;, &#39;fileSize&#39;: 2057}&quot;&quot;&quot;</span>\n\n<span class="nb">print</span><span class="p">(</span><span class="n">res</span><span class="o">.</span><span class="n">inconsistency</span><span class="p">)</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="sd">{&#39;reasoning&#39;: &#39;The document contains two clear internal contradictions: team size (10 vs 12 employees) and revenue</span>\n<span class="sd">figures ($100,000 vs $120,000). All other facts are either consistent with the document or contain additional information</span>\n<span class="sd"> not mentioned in the document.&#39;, &#39;inconsistent_facts&#39;: 2, &#39;metadata&#39;: [{&#39;original&#39;: &#39;Fict.AI is headquartered in Austin,</span>\n<span class="sd">  Texas. There is some inconsistency in the reported team size, with the document mentioning both 10 and 12 employees</span>\n<span class="sd">  at different points.&#39;, &#39;new&#39;: &quot;The document shows an inconsistency in team size, stating both &#39;10 employees&#39; and</span>\n<span class="sd">  &#39;team of only 12&#39;&quot;}, {&#39;original&#39;: &#39;The revenue figures mentioned in the document are inconsistent, with multiple</span>\n<span class="sd">   references to $100,000 throughout the text, but the final paragraph states a revenue of $120,000.&#39;, &#39;new&#39;: &#39;The document</span>\n<span class="sd">   shows inconsistency in revenue figures, mentioning $100,000 multiple times but stating $120,000 in the final paragraph&#39;}]}</span>\n<span class="sd">&quot;&quot;&quot;</span>\n\n<span class="nb">print</span><span class="p">(</span><span class="n">res</span><span class="o">.</span><span class="n">pii</span><span class="p">)</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="sd">{&#39;present&#39;: True, &#39;metadata&#39;: [&#39;Name: James Smith&#39;, &#39;Date of Birth: September 23, 1970&#39;], &#39;count&#39;: 2}</span>\n<span class="sd">&quot;&quot;&quot;</span>\n</code></pre>\n</div>\n\n<h3 id="compare-documents-or-versions-of-same-documents">compare documents or versions of same documents</h3>\n\n<div class="pdoc-code codehilite">\n<pre><span></span><code><span class="kn">from</span><span class="w"> </span><span class="nn">lightudq</span><span class="w"> </span><span class="kn">import</span> <span class="n">DocumentQuality</span>\n<span class="n">reference_dq</span> <span class="o">=</span> <span class="n">DocumentQuality</span><span class="p">(</span><span class="n">file_path</span><span class="o">=</span><span class="s1">&#39;tests/doc_samples/base_description.pdf&#39;</span><span class="p">)</span>\n<span class="n">reference_profile</span> <span class="o">=</span> <span class="n">reference_dq</span><span class="o">.</span><span class="n">get_document_profile</span><span class="p">()</span>\n<span class="n">dq</span> <span class="o">=</span> <span class="n">DocumentQuality</span><span class="p">(</span><span class="n">file_path</span><span class="o">=</span><span class="s1">&#39;tests/doc_samples/corrupt_description.txt&#39;</span><span class="p">)</span>\n<span class="n">res</span> <span class="o">=</span> <span class="n">dq</span><span class="o">.</span><span class="n">compare</span><span class="p">(</span><span class="n">reference_profile</span><span class="o">=</span><span class="n">reference_profile</span><span class="p">)</span>\n<span class="nb">print</span><span class="p">(</span><span class="n">res</span><span class="o">.</span><span class="n">incompleteness</span><span class="p">)</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="sd">{&#39;reasoning&#39;: &#39;The document only mentions revenue figures (with some inconsistency between $100,000 and $120,000) but</span>\n<span class="sd">does not provide any information about net income or profit margins. While it mentions &quot;notable profit numbers,&quot;</span>\n<span class="sd">no specific net income figure is provided. All other questions about headquarters, team size, location benefits, and</span>\n<span class="sd">revenue utilization are clearly answered in the text.&#39;, &#39;questions&#39;: [&quot;What is Fict.AI&#39;s net income for the fiscal year?&quot;]}</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="nb">print</span><span class="p">(</span><span class="n">res</span><span class="o">.</span><span class="n">inaccuracy</span><span class="p">)</span>\n<span class="sd">&quot;&quot;&quot;</span>\n<span class="sd">{&#39;reasoning&#39;: &#39;Two direct contradictions found: 1) The document states both 10 and 12 employees, with the latter figure</span>\n<span class="sd"> contradicting the original fact. 2) The document mentions $100,000 revenue multiple times but concludes with $120,000,</span>\n<span class="sd"> contradicting the earlier statements and the original fact.&#39;, &#39;inconsistent_facts&#39;: 2,</span>\n<span class="sd"> &#39;metadata&#39;: [{&#39;original&#39;: &#39;Fict.AI is headquartered in Austin, Texas and operates with a compact team of 10 employees.&#39;,</span>\n<span class="sd">  &#39;new&#39;: &#39;Even with a team of only 12, the company manages to keep overhead costs low&#39;},</span>\n<span class="sd">  {&#39;original&#39;: &#39;Fict.AI generates a revenue of $100,000 through their advanced AI solutions.&#39;, &#39;new&#39;: &#39;With a noteworthy</span>\n<span class="sd">   revenue of $120,000 under its belt, the company is all set to steer the future of AI technology&#39;}]}</span>\n<span class="sd">&quot;&quot;&quot;</span>\n</code></pre>\n</div>\n',
        },
        "lightudq.document_quality": {
          fullname: "lightudq.document_quality",
          modulename: "lightudq.document_quality",
          kind: "module",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality": {
          fullname: "lightudq.document_quality.DocumentQuality",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality",
          kind: "class",
          doc: "<p>Checks the quality of the document</p>\n",
        },
        "lightudq.document_quality.DocumentQuality.__init__": {
          fullname: "lightudq.document_quality.DocumentQuality.__init__",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.__init__",
          kind: "function",
          doc: "<p>Initialize the DocumentQuality class.\nArgs:\n  file_path (str): The path to the document file to be analyzed.\n  model_name (str): The name of the LLM model to use for analysis, available models: <a href=\"https://ai.pydantic.dev/api/models/base/#pydantic_ai.models.KnownModelName\">https://ai.pydantic.dev/api/models/base/#pydantic_ai.models.KnownModelName</a>\n  by default 'openai:gpt-4o'.</p>\n",
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="n">file_path</span><span class="p">:</span> <span class="nb">str</span>, </span><span class="param"><span class="n">model_name</span><span class="p">:</span> <span class="nb">str</span> <span class="o">=</span> <span class="s1">&#39;openai:gpt-4o&#39;</span></span>)</span>',
        },
        "lightudq.document_quality.DocumentQuality.file_path": {
          fullname: "lightudq.document_quality.DocumentQuality.file_path",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.file_path",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality.document": {
          fullname: "lightudq.document_quality.DocumentQuality.document",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.document",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality.profile": {
          fullname: "lightudq.document_quality.DocumentQuality.profile",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.profile",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality.output": {
          fullname: "lightudq.document_quality.DocumentQuality.output",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.output",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.DocumentQualityCheckResult]",
        },
        "lightudq.document_quality.DocumentQuality.doc_profile": {
          fullname: "lightudq.document_quality.DocumentQuality.doc_profile",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.doc_profile",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality.llm_client": {
          fullname: "lightudq.document_quality.DocumentQuality.llm_client",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.llm_client",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.document_quality.DocumentQuality.run": {
          fullname: "lightudq.document_quality.DocumentQuality.run",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.run",
          kind: "function",
          doc: '<p>Run the document quality checks and return the results.</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>DocumentQualityCheckResult: A pydantic model containing the results of the document quality checks.</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">DocumentQualityCheckResult</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.compare": {
          fullname: "lightudq.document_quality.DocumentQuality.compare",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.compare",
          kind: "function",
          doc: '<p>Compare the document quality against a reference profile.</p>\n\n<h2 id="parameters">Parameters</h2>\n\n<p>reference_profile : DocumentProfile\n    The reference profile to compare against.</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>DocumentQualityCheckResult: A pydantic model containing the results of the document quality checks against the reference profile.</p>\n',
          signature:
            '<span class="signature pdoc-code multiline">(<span class="param">\t<span class="bp">self</span>,</span><span class="param">\t<span class="n">reference_profile</span><span class="p">:</span> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">DocumentProfile</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">DocumentQualityCheckResult</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
          fullname: "lightudq.document_quality.DocumentQuality.get_response_from_llm",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.get_response_from_llm",
          kind: "function",
          doc: '<p>get response from LLM for a given message and output model</p>\n\n<h2 id="parameters">Parameters</h2>\n\n<p>msg : str\n    The message to send to the LLM\noutput_model : Type[BaseModel], optional\n    pydantic model to parse the output, by default None</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>a string or a pydantic model instance</p>\n',
          signature:
            '<span class="signature pdoc-code multiline">(<span class="param">\t<span class="bp">self</span>,</span><span class="param">\t<span class="n">msg</span><span class="p">:</span> <span class="nb">str</span>,</span><span class="param">\t<span class="n">output_model</span><span class="p">:</span> <span class="n">Optional</span><span class="p">[</span><span class="nb">type</span><span class="p">[</span><span class="n">pydantic</span><span class="o">.</span><span class="n">main</span><span class="o">.</span><span class="n">BaseModel</span><span class="p">]]</span> <span class="o">=</span> <span class="kc">None</span></span><span class="return-annotation">) -> <span class="n">Union</span><span class="p">[</span><span class="nb">str</span><span class="p">,</span> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">InconsistentFacts</span><span class="p">,</span> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">QnAPairs</span><span class="p">,</span> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">MissingQuestions</span><span class="p">,</span> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">PIIPresence</span><span class="p">]</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.extract_qna": {
          fullname: "lightudq.document_quality.DocumentQuality.extract_qna",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.extract_qna",
          kind: "function",
          doc: '<p>extract pairs of questions and answers from a document</p>\n\n<h2 id="returns">Returns:</h2>\n\n<p>QnAPairs: a pydantic model containing the list of questions and answers</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">QnAPairs</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
          fullname: "lightudq.document_quality.DocumentQuality.compute_fact_checks",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.compute_fact_checks",
          kind: "function",
          doc: '<p>Checks whether the provided facts are consistent against the document</p>\n\n<h2 id="parameters">Parameters</h2>\n\n<p>facts : list[str]\n    The list of facts to check against the document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>InconsistentFacts: a pydantic model containing the inconsistent facts and metadata if any</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span>, </span><span class="param"><span class="n">facts</span><span class="p">:</span> <span class="nb">list</span><span class="p">[</span><span class="nb">str</span><span class="p">]</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">InconsistentFacts</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
          fullname: "lightudq.document_quality.DocumentQuality.incompleteness_metric",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.incompleteness_metric",
          kind: "function",
          doc: '<p>check for questions not answered in a document</p>\n\n<h2 id="parameters">Parameters</h2>\n\n<p>questions : list[str]\n    The list of questions to check against the document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>MissingQuestions: a pydantic model containing the list of questions not answered in the document</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span>, </span><span class="param"><span class="n">questions</span><span class="p">:</span> <span class="nb">list</span><span class="p">[</span><span class="nb">str</span><span class="p">]</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">MissingQuestions</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.pii_presence_check": {
          fullname: "lightudq.document_quality.DocumentQuality.pii_presence_check",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.pii_presence_check",
          kind: "function",
          doc: '<p>check for presence of PII in a document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>PIIPresence: a pydantic model containing the presence of PII in the document, metadata if any, and count of PII found</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">PIIPresence</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.get_word_count": {
          fullname: "lightudq.document_quality.DocumentQuality.get_word_count",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.get_word_count",
          kind: "function",
          doc: '<p>get the word count of a document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>int: the number of words in the document</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="nb">int</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.get_doc_summary": {
          fullname: "lightudq.document_quality.DocumentQuality.get_doc_summary",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.get_doc_summary",
          kind: "function",
          doc: '<p>get a summary of a document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>str: the summary of the document</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="nb">str</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
          fullname: "lightudq.document_quality.DocumentQuality.get_custom_metric",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.get_custom_metric",
          kind: "function",
          doc: "<p>get a custom metric for a document</p>\n",
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span>, </span><span class="param"><span class="n">prompt</span><span class="p">:</span> <span class="nb">str</span>, </span><span class="param"><span class="n">output_schema</span><span class="p">:</span> <span class="nb">str</span></span><span class="return-annotation">) -> <span class="nb">str</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.document_quality.DocumentQuality.get_document_profile": {
          fullname: "lightudq.document_quality.DocumentQuality.get_document_profile",
          modulename: "lightudq.document_quality",
          qualname: "DocumentQuality.get_document_profile",
          kind: "function",
          doc: '<p>get the profile of a document</p>\n\n<h2 id="returns">Returns</h2>\n\n<p>DocumentProfile: a pydantic model containing profile of the document</p>\n',
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="bp">self</span></span><span class="return-annotation">) -> <span class="n">lightudq</span><span class="o">.</span><span class="n">schemas</span><span class="o">.</span><span class="n">DocumentProfile</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.prompts": {
          fullname: "lightudq.prompts",
          modulename: "lightudq.prompts",
          kind: "module",
          doc: "<p></p>\n",
        },
        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
          fullname: "lightudq.prompts.QNA_EXTRACT_PROMPT",
          modulename: "lightudq.prompts",
          qualname: "QNA_EXTRACT_PROMPT",
          kind: "variable",
          doc: "<p></p>\n",
          default_value:
            "&#x27;You are an advanced text analysis system designed to extract key\\ninformation from documents in the form of question-answer pairs. Your task is to analyze the given document\\nand create up to 5 question-answer pairs based on the information directly addressed in the text.\\n\\nFirst, carefully read the following document:\\n\\n&lt;document&gt;\\n{document}\\n&lt;/document&gt;\\n\\nThen extract key questions and their corresponding answers from the document.  The answer in each question-answer pair\\nshould be self-contained and fully comprehensible without needing to refer back to the question or the original document.\\n\\nAfter completing your analysis, please format your output as a JSON object that adheres to the following\\nschema:\\n\\n&lt;output_schema&gt;\\n{output_schema}\\n&lt;/output_schema&gt;\\n\\n\\nRemember:\\n- The answer in each question-answer pair  should be self-contained and fully comprehensible without needing to refer\\n back to the question or the original document.\\n- Your final output must be strictly in the JSON format specified by the output_schema.\\n- Double-check your JSON structure before finalizing your response.\\n- Do not output any reasoning or justifications\\n&#x27;",
        },
        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
          fullname: "lightudq.prompts.MISSING_QUESTIONS_PROMPT",
          modulename: "lightudq.prompts",
          qualname: "MISSING_QUESTIONS_PROMPT",
          kind: "variable",
          doc: "<p></p>\n",
          default_value:
            "&#x27;Check if the following document answers the following questions.\\n&lt;document&gt;\\n{document}\\n&lt;/document&gt;\\n\\n&lt;questions&gt;\\n{questions}\\n&lt;/questions&gt;\\n\\nOutput just the list of questions (if any) not answered by the document, with the following output schema.\\n&lt;output_schema&gt;\\n{output_schema}\\n&lt;/output_schema&gt;\\n&#x27;",
        },
        "lightudq.prompts.FACT_CHECK_PROMPT": {
          fullname: "lightudq.prompts.FACT_CHECK_PROMPT",
          modulename: "lightudq.prompts",
          qualname: "FACT_CHECK_PROMPT",
          kind: "variable",
          doc: "<p></p>\n",
          default_value:
            "&#x27;You are a precise and thorough fact-checker. Your task is to verify if a given document directly\\ncontradicts a set of provided facts. You must ignore any facts that are not present in the document.\\nHere is the document to analyze:\\n&lt;document&gt;\\n{document}\\n&lt;/document&gt;\\n\\nHere are the facts to check:\\n&lt;facts&gt;\\n{facts}\\n&lt;/facts&gt;\\n\\nHere is the schema for the JSON output you must produce:\\n&lt;output_schema&gt;\\n{output_schema}\\n&lt;/output_schema&gt;\\n\\nPlease follow these steps:\\n\\n1. Carefully read the document provided.\\n2. For each fact in the list of facts:\\n   a. Determine if the document directly contradicts the fact. Note that :\\n        - Any extra information in the fact not present in the document should not be considered a contradiction and\\n        be ignored.\\n        - If the document describes a different procedure to accomplish the same task in the fact, this should not\\n        constitute a contradiction unless the document explicitly states that the described procedure is the only way\\n        to accomplish the task\\n   b. If fact is not contradicted by the document, ignore the fact.\\n   c. If fact is contradicted, capture it in output\\n2. For each fact in the list of facts:\\n   a. Determine if the document directly contradicts the fact. Any extra information in the fact not present in the\\n   document should not be considered a contradiction and be ignored.\\n   b. If fact is not contradicted by the document, ignore the fact.\\n   c. If fact is contradicted, capture it in output\\n\\n3. Construct your output in the JSON format specified by the output_schema.\\n\\nExamples:\\nfact: &quot;an apple is a fruit&quot;\\ndocument: &quot;an orange is a fruit&quot;.\\nresult: no contradiction\\n\\nfact: &quot;an apple is a fruit and can be eaten after cutting by knife&quot;\\ndocument: &quot;an apple is a fruit&quot;\\nresult: no contradiction\\n\\nfact: &quot;an apple is a fruit and can be eaten after cutting by knife&quot;\\ndocument: &quot;an apple is a fruit and can be eaten by biting directly into it&quot;\\nresult: no contradiction\\n\\nfact: &quot;an apple is a fruit&quot;\\ndocument: &quot;an apple is a round fruit and can be eaten by biting directly into it&quot;\\nresult: no contradiction\\n\\nfact: &quot;an apple is a fruit&quot;\\ndocument: &quot;an apple is not a fruit&quot;\\nresult: contradiction\\n\\nfact: &quot;an apple can be eaten in 3 different ways: (1) biting, (2) slicing, (3) cutting&quot;\\ndocument: &quot;here are two different ways of eating apple: (1) biting and (2) cutting&quot;\\nresult: no contradiction, since extra information in fact not mentioned in document\\n\\nRemember:\\n- Your final output must be strictly in the JSON format specified by the output_schema.\\n- Double-check your JSON structure before finalizing your response.\\n- Do not output any reasoning or justifications.\\n&#x27;",
        },
        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
          fullname: "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT",
          modulename: "lightudq.prompts",
          qualname: "PII_PRESENCE_CHECK_PROMPT",
          kind: "variable",
          doc: "<p></p>\n",
          default_value:
            "&#x27;Check if the following document contains any Personally Identifiable Information (PII).\\n&lt;document&gt;\\n{document}\\n&lt;/document&gt;\\n\\nStructure the output using this json schema:\\n&lt;output_schema&gt;\\n{output_schema}\\n&lt;/output_schema&gt;\\n\\nDo not output any reasoning or justifications.\\n&#x27;",
        },
        "lightudq.prompts.SUMMARY_PROMPT": {
          fullname: "lightudq.prompts.SUMMARY_PROMPT",
          modulename: "lightudq.prompts",
          qualname: "SUMMARY_PROMPT",
          kind: "variable",
          doc: "<p></p>\n",
          default_value:
            "&#x27;Summarize the following document in no more than 100 words. &lt;document&gt;{document}&lt;/document&gt;&#x27;",
        },
        "lightudq.schemas": {
          fullname: "lightudq.schemas",
          modulename: "lightudq.schemas",
          kind: "module",
          doc: "<p></p>\n",
        },
        "lightudq.schemas.ReasoningMixin": {
          fullname: "lightudq.schemas.ReasoningMixin",
          modulename: "lightudq.schemas",
          qualname: "ReasoningMixin",
          kind: "class",
          doc: "<p></p>\n",
        },
        "lightudq.schemas.ReasoningMixin.reasoning": {
          fullname: "lightudq.schemas.ReasoningMixin.reasoning",
          modulename: "lightudq.schemas",
          qualname: "ReasoningMixin.reasoning",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
          default_value:
            "FieldInfo(annotation=Union[str, NoneType], required=False, default=None, description=&#x27;reasoning or justification for the answer. This should be limited to 100 words.&#x27;)",
        },
        "lightudq.schemas.QnAPair": {
          fullname: "lightudq.schemas.QnAPair",
          modulename: "lightudq.schemas",
          qualname: "QnAPair",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.QnAPair.question": {
          fullname: "lightudq.schemas.QnAPair.question",
          modulename: "lightudq.schemas",
          qualname: "QnAPair.question",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": str",
        },
        "lightudq.schemas.QnAPair.answer": {
          fullname: "lightudq.schemas.QnAPair.answer",
          modulename: "lightudq.schemas",
          qualname: "QnAPair.answer",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": str",
        },
        "lightudq.schemas.QnAPair.model_config": {
          fullname: "lightudq.schemas.QnAPair.model_config",
          modulename: "lightudq.schemas",
          qualname: "QnAPair.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.QnAPairs": {
          fullname: "lightudq.schemas.QnAPairs",
          modulename: "lightudq.schemas",
          qualname: "QnAPairs",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.QnAPairs.qna_pairs": {
          fullname: "lightudq.schemas.QnAPairs.qna_pairs",
          modulename: "lightudq.schemas",
          qualname: "QnAPairs.qna_pairs",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": list[lightudq.schemas.QnAPair]",
        },
        "lightudq.schemas.QnAPairs.questions": {
          fullname: "lightudq.schemas.QnAPairs.questions",
          modulename: "lightudq.schemas",
          qualname: "QnAPairs.questions",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.schemas.QnAPairs.answers": {
          fullname: "lightudq.schemas.QnAPairs.answers",
          modulename: "lightudq.schemas",
          qualname: "QnAPairs.answers",
          kind: "variable",
          doc: "<p></p>\n",
        },
        "lightudq.schemas.QnAPairs.model_config": {
          fullname: "lightudq.schemas.QnAPairs.model_config",
          modulename: "lightudq.schemas",
          qualname: "QnAPairs.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.FactCompare": {
          fullname: "lightudq.schemas.FactCompare",
          modulename: "lightudq.schemas",
          qualname: "FactCompare",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.FactCompare.original": {
          fullname: "lightudq.schemas.FactCompare.original",
          modulename: "lightudq.schemas",
          qualname: "FactCompare.original",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": str",
        },
        "lightudq.schemas.FactCompare.new": {
          fullname: "lightudq.schemas.FactCompare.new",
          modulename: "lightudq.schemas",
          qualname: "FactCompare.new",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": str",
        },
        "lightudq.schemas.FactCompare.model_config": {
          fullname: "lightudq.schemas.FactCompare.model_config",
          modulename: "lightudq.schemas",
          qualname: "FactCompare.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.InconsistentFacts": {
          fullname: "lightudq.schemas.InconsistentFacts",
          modulename: "lightudq.schemas",
          qualname: "InconsistentFacts",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel, ReasoningMixin",
        },
        "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
          fullname: "lightudq.schemas.InconsistentFacts.inconsistent_facts",
          modulename: "lightudq.schemas",
          qualname: "InconsistentFacts.inconsistent_facts",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": typing.Annotated[int, Ge(ge=0)]",
        },
        "lightudq.schemas.InconsistentFacts.metadata": {
          fullname: "lightudq.schemas.InconsistentFacts.metadata",
          modulename: "lightudq.schemas",
          qualname: "InconsistentFacts.metadata",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[list[lightudq.schemas.FactCompare]]",
        },
        "lightudq.schemas.InconsistentFacts.model_config": {
          fullname: "lightudq.schemas.InconsistentFacts.model_config",
          modulename: "lightudq.schemas",
          qualname: "InconsistentFacts.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.FactCheckOutput": {
          fullname: "lightudq.schemas.FactCheckOutput",
          modulename: "lightudq.schemas",
          qualname: "FactCheckOutput",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "InconsistentFacts",
        },
        "lightudq.schemas.FactCheckOutput.source": {
          fullname: "lightudq.schemas.FactCheckOutput.source",
          modulename: "lightudq.schemas",
          qualname: "FactCheckOutput.source",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
        },
        "lightudq.schemas.FactCheckOutput.target": {
          fullname: "lightudq.schemas.FactCheckOutput.target",
          modulename: "lightudq.schemas",
          qualname: "FactCheckOutput.target",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
        },
        "lightudq.schemas.FactCheckOutput.model_config": {
          fullname: "lightudq.schemas.FactCheckOutput.model_config",
          modulename: "lightudq.schemas",
          qualname: "FactCheckOutput.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.MissingQuestions": {
          fullname: "lightudq.schemas.MissingQuestions",
          modulename: "lightudq.schemas",
          qualname: "MissingQuestions",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel, ReasoningMixin",
        },
        "lightudq.schemas.MissingQuestions.questions": {
          fullname: "lightudq.schemas.MissingQuestions.questions",
          modulename: "lightudq.schemas",
          qualname: "MissingQuestions.questions",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[list[str]]",
        },
        "lightudq.schemas.MissingQuestions.model_config": {
          fullname: "lightudq.schemas.MissingQuestions.model_config",
          modulename: "lightudq.schemas",
          qualname: "MissingQuestions.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.PIIPresence": {
          fullname: "lightudq.schemas.PIIPresence",
          modulename: "lightudq.schemas",
          qualname: "PIIPresence",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.PIIPresence.present": {
          fullname: "lightudq.schemas.PIIPresence.present",
          modulename: "lightudq.schemas",
          qualname: "PIIPresence.present",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": bool",
        },
        "lightudq.schemas.PIIPresence.metadata": {
          fullname: "lightudq.schemas.PIIPresence.metadata",
          modulename: "lightudq.schemas",
          qualname: "PIIPresence.metadata",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[list[str]]",
        },
        "lightudq.schemas.PIIPresence.count": {
          fullname: "lightudq.schemas.PIIPresence.count",
          modulename: "lightudq.schemas",
          qualname: "PIIPresence.count",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[Annotated[int, Ge(ge=0)]]",
        },
        "lightudq.schemas.PIIPresence.model_config": {
          fullname: "lightudq.schemas.PIIPresence.model_config",
          modulename: "lightudq.schemas",
          qualname: "PIIPresence.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.DocumentProfile": {
          fullname: "lightudq.schemas.DocumentProfile",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.DocumentProfile.title": {
          fullname: "lightudq.schemas.DocumentProfile.title",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.title",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
        },
        "lightudq.schemas.DocumentProfile.wordCount": {
          fullname: "lightudq.schemas.DocumentProfile.wordCount",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.wordCount",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[Annotated[int, Ge(ge=0)]]",
        },
        "lightudq.schemas.DocumentProfile.qnaPairs": {
          fullname: "lightudq.schemas.DocumentProfile.qnaPairs",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.qnaPairs",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.QnAPairs]",
        },
        "lightudq.schemas.DocumentProfile.summary": {
          fullname: "lightudq.schemas.DocumentProfile.summary",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.summary",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
        },
        "lightudq.schemas.DocumentProfile.fileType": {
          fullname: "lightudq.schemas.DocumentProfile.fileType",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.fileType",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[str]",
        },
        "lightudq.schemas.DocumentProfile.fileSize": {
          fullname: "lightudq.schemas.DocumentProfile.fileSize",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.fileSize",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[int]",
        },
        "lightudq.schemas.DocumentProfile.model_config": {
          fullname: "lightudq.schemas.DocumentProfile.model_config",
          modulename: "lightudq.schemas",
          qualname: "DocumentProfile.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.schemas.DocumentQualityCheckResult": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult",
          kind: "class",
          doc: '<p>!!! abstract "Usage Documentation"\n    <a href="../concepts/models.md">Models</a></p>\n\n<p>A base class for creating Pydantic models.</p>\n\n<p>Attributes:\n    __class_vars__: The names of the class variables defined on the model.\n    __private_attributes__: Metadata about the private attributes of the model.\n    __signature__: The synthesized <code>__init__</code> [<code>Signature</code>][inspect.Signature] of the model.</p>\n\n<pre><code>__pydantic_complete__: Whether model building is completed, or if there are still undefined fields.\n__pydantic_core_schema__: The core schema of the model.\n__pydantic_custom_init__: Whether the model has a custom `__init__` function.\n__pydantic_decorators__: Metadata containing the decorators defined on the model.\n    This replaces `Model.__validators__` and `Model.__root_validators__` from Pydantic V1.\n__pydantic_generic_metadata__: Metadata for generic models; contains data used for a similar purpose to\n    __args__, __origin__, __parameters__ in typing-module generics. May eventually be replaced by these.\n__pydantic_parent_namespace__: Parent namespace of the model, used for automatic rebuilding of models.\n__pydantic_post_init__: The name of the post-init method for the model, if defined.\n__pydantic_root_model__: Whether the model is a [`RootModel`][pydantic.root_model.RootModel].\n__pydantic_serializer__: The `pydantic-core` `SchemaSerializer` used to dump instances of the model.\n__pydantic_validator__: The `pydantic-core` `SchemaValidator` used to validate instances of the model.\n\n__pydantic_fields__: A dictionary of field names and their corresponding [`FieldInfo`][pydantic.fields.FieldInfo] objects.\n__pydantic_computed_fields__: A dictionary of computed field names and their corresponding [`ComputedFieldInfo`][pydantic.fields.ComputedFieldInfo] objects.\n\n__pydantic_extra__: A dictionary containing extra values, if [`extra`][pydantic.config.ConfigDict.extra]\n    is set to `\'allow\'`.\n__pydantic_fields_set__: The names of fields explicitly set during instantiation.\n__pydantic_private__: Values of private attributes set on the model instance.\n</code></pre>\n',
          bases: "pydantic.main.BaseModel",
        },
        "lightudq.schemas.DocumentQualityCheckResult.profile": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.profile",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.profile",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.DocumentProfile]",
        },
        "lightudq.schemas.DocumentQualityCheckResult.inconsistency": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.inconsistency",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.inconsistency",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.InconsistentFacts]",
        },
        "lightudq.schemas.DocumentQualityCheckResult.pii": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.pii",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.pii",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": lightudq.schemas.PIIPresence",
        },
        "lightudq.schemas.DocumentQualityCheckResult.incompleteness": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.incompleteness",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.incompleteness",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.MissingQuestions]",
        },
        "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.inaccuracy",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.inaccuracy",
          kind: "variable",
          doc: "<p></p>\n",
          annotation: ": Optional[lightudq.schemas.InconsistentFacts]",
        },
        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
          fullname: "lightudq.schemas.DocumentQualityCheckResult.model_config",
          modulename: "lightudq.schemas",
          qualname: "DocumentQualityCheckResult.model_config",
          kind: "variable",
          doc: "<p>Configuration for the model, should be a dictionary conforming to [<code>ConfigDict</code>][pydantic.config.ConfigDict].</p>\n",
          annotation: ": ClassVar[pydantic.config.ConfigDict]",
          default_value: "{}",
        },
        "lightudq.utils": {
          fullname: "lightudq.utils",
          modulename: "lightudq.utils",
          kind: "module",
          doc: "<p></p>\n",
        },
        "lightudq.utils.read_markdown_to_text": {
          fullname: "lightudq.utils.read_markdown_to_text",
          modulename: "lightudq.utils",
          qualname: "read_markdown_to_text",
          kind: "function",
          doc: "<p></p>\n",
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="n">file_path</span><span class="p">:</span> <span class="nb">str</span></span><span class="return-annotation">) -> <span class="nb">str</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.utils.read_pdf_to_text": {
          fullname: "lightudq.utils.read_pdf_to_text",
          modulename: "lightudq.utils",
          qualname: "read_pdf_to_text",
          kind: "function",
          doc: "<p></p>\n",
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="n">file_path</span><span class="p">:</span> <span class="nb">str</span></span><span class="return-annotation">) -> <span class="nb">str</span>:</span></span>',
          funcdef: "def",
        },
        "lightudq.utils.read_document": {
          fullname: "lightudq.utils.read_document",
          modulename: "lightudq.utils",
          qualname: "read_document",
          kind: "function",
          doc: "<p>Read document content based on file extension</p>\n",
          signature:
            '<span class="signature pdoc-code condensed">(<span class="param"><span class="n">file_path</span><span class="p">:</span> <span class="nb">str</span></span><span class="return-annotation">) -> <span class="nb">str</span>:</span></span>',
          funcdef: "def",
        },
      },
      docInfo: {
        lightudq: {
          qualname: 0,
          fullname: 1,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 1418,
        },
        "lightudq.document_quality": {
          qualname: 0,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality": {
          qualname: 1,
          fullname: 4,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 8,
        },
        "lightudq.document_quality.DocumentQuality.__init__": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 38,
          bases: 0,
          doc: 49,
        },
        "lightudq.document_quality.DocumentQuality.file_path": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.document": {
          qualname: 2,
          fullname: 5,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.profile": {
          qualname: 2,
          fullname: 5,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.output": {
          qualname: 2,
          fullname: 5,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.doc_profile": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.llm_client": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.document_quality.DocumentQuality.run": {
          qualname: 2,
          fullname: 5,
          annotation: 0,
          default_value: 0,
          signature: 24,
          bases: 0,
          doc: 30,
        },
        "lightudq.document_quality.DocumentQuality.compare": {
          qualname: 2,
          fullname: 5,
          annotation: 0,
          default_value: 0,
          signature: 47,
          bases: 0,
          doc: 49,
        },
        "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
          qualname: 5,
          fullname: 8,
          annotation: 0,
          default_value: 0,
          signature: 135,
          bases: 0,
          doc: 54,
        },
        "lightudq.document_quality.DocumentQuality.extract_qna": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 24,
          bases: 0,
          doc: 27,
        },
        "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 40,
          bases: 0,
          doc: 46,
        },
        "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
          qualname: 3,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 40,
          bases: 0,
          doc: 46,
        },
        "lightudq.document_quality.DocumentQuality.pii_presence_check": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 24,
          bases: 0,
          doc: 35,
        },
        "lightudq.document_quality.DocumentQuality.get_word_count": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 14,
          bases: 0,
          doc: 22,
        },
        "lightudq.document_quality.DocumentQuality.get_doc_summary": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 14,
          bases: 0,
          doc: 19,
        },
        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 35,
          bases: 0,
          doc: 9,
        },
        "lightudq.document_quality.DocumentQuality.get_document_profile": {
          qualname: 4,
          fullname: 7,
          annotation: 0,
          default_value: 0,
          signature: 24,
          bases: 0,
          doc: 22,
        },
        "lightudq.prompts": {
          qualname: 0,
          fullname: 2,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
          qualname: 3,
          fullname: 5,
          annotation: 0,
          default_value: 185,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
          qualname: 3,
          fullname: 5,
          annotation: 0,
          default_value: 59,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.prompts.FACT_CHECK_PROMPT": {
          qualname: 3,
          fullname: 5,
          annotation: 0,
          default_value: 474,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
          qualname: 4,
          fullname: 6,
          annotation: 0,
          default_value: 48,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.prompts.SUMMARY_PROMPT": {
          qualname: 2,
          fullname: 4,
          annotation: 0,
          default_value: 21,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas": {
          qualname: 0,
          fullname: 2,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.ReasoningMixin": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.ReasoningMixin.reasoning": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 25,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPair": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.QnAPair.question": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPair.answer": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPair.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.QnAPairs": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.QnAPairs.qna_pairs": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPairs.questions": {
          qualname: 2,
          fullname: 4,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPairs.answers": {
          qualname: 2,
          fullname: 4,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.QnAPairs.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.FactCompare": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.FactCompare.original": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.FactCompare.new": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.FactCompare.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.InconsistentFacts": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 4,
          doc: 308,
        },
        "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
          qualname: 3,
          fullname: 5,
          annotation: 7,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.InconsistentFacts.metadata": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.InconsistentFacts.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.FactCheckOutput": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 1,
          doc: 308,
        },
        "lightudq.schemas.FactCheckOutput.source": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.FactCheckOutput.target": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.FactCheckOutput.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.MissingQuestions": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 4,
          doc: 308,
        },
        "lightudq.schemas.MissingQuestions.questions": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.MissingQuestions.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.PIIPresence": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.PIIPresence.present": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.PIIPresence.metadata": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.PIIPresence.count": {
          qualname: 2,
          fullname: 4,
          annotation: 6,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.PIIPresence.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.DocumentProfile": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.DocumentProfile.title": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.wordCount": {
          qualname: 2,
          fullname: 4,
          annotation: 6,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.qnaPairs": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.summary": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.fileType": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.fileSize": {
          qualname: 2,
          fullname: 4,
          annotation: 2,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentProfile.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.schemas.DocumentQualityCheckResult": {
          qualname: 1,
          fullname: 3,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 3,
          doc: 308,
        },
        "lightudq.schemas.DocumentQualityCheckResult.profile": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentQualityCheckResult.inconsistency": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentQualityCheckResult.pii": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentQualityCheckResult.incompleteness": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
          qualname: 2,
          fullname: 4,
          annotation: 4,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
          qualname: 3,
          fullname: 5,
          annotation: 4,
          default_value: 1,
          signature: 0,
          bases: 0,
          doc: 18,
        },
        "lightudq.utils": {
          qualname: 0,
          fullname: 2,
          annotation: 0,
          default_value: 0,
          signature: 0,
          bases: 0,
          doc: 3,
        },
        "lightudq.utils.read_markdown_to_text": {
          qualname: 4,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 20,
          bases: 0,
          doc: 3,
        },
        "lightudq.utils.read_pdf_to_text": {
          qualname: 4,
          fullname: 6,
          annotation: 0,
          default_value: 0,
          signature: 20,
          bases: 0,
          doc: 3,
        },
        "lightudq.utils.read_document": {
          qualname: 2,
          fullname: 4,
          annotation: 0,
          default_value: 0,
          signature: 20,
          bases: 0,
          doc: 9,
        },
      },
      length: 78,
      save: true,
    },
    index: {
      qualname: {
        root: {
          docs: { "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 } },
          df: 1,
          d: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.doc_profile": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                },
                df: 2,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.document": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1 },
                            "lightudq.utils.read_document": { tf: 1 },
                          },
                          df: 3,
                          q: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      y: {
                                        docs: {
                                          "lightudq.document_quality.DocumentQuality": {
                                            tf: 1,
                                          },
                                          "lightudq.document_quality.DocumentQuality.__init__":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.file_path":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.document":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.profile":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.output":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.doc_profile":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.llm_client":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.run":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.compare":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.extract_qna":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.pii_presence_check":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_word_count":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_doc_summary":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_custom_metric":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                                            { tf: 1 },
                                        },
                                        df: 19,
                                        c: {
                                          docs: {},
                                          df: 0,
                                          h: {
                                            docs: {},
                                            df: 0,
                                            e: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                k: {
                                                  docs: {},
                                                  df: 0,
                                                  r: {
                                                    docs: {},
                                                    df: 0,
                                                    e: {
                                                      docs: {},
                                                      df: 0,
                                                      s: {
                                                        docs: {},
                                                        df: 0,
                                                        u: {
                                                          docs: {},
                                                          df: 0,
                                                          l: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {
                                                                "lightudq.schemas.DocumentQualityCheckResult":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.profile":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.pii":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                                                  { tf: 1 },
                                                              },
                                                              df: 7,
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          p: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                f: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {
                                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                                          "lightudq.schemas.DocumentProfile.title": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.wordCount":
                                            { tf: 1 },
                                          "lightudq.schemas.DocumentProfile.qnaPairs": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.summary": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.fileType": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.fileSize": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.model_config":
                                            { tf: 1 },
                                        },
                                        df: 8,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                  },
                  df: 1,
                },
              },
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  s: {
                                    docs: {},
                                    df: 0,
                                    s: {
                                      docs: {
                                        "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                          { tf: 1 },
                                        "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                          { tf: 1 },
                                      },
                                      df: 2,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {
                                    "lightudq.schemas.InconsistentFacts.inconsistent_facts":
                                      { tf: 1 },
                                  },
                                  df: 1,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.schemas.InconsistentFacts": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.InconsistentFacts.inconsistent_facts":
                                                { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts.metadata":
                                                { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts.model_config":
                                                { tf: 1 },
                                            },
                                            df: 4,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                                c: {
                                  docs: {},
                                  df: 0,
                                  y: {
                                    docs: {
                                      "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                        { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                  { tf: 1 },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          f: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.file_path": { tf: 1 },
                  },
                  df: 1,
                  t: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.DocumentProfile.fileType": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                  s: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      z: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.DocumentProfile.fileSize": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                m: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                      tf: 1,
                    },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                  },
                  df: 2,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        p: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.FactCompare": { tf: 1 },
                                  "lightudq.schemas.FactCompare.original": { tf: 1 },
                                  "lightudq.schemas.FactCompare.new": { tf: 1 },
                                  "lightudq.schemas.FactCompare.model_config": {
                                    tf: 1,
                                  },
                                },
                                df: 4,
                              },
                            },
                          },
                        },
                      },
                    },
                    h: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          k: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              u: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  p: {
                                    docs: {},
                                    df: 0,
                                    u: {
                                      docs: {},
                                      df: 0,
                                      t: {
                                        docs: {
                                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                          "lightudq.schemas.FactCheckOutput.source": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.FactCheckOutput.target": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.FactCheckOutput.model_config":
                                            { tf: 1 },
                                        },
                                        df: 4,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  s: {
                    docs: {
                      "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                        tf: 1,
                      },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.file_path": { tf: 1 },
                  },
                  df: 1,
                },
              },
              i: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: { "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.doc_profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.profile": {
                            tf: 1,
                          },
                        },
                        df: 4,
                      },
                    },
                  },
                },
                m: {
                  docs: {},
                  df: 0,
                  p: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                        "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                      },
                      df: 5,
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                      t: {
                        docs: { "lightudq.schemas.PIIPresence.present": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              i: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1,
                  },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult.pii": { tf: 1 },
                },
                df: 3,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.PIIPresence": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.present": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.count": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.model_config": {
                                    tf: 1,
                                  },
                                },
                                df: 5,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            d: {
              docs: {},
              df: 0,
              f: { docs: { "lightudq.utils.read_pdf_to_text": { tf: 1 } }, df: 1 },
            },
          },
          o: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.output": { tf: 1 },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: { "lightudq.schemas.FactCompare.original": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          l: {
            docs: {},
            df: 0,
            l: {
              docs: {},
              df: 0,
              m: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.llm_client": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                },
                df: 2,
              },
            },
          },
          c: {
            docs: {},
            df: 0,
            l: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.llm_client": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              u: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_word_count": {
                        tf: 1,
                      },
                      "lightudq.schemas.PIIPresence.count": { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                        "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                        "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                        "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                          tf: 1,
                        },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  k: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                      "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                    },
                    df: 3,
                    s: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                          { tf: 1 },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              n: {
                docs: { "lightudq.document_quality.DocumentQuality.run": { tf: 1 } },
                df: 1,
              },
            },
            e: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {
                              "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            },
                            df: 1,
                            m: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                x: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {
                                        "lightudq.schemas.ReasoningMixin": { tf: 1 },
                                        "lightudq.schemas.ReasoningMixin.reasoning": {
                                          tf: 1,
                                        },
                                      },
                                      df: 2,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                d: {
                  docs: {
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                    "lightudq.utils.read_document": { tf: 1 },
                  },
                  df: 3,
                },
              },
            },
          },
          g: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_document_profile": {
                    tf: 1,
                  },
                },
                df: 5,
              },
            },
          },
          e: {
            docs: {},
            df: 0,
            x: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        },
                        df: 2,
                      },
                    },
                  },
                },
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              a: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                },
                df: 3,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPair.question": { tf: 1 },
                          "lightudq.schemas.QnAPair.answer": { tf: 1 },
                          "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        },
                        df: 4,
                        s: {
                          docs: {
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                            "lightudq.schemas.QnAPairs.answers": { tf: 1 },
                            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                          },
                          df: 6,
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { "lightudq.schemas.QnAPair.question": { tf: 1 } },
                          df: 1,
                          s: {
                            docs: {
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                              "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                              "lightudq.schemas.MissingQuestions.questions": { tf: 1 },
                            },
                            df: 3,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                          { tf: 1 },
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 2,
                    },
                  },
                },
                a: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {
                            "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
                            "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {
                          "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                        },
                        df: 1,
                        q: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        s: {
                                          docs: {
                                            "lightudq.schemas.MissingQuestions": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.MissingQuestions.questions":
                                              { tf: 1 },
                                            "lightudq.schemas.MissingQuestions.model_config":
                                              { tf: 1 },
                                          },
                                          df: 3,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                      "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                      "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                      "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                      "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                        tf: 1,
                      },
                    },
                    df: 9,
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                k: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      w: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { "lightudq.utils.read_markdown_to_text": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          w: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                d: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_word_count": {
                      tf: 1,
                    },
                  },
                  df: 1,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {
                              "lightudq.schemas.DocumentProfile.wordCount": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          s: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                m: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      y: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                            tf: 1,
                          },
                          "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.summary": { tf: 1 },
                        },
                        df: 3,
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              u: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { "lightudq.schemas.FactCheckOutput.source": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          a: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: { "lightudq.schemas.QnAPair.answer": { tf: 1 } },
                      df: 1,
                      s: {
                        docs: { "lightudq.schemas.QnAPairs.answers": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
          },
          n: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              w: { docs: { "lightudq.schemas.FactCompare.new": { tf: 1 } }, df: 1 },
            },
          },
          t: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: { "lightudq.schemas.FactCheckOutput.target": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.schemas.DocumentProfile.title": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            o: {
              docs: {
                "lightudq.utils.read_markdown_to_text": { tf: 1 },
                "lightudq.utils.read_pdf_to_text": { tf: 1 },
              },
              df: 2,
            },
            e: {
              docs: {},
              df: 0,
              x: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                  },
                  df: 2,
                },
              },
            },
          },
        },
      },
      fullname: {
        root: {
          docs: { "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 } },
          df: 1,
          l: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              g: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.document_quality": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.file_path": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.document": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.profile": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.output": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.doc_profile": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.llm_client": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.compare": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_word_count":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_doc_summary":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_custom_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1 },
                            "lightudq.prompts": { tf: 1 },
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                            "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                            "lightudq.schemas": { tf: 1 },
                            "lightudq.schemas.ReasoningMixin": { tf: 1 },
                            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPair.question": { tf: 1 },
                            "lightudq.schemas.QnAPair.answer": { tf: 1 },
                            "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                            "lightudq.schemas.QnAPairs.answers": { tf: 1 },
                            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.FactCompare.original": { tf: 1 },
                            "lightudq.schemas.FactCompare.new": { tf: 1 },
                            "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                              tf: 1,
                            },
                            "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts.model_config": {
                              tf: 1,
                            },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput.source": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput.target": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.MissingQuestions.questions": { tf: 1 },
                            "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.PIIPresence.present": { tf: 1 },
                            "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                            "lightudq.schemas.PIIPresence.count": { tf: 1 },
                            "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.title": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.wordCount": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.summary": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.fileType": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.fileSize": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult.profile": {
                              tf: 1,
                            },
                            "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                              { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult.pii": {
                              tf: 1,
                            },
                            "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                              { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
                              tf: 1,
                            },
                            "lightudq.schemas.DocumentQualityCheckResult.model_config":
                              { tf: 1 },
                            "lightudq.utils": { tf: 1 },
                            "lightudq.utils.read_markdown_to_text": { tf: 1 },
                            "lightudq.utils.read_pdf_to_text": { tf: 1 },
                            "lightudq.utils.read_document": { tf: 1 },
                          },
                          df: 78,
                        },
                      },
                    },
                  },
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              m: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.llm_client": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                },
                df: 2,
              },
            },
          },
          d: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.doc_profile": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                },
                df: 2,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            "lightudq.document_quality": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.file_path": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.document": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.document_quality.DocumentQuality.profile": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.output": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.doc_profile": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.llm_client": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.compare": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_word_count":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_doc_summary":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_custom_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1.4142135623730951 },
                            "lightudq.utils.read_document": { tf: 1 },
                          },
                          df: 21,
                          q: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      y: {
                                        docs: {
                                          "lightudq.document_quality.DocumentQuality": {
                                            tf: 1,
                                          },
                                          "lightudq.document_quality.DocumentQuality.__init__":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.file_path":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.document":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.profile":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.output":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.doc_profile":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.llm_client":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.run":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.compare":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.extract_qna":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.pii_presence_check":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_word_count":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_doc_summary":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_custom_metric":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                                            { tf: 1 },
                                        },
                                        df: 19,
                                        c: {
                                          docs: {},
                                          df: 0,
                                          h: {
                                            docs: {},
                                            df: 0,
                                            e: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                k: {
                                                  docs: {},
                                                  df: 0,
                                                  r: {
                                                    docs: {},
                                                    df: 0,
                                                    e: {
                                                      docs: {},
                                                      df: 0,
                                                      s: {
                                                        docs: {},
                                                        df: 0,
                                                        u: {
                                                          docs: {},
                                                          df: 0,
                                                          l: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {
                                                                "lightudq.schemas.DocumentQualityCheckResult":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.profile":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.pii":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                                                  { tf: 1 },
                                                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                                                  { tf: 1 },
                                                              },
                                                              df: 7,
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          p: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                f: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {
                                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                                          "lightudq.schemas.DocumentProfile.title": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.wordCount":
                                            { tf: 1 },
                                          "lightudq.schemas.DocumentProfile.qnaPairs": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.summary": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.fileType": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.fileSize": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.DocumentProfile.model_config":
                                            { tf: 1 },
                                        },
                                        df: 8,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      y: {
                        docs: {
                          "lightudq.document_quality": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.__init__": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.file_path": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.document": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.output": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.doc_profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.llm_client": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.pii_presence_check":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.get_word_count": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_custom_metric":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1 },
                        },
                        df: 20,
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { "lightudq.schemas.QnAPair.question": { tf: 1 } },
                          df: 1,
                          s: {
                            docs: {
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                              "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                              "lightudq.schemas.MissingQuestions.questions": { tf: 1 },
                            },
                            df: 3,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            n: {
              docs: {},
              df: 0,
              a: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                },
                df: 3,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPair.question": { tf: 1 },
                          "lightudq.schemas.QnAPair.answer": { tf: 1 },
                          "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        },
                        df: 4,
                        s: {
                          docs: {
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                            "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                            "lightudq.schemas.QnAPairs.answers": { tf: 1 },
                            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                          },
                          df: 6,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                  },
                  df: 1,
                },
              },
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  s: {
                                    docs: {},
                                    df: 0,
                                    s: {
                                      docs: {
                                        "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                          { tf: 1 },
                                        "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                          { tf: 1 },
                                      },
                                      df: 2,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {
                                    "lightudq.schemas.InconsistentFacts.inconsistent_facts":
                                      { tf: 1 },
                                  },
                                  df: 1,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.schemas.InconsistentFacts": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.InconsistentFacts.inconsistent_facts":
                                                { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts.metadata":
                                                { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts.model_config":
                                                { tf: 1 },
                                            },
                                            df: 4,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                                c: {
                                  docs: {},
                                  df: 0,
                                  y: {
                                    docs: {
                                      "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                        { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                  { tf: 1 },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          f: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.file_path": { tf: 1 },
                  },
                  df: 1,
                  t: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.DocumentProfile.fileType": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                  s: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      z: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.DocumentProfile.fileSize": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                m: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                      tf: 1,
                    },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                  },
                  df: 2,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        p: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.FactCompare": { tf: 1 },
                                  "lightudq.schemas.FactCompare.original": { tf: 1 },
                                  "lightudq.schemas.FactCompare.new": { tf: 1 },
                                  "lightudq.schemas.FactCompare.model_config": {
                                    tf: 1,
                                  },
                                },
                                df: 4,
                              },
                            },
                          },
                        },
                      },
                    },
                    h: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          k: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              u: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  p: {
                                    docs: {},
                                    df: 0,
                                    u: {
                                      docs: {},
                                      df: 0,
                                      t: {
                                        docs: {
                                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                          "lightudq.schemas.FactCheckOutput.source": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.FactCheckOutput.target": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.FactCheckOutput.model_config":
                                            { tf: 1 },
                                        },
                                        df: 4,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  s: {
                    docs: {
                      "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                        tf: 1,
                      },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.file_path": { tf: 1 },
                  },
                  df: 1,
                },
              },
              i: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: { "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.doc_profile": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.profile": {
                            tf: 1,
                          },
                        },
                        df: 4,
                      },
                    },
                  },
                },
                m: {
                  docs: {},
                  df: 0,
                  p: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                        "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                      },
                      df: 5,
                      s: {
                        docs: {
                          "lightudq.prompts": { tf: 1 },
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                          "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                          "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                          "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                          "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                        },
                        df: 6,
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                      t: {
                        docs: { "lightudq.schemas.PIIPresence.present": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              i: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1,
                  },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult.pii": { tf: 1 },
                },
                df: 3,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.PIIPresence": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.present": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.count": { tf: 1 },
                                  "lightudq.schemas.PIIPresence.model_config": {
                                    tf: 1,
                                  },
                                },
                                df: 5,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            d: {
              docs: {},
              df: 0,
              f: { docs: { "lightudq.utils.read_pdf_to_text": { tf: 1 } }, df: 1 },
            },
          },
          o: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.output": { tf: 1 },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: { "lightudq.schemas.FactCompare.original": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          c: {
            docs: {},
            df: 0,
            l: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.llm_client": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              u: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_word_count": {
                        tf: 1,
                      },
                      "lightudq.schemas.PIIPresence.count": { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                        "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                        "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                        "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                          tf: 1,
                        },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  k: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                      "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                    },
                    df: 3,
                    s: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                          { tf: 1 },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              n: {
                docs: { "lightudq.document_quality.DocumentQuality.run": { tf: 1 } },
                df: 1,
              },
            },
            e: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {
                              "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            },
                            df: 1,
                            m: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                x: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {
                                        "lightudq.schemas.ReasoningMixin": { tf: 1 },
                                        "lightudq.schemas.ReasoningMixin.reasoning": {
                                          tf: 1,
                                        },
                                      },
                                      df: 2,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                d: {
                  docs: {
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                    "lightudq.utils.read_document": { tf: 1 },
                  },
                  df: 3,
                },
              },
            },
          },
          g: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_document_profile": {
                    tf: 1,
                  },
                },
                df: 5,
              },
            },
          },
          e: {
            docs: {},
            df: 0,
            x: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        },
                        df: 2,
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                          { tf: 1 },
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 2,
                    },
                  },
                },
                a: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {
                            "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
                            "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {
                          "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                        },
                        df: 1,
                        q: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        s: {
                                          docs: {
                                            "lightudq.schemas.MissingQuestions": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.MissingQuestions.questions":
                                              { tf: 1 },
                                            "lightudq.schemas.MissingQuestions.model_config":
                                              { tf: 1 },
                                          },
                                          df: 3,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                      "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                      "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                      "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                      "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                        tf: 1,
                      },
                    },
                    df: 9,
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                k: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      w: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { "lightudq.utils.read_markdown_to_text": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          w: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                d: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_word_count": {
                      tf: 1,
                    },
                  },
                  df: 1,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {
                              "lightudq.schemas.DocumentProfile.wordCount": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          s: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                m: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      y: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                            tf: 1,
                          },
                          "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.summary": { tf: 1 },
                        },
                        df: 3,
                      },
                    },
                  },
                },
              },
            },
            c: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {
                          "lightudq.schemas": { tf: 1 },
                          "lightudq.schemas.ReasoningMixin": { tf: 1 },
                          "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPair.question": { tf: 1 },
                          "lightudq.schemas.QnAPair.answer": { tf: 1 },
                          "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                          "lightudq.schemas.QnAPairs": { tf: 1 },
                          "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                          "lightudq.schemas.QnAPairs.questions": { tf: 1 },
                          "lightudq.schemas.QnAPairs.answers": { tf: 1 },
                          "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                          "lightudq.schemas.FactCompare": { tf: 1 },
                          "lightudq.schemas.FactCompare.original": { tf: 1 },
                          "lightudq.schemas.FactCompare.new": { tf: 1 },
                          "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                            tf: 1,
                          },
                          "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput.source": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput.target": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                          "lightudq.schemas.MissingQuestions": { tf: 1 },
                          "lightudq.schemas.MissingQuestions.questions": { tf: 1 },
                          "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                          "lightudq.schemas.PIIPresence": { tf: 1 },
                          "lightudq.schemas.PIIPresence.present": { tf: 1 },
                          "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
                          "lightudq.schemas.PIIPresence.count": { tf: 1 },
                          "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.title": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.wordCount": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.summary": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.fileType": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.fileSize": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.profile": {
                            tf: 1,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult.inconsistency": {
                            tf: 1,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult.pii": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                            { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
                            tf: 1,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                            tf: 1,
                          },
                        },
                        df: 47,
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              u: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { "lightudq.schemas.FactCheckOutput.source": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          a: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: { "lightudq.schemas.QnAPair.answer": { tf: 1 } },
                      df: 1,
                      s: {
                        docs: { "lightudq.schemas.QnAPairs.answers": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
          },
          n: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              w: { docs: { "lightudq.schemas.FactCompare.new": { tf: 1 } }, df: 1 },
            },
          },
          t: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: { "lightudq.schemas.FactCheckOutput.target": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.schemas.DocumentProfile.title": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            o: {
              docs: {
                "lightudq.utils.read_markdown_to_text": { tf: 1 },
                "lightudq.utils.read_pdf_to_text": { tf: 1 },
              },
              df: 2,
            },
            e: {
              docs: {},
              df: 0,
              x: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                  },
                  df: 2,
                },
              },
            },
          },
          u: {
            docs: {},
            df: 0,
            t: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {
                      "lightudq.utils": { tf: 1 },
                      "lightudq.utils.read_markdown_to_text": { tf: 1 },
                      "lightudq.utils.read_pdf_to_text": { tf: 1 },
                      "lightudq.utils.read_document": { tf: 1 },
                    },
                    df: 4,
                  },
                },
              },
            },
          },
        },
      },
      annotation: {
        root: {
          0: {
            docs: {
              "lightudq.schemas.InconsistentFacts.inconsistent_facts": { tf: 1 },
              "lightudq.schemas.PIIPresence.count": { tf: 1 },
              "lightudq.schemas.DocumentProfile.wordCount": { tf: 1 },
            },
            df: 3,
          },
          docs: {
            "lightudq.document_quality.DocumentQuality.output": { tf: 1 },
            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
            "lightudq.schemas.QnAPair.question": { tf: 1 },
            "lightudq.schemas.QnAPair.answer": { tf: 1 },
            "lightudq.schemas.QnAPair.model_config": { tf: 1 },
            "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
            "lightudq.schemas.FactCompare.original": { tf: 1 },
            "lightudq.schemas.FactCompare.new": { tf: 1 },
            "lightudq.schemas.FactCompare.model_config": { tf: 1 },
            "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
              tf: 1.4142135623730951,
            },
            "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
            "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
            "lightudq.schemas.FactCheckOutput.source": { tf: 1 },
            "lightudq.schemas.FactCheckOutput.target": { tf: 1 },
            "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
            "lightudq.schemas.MissingQuestions.questions": { tf: 1 },
            "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
            "lightudq.schemas.PIIPresence.present": { tf: 1 },
            "lightudq.schemas.PIIPresence.metadata": { tf: 1 },
            "lightudq.schemas.PIIPresence.count": { tf: 1.4142135623730951 },
            "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
            "lightudq.schemas.DocumentProfile.title": { tf: 1 },
            "lightudq.schemas.DocumentProfile.wordCount": { tf: 1.4142135623730951 },
            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
            "lightudq.schemas.DocumentProfile.summary": { tf: 1 },
            "lightudq.schemas.DocumentProfile.fileType": { tf: 1 },
            "lightudq.schemas.DocumentProfile.fileSize": { tf: 1 },
            "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.profile": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.inconsistency": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.pii": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.incompleteness": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
          },
          df: 35,
          o: {
            docs: {},
            df: 0,
            p: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          "[": {
                            docs: {},
                            df: 0,
                            l: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                g: {
                                  docs: {},
                                  df: 0,
                                  h: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      u: {
                                        docs: {},
                                        df: 0,
                                        d: {
                                          docs: {},
                                          df: 0,
                                          q: {
                                            docs: {
                                              "lightudq.document_quality.DocumentQuality.output":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentProfile.qnaPairs":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.profile":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                                { tf: 1 },
                                            },
                                            df: 6,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                                s: {
                                  docs: {},
                                  df: 0,
                                  t: {
                                    docs: {},
                                    df: 0,
                                    "[": {
                                      docs: {},
                                      df: 0,
                                      l: {
                                        docs: {},
                                        df: 0,
                                        i: {
                                          docs: {},
                                          df: 0,
                                          g: {
                                            docs: {},
                                            df: 0,
                                            h: {
                                              docs: {},
                                              df: 0,
                                              t: {
                                                docs: {},
                                                df: 0,
                                                u: {
                                                  docs: {},
                                                  df: 0,
                                                  d: {
                                                    docs: {},
                                                    df: 0,
                                                    q: {
                                                      docs: {
                                                        "lightudq.schemas.InconsistentFacts.metadata":
                                                          { tf: 1 },
                                                      },
                                                      df: 1,
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                      s: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          r: {
                                            docs: {
                                              "lightudq.schemas.MissingQuestions.questions":
                                                { tf: 1 },
                                              "lightudq.schemas.PIIPresence.metadata": {
                                                tf: 1,
                                              },
                                            },
                                            df: 2,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                            s: {
                              docs: {},
                              df: 0,
                              t: {
                                docs: {},
                                df: 0,
                                r: {
                                  docs: {
                                    "lightudq.schemas.ReasoningMixin.reasoning": {
                                      tf: 1,
                                    },
                                    "lightudq.schemas.FactCheckOutput.source": {
                                      tf: 1,
                                    },
                                    "lightudq.schemas.FactCheckOutput.target": {
                                      tf: 1,
                                    },
                                    "lightudq.schemas.DocumentProfile.title": { tf: 1 },
                                    "lightudq.schemas.DocumentProfile.summary": {
                                      tf: 1,
                                    },
                                    "lightudq.schemas.DocumentProfile.fileType": {
                                      tf: 1,
                                    },
                                  },
                                  df: 6,
                                },
                              },
                            },
                            a: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  o: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      a: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          e: {
                                            docs: {},
                                            df: 0,
                                            d: {
                                              docs: {},
                                              df: 0,
                                              "[": {
                                                docs: {},
                                                df: 0,
                                                i: {
                                                  docs: {},
                                                  df: 0,
                                                  n: {
                                                    docs: {},
                                                    df: 0,
                                                    t: {
                                                      docs: {
                                                        "lightudq.schemas.PIIPresence.count":
                                                          { tf: 1 },
                                                        "lightudq.schemas.DocumentProfile.wordCount":
                                                          { tf: 1 },
                                                      },
                                                      df: 2,
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                            i: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {
                                    "lightudq.schemas.DocumentProfile.fileSize": {
                                      tf: 1,
                                    },
                                  },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          s: {
            docs: {},
            df: 0,
            c: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.output": { tf: 1 },
                          "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts.metadata": { tf: 1 },
                          "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.profile": {
                            tf: 1,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult.inconsistency": {
                            tf: 1,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult.pii": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                            { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
                            tf: 1,
                          },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
            },
            t: {
              docs: {},
              df: 0,
              r: {
                docs: {
                  "lightudq.schemas.QnAPair.question": { tf: 1 },
                  "lightudq.schemas.QnAPair.answer": { tf: 1 },
                  "lightudq.schemas.FactCompare.original": { tf: 1 },
                  "lightudq.schemas.FactCompare.new": { tf: 1 },
                },
                df: 4,
              },
            },
          },
          d: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          q: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      y: {
                                        docs: {},
                                        df: 0,
                                        c: {
                                          docs: {},
                                          df: 0,
                                          h: {
                                            docs: {},
                                            df: 0,
                                            e: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                k: {
                                                  docs: {},
                                                  df: 0,
                                                  r: {
                                                    docs: {},
                                                    df: 0,
                                                    e: {
                                                      docs: {},
                                                      df: 0,
                                                      s: {
                                                        docs: {},
                                                        df: 0,
                                                        u: {
                                                          docs: {},
                                                          df: 0,
                                                          l: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {
                                                                "lightudq.document_quality.DocumentQuality.output":
                                                                  { tf: 1 },
                                                              },
                                                              df: 1,
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          p: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                f: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {
                                          "lightudq.schemas.DocumentQualityCheckResult.profile":
                                            { tf: 1 },
                                        },
                                        df: 1,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          c: {
            docs: {},
            df: 0,
            l: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    v: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          "[": {
                            docs: {},
                            df: 0,
                            p: {
                              docs: {},
                              df: 0,
                              y: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: {},
                                  df: 0,
                                  a: {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {},
                                      df: 0,
                                      t: {
                                        docs: {},
                                        df: 0,
                                        i: {
                                          docs: {},
                                          df: 0,
                                          c: {
                                            docs: {
                                              "lightudq.schemas.QnAPair.model_config": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.QnAPairs.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.FactCompare.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.FactCheckOutput.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.MissingQuestions.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.PIIPresence.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentProfile.model_config":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                                { tf: 1 },
                                            },
                                            df: 9,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                        "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                        "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                        "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                          tf: 1,
                        },
                      },
                      df: 9,
                      d: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {
                                "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                                "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                                "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.FactCheckOutput.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.MissingQuestions.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                                "lightudq.schemas.DocumentProfile.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                  { tf: 1 },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          l: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  "[": {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {},
                          df: 0,
                          h: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              u: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: {},
                                  df: 0,
                                  q: {
                                    docs: {
                                      "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              g: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {
                            "lightudq.schemas.DocumentQualityCheckResult.pii": {
                              tf: 1,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: { "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1 } },
                        df: 1,
                        s: {
                          docs: {
                            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          t: {
            docs: {},
            df: 0,
            y: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          a: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: {},
                            df: 0,
                            "[": {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  t: {
                                    docs: {
                                      "lightudq.schemas.InconsistentFacts.inconsistent_facts":
                                        { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          g: {
            docs: {},
            df: 0,
            e: {
              docs: {
                "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
                  tf: 1.4142135623730951,
                },
                "lightudq.schemas.PIIPresence.count": { tf: 1.4142135623730951 },
                "lightudq.schemas.DocumentProfile.wordCount": {
                  tf: 1.4142135623730951,
                },
              },
              df: 3,
            },
          },
          f: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        p: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.InconsistentFacts.metadata": {
                                    tf: 1,
                                  },
                                },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          b: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                l: {
                  docs: { "lightudq.schemas.PIIPresence.present": { tf: 1 } },
                  df: 1,
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.schemas.DocumentQualityCheckResult.inconsistency":
                                                { tf: 1 },
                                              "lightudq.schemas.DocumentQualityCheckResult.inaccuracy":
                                                { tf: 1 },
                                            },
                                            df: 2,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.schemas.DocumentQualityCheckResult.pii": {
                                    tf: 1,
                                  },
                                },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        s: {
                                          docs: {
                                            "lightudq.schemas.DocumentQualityCheckResult.incompleteness":
                                              { tf: 1 },
                                          },
                                          df: 1,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
      default_value: {
        root: {
          1: {
            0: {
              0: {
                docs: {
                  "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                  "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                },
                df: 2,
              },
              docs: {},
              df: 0,
            },
            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 } },
            df: 1,
          },
          2: {
            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 } },
            df: 1,
          },
          3: {
            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 } },
            df: 1,
          },
          5: { docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } }, df: 1 },
          docs: {
            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1.4142135623730951 },
            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1.4142135623730951 },
            "lightudq.prompts.SUMMARY_PROMPT": { tf: 1.4142135623730951 },
            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
            "lightudq.schemas.QnAPair.model_config": { tf: 1 },
            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
            "lightudq.schemas.FactCompare.model_config": { tf: 1 },
            "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
            "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
            "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
            "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
            "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
            "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
          },
          df: 15,
          x: {
            2: {
              7: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                  "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.prompts.SUMMARY_PROMPT": { tf: 1.4142135623730951 },
                  "lightudq.schemas.ReasoningMixin.reasoning": {
                    tf: 1.4142135623730951,
                  },
                },
                df: 6,
              },
              docs: {},
              df: 0,
            },
            docs: {},
            df: 0,
          },
          y: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              u: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
                },
                df: 2,
                r: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 2.449489742783178 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                  },
                  df: 2,
                },
              },
            },
          },
          a: {
            docs: {
              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 4.358898943540674 },
            },
            df: 2,
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                },
                df: 2,
              },
            },
            n: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.3166247903554 },
              },
              df: 2,
              a: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  y: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                              tf: 1.4142135623730951,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                    z: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                        df: 1,
                        ":": {
                          docs: {},
                          df: 0,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                          tf: 2.449489742783178,
                        },
                        "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                      },
                      df: 2,
                      s: {
                        docs: {
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                          "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                        },
                        df: 2,
                      },
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {
                            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              d: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.6457513110645907 },
                },
                df: 2,
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
              y: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                    tf: 1.4142135623730951,
                  },
                },
                df: 4,
              },
              n: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {
                                "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            d: {
              docs: {},
              df: 0,
              v: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              d: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            s: { docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } }, df: 1 },
            c: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          s: {
                            docs: {},
                            df: 0,
                            h: {
                              docs: {
                                "lightudq.prompts.FACT_CHECK_PROMPT": {
                                  tf: 1.4142135623730951,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            p: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.3166247903554 },
                    },
                    df: 1,
                  },
                },
              },
            },
            f: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          t: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              x: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
            },
            o: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 2.8284271247461903 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
              },
              df: 3,
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 3.872983346207417 },
                  "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 2.23606797749979 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 5.477225575051661 },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                  "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                },
                df: 6,
                i: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
                  },
                  df: 2,
                },
                n: { docs: { "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 } }, df: 1 },
              },
              o: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {},
                        df: 0,
                        h: {
                          docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                s: {
                  docs: {
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                    "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                    "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                  },
                  df: 3,
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                k: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 2,
                  "\\": {
                    docs: {},
                    df: 0,
                    n: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            w: {
              docs: {},
              df: 0,
              o: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
            },
          },
          s: {
            docs: {},
            df: 0,
            y: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                f: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
              t: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
            },
            c: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                          tf: 1.7320508075688772,
                        },
                        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                          tf: 1.7320508075688772,
                        },
                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 4,
                      "}": {
                        docs: {},
                        df: 0,
                        "\\": {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                              "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                            },
                            df: 4,
                          },
                        },
                      },
                      ":": {
                        docs: {},
                        df: 0,
                        "\\": {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {
                              "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        "lightudq.prompts.FACT_CHECK_PROMPT": {
                          tf: 1.7320508075688772,
                        },
                        "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                      },
                      df: 3,
                    },
                  },
                },
              },
            },
            t: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        y: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
                u: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                            },
                            df: 2,
                          },
                        },
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    ":": {
                      docs: {},
                      df: 0,
                      "\\": {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              1: {
                                docs: {
                                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                                },
                                df: 1,
                              },
                              docs: {},
                              df: 0,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            p: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    f: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.FACT_CHECK_PROMPT": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 2,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                e: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
              },
            },
            l: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                m: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        z: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: { "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          d: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
                c: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      b: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                          d: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                      p: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          i: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {
                                  "lightudq.schemas.ReasoningMixin.reasoning": {
                                    tf: 1,
                                  },
                                },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.prompts.FACT_CHECK_PROMPT": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
              },
              df: 2,
              c: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                              tf: 2.23606797749979,
                            },
                            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 2 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": {
                              tf: 3.7416573867739413,
                            },
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                              tf: 1.7320508075688772,
                            },
                            "lightudq.prompts.SUMMARY_PROMPT": { tf: 2 },
                          },
                          df: 5,
                          s: {
                            docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  d: {
                                    docs: {
                                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                              "\\": {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  r: {
                                    docs: {},
                                    df: 0,
                                    e: {
                                      docs: {},
                                      df: 0,
                                      m: {
                                        docs: {},
                                        df: 0,
                                        e: {
                                          docs: {},
                                          df: 0,
                                          m: {
                                            docs: {},
                                            df: 0,
                                            b: {
                                              docs: {},
                                              df: 0,
                                              e: {
                                                docs: {},
                                                df: 0,
                                                r: {
                                                  docs: {},
                                                  df: 0,
                                                  ":": {
                                                    docs: {},
                                                    df: 0,
                                                    "\\": {
                                                      docs: {},
                                                      df: 0,
                                                      n: {
                                                        docs: {
                                                          "lightudq.prompts.FACT_CHECK_PROMPT":
                                                            { tf: 1 },
                                                        },
                                                        df: 1,
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          ":": {
                            docs: {},
                            df: 0,
                            "\\": {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                "\\": {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              u: {
                docs: {},
                df: 0,
                b: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                      },
                      df: 2,
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        y: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                          },
                          df: 2,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              c: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      r: {
                                        docs: {},
                                        df: 0,
                                        a: {
                                          docs: {},
                                          df: 0,
                                          d: {
                                            docs: {},
                                            df: 0,
                                            i: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                t: {
                                                  docs: {},
                                                  df: 0,
                                                  s: {
                                                    docs: {
                                                      "lightudq.prompts.FACT_CHECK_PROMPT":
                                                        { tf: 1 },
                                                    },
                                                    df: 1,
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {
                              "lightudq.prompts.FACT_CHECK_PROMPT": {
                                tf: 1.7320508075688772,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          e: {
            docs: {},
            df: 0,
            x: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
                    },
                    df: 1,
                    c: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              p: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                h: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 2,
                },
              },
              t: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                    },
                    df: 1,
                  },
                },
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          k: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              y: {
                docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                df: 1,
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        f: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              m: {
                                docs: {},
                                df: 0,
                                a: {
                                  docs: {},
                                  df: 0,
                                  t: {
                                    docs: {},
                                    df: 0,
                                    i: {
                                      docs: {},
                                      df: 0,
                                      o: {
                                        docs: {},
                                        df: 0,
                                        n: {
                                          docs: {
                                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                                              tf: 1,
                                            },
                                          },
                                          df: 1,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            n: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          f: {
            docs: {},
            df: 0,
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                m: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
              u: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.1622776601683795 },
                    },
                    df: 1,
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
                  "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                },
                df: 2,
                m: {
                  docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                  df: 1,
                  a: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.prompts.FACT_CHECK_PROMPT": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 2,
                    },
                  },
                },
              },
              l: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    w: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                              "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                            },
                            df: 4,
                            "\\": {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                s: {
                                  docs: {},
                                  df: 0,
                                  c: {
                                    docs: {},
                                    df: 0,
                                    h: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {},
                                        df: 0,
                                        m: {
                                          docs: {},
                                          df: 0,
                                          a: {
                                            docs: {},
                                            df: 0,
                                            ":": {
                                              docs: {},
                                              df: 0,
                                              "\\": {
                                                docs: {},
                                                df: 0,
                                                n: {
                                                  docs: {},
                                                  df: 0,
                                                  "\\": {
                                                    docs: {},
                                                    df: 0,
                                                    n: {
                                                      docs: {
                                                        "lightudq.prompts.QNA_EXTRACT_PROMPT":
                                                          { tf: 1 },
                                                      },
                                                      df: 1,
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  y: {
                    docs: {
                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                    },
                    df: 1,
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                    },
                    df: 2,
                    i: {
                      docs: {},
                      df: 0,
                      z: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: {
                                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                              },
                              df: 2,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        f: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {
                              "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.872983346207417 },
                  },
                  df: 1,
                  s: {
                    docs: {
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                    },
                    df: 1,
                    ":": {
                      docs: {},
                      df: 0,
                      "\\": {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {
                            "lightudq.prompts.FACT_CHECK_PROMPT": {
                              tf: 1.4142135623730951,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              l: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 2.23606797749979 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.872983346207417 },
                "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
              },
              df: 3,
              f: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          i: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {
                                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                  "lightudq.prompts.FACT_CHECK_PROMPT": {
                                    tf: 1.7320508075688772,
                                  },
                                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                                    tf: 1,
                                  },
                                },
                                df: 3,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                o: {
                  docs: {
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
            },
            s: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 4.242640687119285 },
              },
              df: 2,
            },
            f: {
              docs: {
                "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1.4142135623730951 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.8284271247461903 },
                "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
              },
              df: 3,
            },
            g: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {
                        "lightudq.prompts.FACT_CHECK_PROMPT": {
                          tf: 1.7320508075688772,
                        },
                      },
                      df: 1,
                      d: {
                        docs: {
                          "lightudq.prompts.FACT_CHECK_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            t: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 } }, df: 1 },
            d: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      f: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            b: {
                              docs: {},
                              df: 0,
                              l: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {
                                    "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                                      tf: 1,
                                    },
                                  },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          o: {
            docs: {},
            df: 0,
            f: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
              },
              df: 3,
            },
            n: {
              docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
              df: 1,
              l: {
                docs: {},
                df: 0,
                y: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
              },
            },
            r: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
              },
              df: 4,
              i: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                              tf: 1.4142135623730951,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                          tf: 2.449489742783178,
                        },
                        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                          tf: 1.7320508075688772,
                        },
                        "lightudq.prompts.FACT_CHECK_PROMPT": {
                          tf: 2.8284271247461903,
                        },
                        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 2 },
                      },
                      df: 4,
                      "\\": {
                        docs: {},
                        df: 0,
                        n: {
                          2: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                          docs: {},
                          df: 0,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              3: {
                                docs: {
                                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                                },
                                df: 1,
                              },
                              docs: {},
                              df: 0,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            b: {
              docs: {},
              df: 0,
              j: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                              tf: 2.449489742783178,
                            },
                          },
                          df: 1,
                          s: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 2 },
                            },
                            df: 2,
                          },
                        },
                      },
                    },
                  },
                },
              },
              o: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 4.898979485566356 },
                  },
                  df: 1,
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                r: {
                  docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                  df: 1,
                  s: {
                    docs: {
                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                    },
                    df: 1,
                  },
                  "\\": {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        h: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              l: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: {
                                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                  },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.prompts.FACT_CHECK_PROMPT": {
                            tf: 1.7320508075688772,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              o: {
                docs: {},
                df: 0,
                v: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {
                            "lightudq.prompts.FACT_CHECK_PROMPT": {
                              tf: 1.4142135623730951,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
                d: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        ":": {
                          docs: {},
                          df: 0,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
                c: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.prompts.FACT_CHECK_PROMPT": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              i: {
                docs: { "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 } },
                df: 1,
              },
            },
          },
          g: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              v: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {
                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
            },
            t: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 2 },
                "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 2.449489742783178 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.449489742783178 },
                "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 2 },
                "lightudq.prompts.SUMMARY_PROMPT": { tf: 1.4142135623730951 },
              },
              df: 5,
            },
          },
          c: {
            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 } },
            df: 1,
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  f: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          y: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                            },
                            df: 2,
                          },
                        },
                      },
                    },
                  },
                },
              },
              p: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.prompts.FACT_CHECK_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              n: {
                docs: {
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                },
                df: 1,
              },
            },
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            d: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  g: {
                                    docs: {
                                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                    },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 1,
                          },
                        },
                        s: {
                          docs: {
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {
                                  "lightudq.prompts.FACT_CHECK_PROMPT": {
                                    tf: 1.4142135623730951,
                                  },
                                },
                                df: 1,
                              },
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                                    },
                                    df: 1,
                                    "\\": {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        "\\": {
                                          docs: {},
                                          df: 0,
                                          n: {
                                            docs: {},
                                            df: 0,
                                            f: {
                                              docs: {},
                                              df: 0,
                                              a: {
                                                docs: {},
                                                df: 0,
                                                c: {
                                                  docs: {},
                                                  df: 0,
                                                  t: {
                                                    docs: {
                                                      "lightudq.prompts.FACT_CHECK_PROMPT":
                                                        { tf: 2.23606797749979 },
                                                    },
                                                    df: 1,
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                              e: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: {
                                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                                  },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            d: {
                              docs: {
                                "lightudq.prompts.FACT_CHECK_PROMPT": {
                                  tf: 1.4142135623730951,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        u: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                    r: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      h: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            s: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                b: {
                                  docs: {},
                                  df: 0,
                                  l: {
                                    docs: {},
                                    df: 0,
                                    e: {
                                      docs: {
                                        "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                                          tf: 1.4142135623730951,
                                        },
                                      },
                                      df: 1,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: {
                                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  k: {
                    docs: {
                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                      "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                      "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                    },
                    df: 4,
                    e: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                    ":": {
                      docs: {},
                      df: 0,
                      "\\": {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
          },
          u: {
            docs: {},
            df: 0,
            p: { docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } }, df: 1 },
            n: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    "[": {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {
                              "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            s: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: { "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
          },
          b: {
            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 } },
            df: 1,
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
              c: {
                docs: {},
                df: 0,
                k: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
            },
            e: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.1622776601683795 },
                "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
              },
              df: 3,
              f: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {
                        "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                      },
                      df: 2,
                    },
                  },
                },
              },
            },
            y: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.8284271247461903 },
              },
              df: 3,
            },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          n: {
            2: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
            docs: {
              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1.7320508075688772 },
              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.8284271247461903 },
              "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1.4142135623730951 },
            },
            df: 4,
            "\\": {
              docs: {},
              df: 0,
              n: {
                docs: { "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 } },
                df: 1,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
                t: {
                  docs: {},
                  df: 0,
                  h: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
                a: {
                  docs: {},
                  df: 0,
                  f: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                          df: 1,
                        },
                      },
                    },
                  },
                },
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        m: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            m: {
                              docs: {},
                              df: 0,
                              b: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  r: {
                                    docs: {},
                                    df: 0,
                                    ":": {
                                      docs: {},
                                      df: 0,
                                      "\\": {
                                        docs: {},
                                        df: 0,
                                        n: {
                                          docs: {
                                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                                              tf: 1,
                                            },
                                          },
                                          df: 1,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                o: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        u: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {
                              "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
                h: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.prompts.FACT_CHECK_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
                p: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  x: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        p: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                ":": {
                                  docs: {},
                                  df: 0,
                                  "\\": {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {},
                                      df: 0,
                                      f: {
                                        docs: {},
                                        df: 0,
                                        a: {
                                          docs: {},
                                          df: 0,
                                          c: {
                                            docs: {},
                                            df: 0,
                                            t: {
                                              docs: {
                                                "lightudq.prompts.FACT_CHECK_PROMPT": {
                                                  tf: 1,
                                                },
                                              },
                                              df: 1,
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              r: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {
                                    "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                                      tf: 1,
                                    },
                                  },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                d: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: { "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            "{": {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              "}": {
                                docs: {},
                                df: 0,
                                "\\": {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                                      "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                                        tf: 1,
                                      },
                                      "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                                      "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                                        tf: 1,
                                      },
                                    },
                                    df: 4,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              o: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 4,
                        },
                      },
                    },
                  },
                },
              },
              q: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                "}": {
                                  docs: {},
                                  df: 0,
                                  "\\": {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {
                                        "lightudq.prompts.MISSING_QUESTIONS_PROMPT": {
                                          tf: 1,
                                        },
                                      },
                                      df: 1,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        "}": {
                          docs: {},
                          df: 0,
                          "\\": {
                            docs: {},
                            df: 0,
                            n: {
                              docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                d: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.23606797749979 },
                "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
              },
              df: 2,
              t: {
                docs: {
                  "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                  "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                  "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 3.1622776601683795 },
                  "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                },
                df: 4,
                e: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                e: {
                  docs: { "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 } },
                  df: 1,
                  t: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
            d: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {
                              "lightudq.prompts.FACT_CHECK_PROMPT": {
                                tf: 2.449489742783178,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.prompts.FACT_CHECK_PROMPT": {
                            tf: 2.449489742783178,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                d: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                  },
                  df: 2,
                },
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {
                              "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                              "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                              "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                              "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                            },
                            df: 4,
                          },
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                    df: 1,
                    "\\": {
                      docs: {},
                      df: 0,
                      n: {
                        docs: { "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 } },
                        df: 1,
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
              q: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {
                            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              u: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
              },
            },
          },
          l: {
            docs: {},
            df: 0,
            t: {
              docs: {
                "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 2 },
                "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 2.449489742783178 },
                "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2.449489742783178 },
                "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 2 },
                "lightudq.prompts.SUMMARY_PROMPT": { tf: 1.4142135623730951 },
              },
              df: 5,
            },
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 2,
                },
              },
              m: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {
                          "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
          },
          w: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: { "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 } },
                  df: 1,
                  o: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              y: {
                docs: {},
                df: 0,
                "\\": {
                  docs: {},
                  df: 0,
                  n: {
                    docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                    df: 1,
                  },
                },
                s: {
                  docs: {
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.4142135623730951 },
                  },
                  df: 1,
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                d: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {
                      "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 },
                      "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
            },
          },
          j: {
            docs: {},
            df: 0,
            s: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                n: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 2 },
                    "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1 },
                  },
                  df: 3,
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: { "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1 } },
                  df: 1,
                  i: {
                    docs: {},
                    df: 0,
                    f: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.schemas.ReasoningMixin.reasoning": {
                                        tf: 1,
                                      },
                                    },
                                    df: 1,
                                    s: {
                                      docs: {
                                        "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 },
                                        "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": {
                                          tf: 1,
                                        },
                                      },
                                      df: 2,
                                      "\\": {
                                        docs: {},
                                        df: 0,
                                        n: {
                                          docs: {
                                            "lightudq.prompts.QNA_EXTRACT_PROMPT": {
                                              tf: 1,
                                            },
                                          },
                                          df: 1,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1 },
                    "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
                  },
                  df: 2,
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                e: { docs: { "lightudq.prompts.SUMMARY_PROMPT": { tf: 1 } }, df: 1 },
              },
            },
          },
          v: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  f: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } },
                      df: 1,
                    },
                  },
                },
              },
            },
          },
          h: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                e: { docs: { "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1 } }, df: 1 },
              },
            },
          },
        },
      },
      signature: {
        root: {
          3: {
            9: {
              docs: {
                "lightudq.document_quality.DocumentQuality.__init__": {
                  tf: 1.4142135623730951,
                },
              },
              df: 1,
            },
            docs: {},
            df: 0,
          },
          4: {
            docs: {},
            df: 0,
            o: {
              docs: { "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 } },
              df: 1,
            },
          },
          docs: {
            "lightudq.document_quality.DocumentQuality.__init__": {
              tf: 5.291502622129181,
            },
            "lightudq.document_quality.DocumentQuality.run": { tf: 4.47213595499958 },
            "lightudq.document_quality.DocumentQuality.compare": {
              tf: 6.164414002968976,
            },
            "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
              tf: 10.488088481701515,
            },
            "lightudq.document_quality.DocumentQuality.extract_qna": {
              tf: 4.47213595499958,
            },
            "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
              tf: 5.744562646538029,
            },
            "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
              tf: 5.744562646538029,
            },
            "lightudq.document_quality.DocumentQuality.pii_presence_check": {
              tf: 4.47213595499958,
            },
            "lightudq.document_quality.DocumentQuality.get_word_count": {
              tf: 3.4641016151377544,
            },
            "lightudq.document_quality.DocumentQuality.get_doc_summary": {
              tf: 3.4641016151377544,
            },
            "lightudq.document_quality.DocumentQuality.get_custom_metric": {
              tf: 5.291502622129181,
            },
            "lightudq.document_quality.DocumentQuality.get_document_profile": {
              tf: 4.47213595499958,
            },
            "lightudq.utils.read_markdown_to_text": { tf: 4 },
            "lightudq.utils.read_pdf_to_text": { tf: 4 },
            "lightudq.utils.read_document": { tf: 4 },
          },
          df: 15,
          f: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                    "lightudq.utils.read_document": { tf: 1 },
                  },
                  df: 4,
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                        tf: 1,
                      },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                    "lightudq.utils.read_markdown_to_text": { tf: 1 },
                    "lightudq.utils.read_pdf_to_text": { tf: 1 },
                    "lightudq.utils.read_document": { tf: 1 },
                  },
                  df: 4,
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
                m: {
                  docs: {},
                  df: 0,
                  p: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            y: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                    { tf: 1 },
                                  "lightudq.document_quality.DocumentQuality.pii_presence_check":
                                    { tf: 1 },
                                },
                                df: 2,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          s: {
            docs: {},
            df: 0,
            t: {
              docs: {},
              df: 0,
              r: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.__init__": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                    tf: 1.7320508075688772,
                  },
                  "lightudq.utils.read_markdown_to_text": { tf: 1.4142135623730951 },
                  "lightudq.utils.read_pdf_to_text": { tf: 1.4142135623730951 },
                  "lightudq.utils.read_document": { tf: 1.4142135623730951 },
                },
                df: 9,
              },
            },
            e: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                f: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                    "lightudq.document_quality.DocumentQuality.compare": { tf: 1 },
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                    "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.get_word_count": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.get_document_profile": {
                      tf: 1,
                    },
                  },
                  df: 11,
                },
              },
            },
            c: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 1,
                      s: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                            { tf: 2 },
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.pii_presence_check":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1 },
                        },
                        df: 8,
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                        { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
            },
            s: {
              docs: {},
              df: 0,
              g: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                },
                df: 1,
              },
            },
            a: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                n: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        s: {
                                          docs: {
                                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                              { tf: 1 },
                                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                              { tf: 1 },
                                          },
                                          df: 2,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          n: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                  },
                  df: 1,
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
          },
          o: {
            docs: {},
            df: 0,
            p: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      ":": {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {},
                          df: 0,
                          p: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.__init__": {
                                  tf: 1,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                          { tf: 1 },
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 2,
                    },
                  },
                },
              },
            },
          },
          l: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              g: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.compare": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 2 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1 },
                          },
                          df: 8,
                        },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                      tf: 1,
                    },
                  },
                  df: 2,
                },
              },
            },
          },
          d: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          q: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      y: {
                                        docs: {},
                                        df: 0,
                                        c: {
                                          docs: {},
                                          df: 0,
                                          h: {
                                            docs: {},
                                            df: 0,
                                            e: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                k: {
                                                  docs: {},
                                                  df: 0,
                                                  r: {
                                                    docs: {},
                                                    df: 0,
                                                    e: {
                                                      docs: {},
                                                      df: 0,
                                                      s: {
                                                        docs: {},
                                                        df: 0,
                                                        u: {
                                                          docs: {},
                                                          df: 0,
                                                          l: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {
                                                                "lightudq.document_quality.DocumentQuality.run":
                                                                  { tf: 1 },
                                                                "lightudq.document_quality.DocumentQuality.compare":
                                                                  { tf: 1 },
                                                              },
                                                              df: 2,
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          p: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                f: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {
                                          "lightudq.document_quality.DocumentQuality.compare":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                                            { tf: 1 },
                                        },
                                        df: 2,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              f: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.document_quality.DocumentQuality.compare": {
                                tf: 1,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          t: {
            docs: {},
            df: 0,
            y: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
          },
          b: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {
                              "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          u: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                        { tf: 1 },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                                { tf: 1 },
                                              "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                                { tf: 1 },
                                            },
                                            df: 2,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                },
                df: 1,
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          s: {
                            docs: {
                              "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                { tf: 1 },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
      bases: {
        root: {
          docs: {},
          df: 0,
          p: {
            docs: {},
            df: 0,
            y: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 8,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                n: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 8,
                },
              },
            },
          },
          b: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 8,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {},
                            df: 0,
                            m: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                x: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    n: {
                                      docs: {
                                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                                      },
                                      df: 2,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.schemas.FactCheckOutput": {
                                                tf: 1,
                                              },
                                            },
                                            df: 1,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
      doc: {
        root: {
          0: {
            0: {
              0: { docs: { lightudq: { tf: 3.872983346207417 } }, df: 1 },
              docs: {},
              df: 0,
            },
            docs: {},
            df: 0,
          },
          1: {
            0: {
              0: { docs: { lightudq: { tf: 2.6457513110645907 } }, df: 1 },
              docs: { lightudq: { tf: 2.23606797749979 } },
              df: 1,
            },
            2: {
              0: { docs: { lightudq: { tf: 2.8284271247461903 } }, df: 1 },
              docs: { lightudq: { tf: 2.449489742783178 } },
              df: 1,
            },
            9: {
              7: { 0: { docs: { lightudq: { tf: 1 } }, df: 1 }, docs: {}, df: 0 },
              docs: {},
              df: 0,
            },
            docs: { lightudq: { tf: 1 } },
            df: 1,
          },
          2: {
            0: {
              1: {
                5: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                docs: {},
                df: 0,
              },
              5: { 7: { docs: { lightudq: { tf: 1 } }, df: 1 }, docs: {}, df: 0 },
              docs: {},
              df: 0,
            },
            3: { docs: { lightudq: { tf: 1 } }, df: 1 },
            docs: { lightudq: { tf: 2 } },
            df: 1,
          },
          3: {
            1: { 0: { docs: { lightudq: { tf: 1 } }, df: 1 }, docs: {}, df: 0 },
            9: { docs: { lightudq: { tf: 11.489125293076057 } }, df: 1 },
            docs: {},
            df: 0,
          },
          4: {
            docs: {},
            df: 0,
            o: {
              docs: { "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 } },
              df: 1,
            },
          },
          docs: {
            lightudq: { tf: 21.587033144922902 },
            "lightudq.document_quality": { tf: 1.7320508075688772 },
            "lightudq.document_quality.DocumentQuality": { tf: 1.4142135623730951 },
            "lightudq.document_quality.DocumentQuality.__init__": {
              tf: 2.6457513110645907,
            },
            "lightudq.document_quality.DocumentQuality.file_path": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.document": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.profile": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.output": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.doc_profile": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.llm_client": {
              tf: 1.7320508075688772,
            },
            "lightudq.document_quality.DocumentQuality.run": { tf: 2.8284271247461903 },
            "lightudq.document_quality.DocumentQuality.compare": {
              tf: 3.7416573867739413,
            },
            "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
              tf: 3.4641016151377544,
            },
            "lightudq.document_quality.DocumentQuality.extract_qna": {
              tf: 2.449489742783178,
            },
            "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
              tf: 3.3166247903554,
            },
            "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
              tf: 3.3166247903554,
            },
            "lightudq.document_quality.DocumentQuality.pii_presence_check": {
              tf: 2.449489742783178,
            },
            "lightudq.document_quality.DocumentQuality.get_word_count": {
              tf: 2.449489742783178,
            },
            "lightudq.document_quality.DocumentQuality.get_doc_summary": {
              tf: 2.449489742783178,
            },
            "lightudq.document_quality.DocumentQuality.get_custom_metric": {
              tf: 1.4142135623730951,
            },
            "lightudq.document_quality.DocumentQuality.get_document_profile": {
              tf: 2.449489742783178,
            },
            "lightudq.prompts": { tf: 1.7320508075688772 },
            "lightudq.prompts.QNA_EXTRACT_PROMPT": { tf: 1.7320508075688772 },
            "lightudq.prompts.MISSING_QUESTIONS_PROMPT": { tf: 1.7320508075688772 },
            "lightudq.prompts.FACT_CHECK_PROMPT": { tf: 1.7320508075688772 },
            "lightudq.prompts.PII_PRESENCE_CHECK_PROMPT": { tf: 1.7320508075688772 },
            "lightudq.prompts.SUMMARY_PROMPT": { tf: 1.7320508075688772 },
            "lightudq.schemas": { tf: 1.7320508075688772 },
            "lightudq.schemas.ReasoningMixin": { tf: 1.7320508075688772 },
            "lightudq.schemas.ReasoningMixin.reasoning": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPair": { tf: 6.782329983125268 },
            "lightudq.schemas.QnAPair.question": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPair.answer": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPair.model_config": { tf: 2 },
            "lightudq.schemas.QnAPairs": { tf: 6.782329983125268 },
            "lightudq.schemas.QnAPairs.qna_pairs": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPairs.questions": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPairs.answers": { tf: 1.7320508075688772 },
            "lightudq.schemas.QnAPairs.model_config": { tf: 2 },
            "lightudq.schemas.FactCompare": { tf: 6.782329983125268 },
            "lightudq.schemas.FactCompare.original": { tf: 1.7320508075688772 },
            "lightudq.schemas.FactCompare.new": { tf: 1.7320508075688772 },
            "lightudq.schemas.FactCompare.model_config": { tf: 2 },
            "lightudq.schemas.InconsistentFacts": { tf: 6.782329983125268 },
            "lightudq.schemas.InconsistentFacts.inconsistent_facts": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.InconsistentFacts.metadata": { tf: 1.7320508075688772 },
            "lightudq.schemas.InconsistentFacts.model_config": { tf: 2 },
            "lightudq.schemas.FactCheckOutput": { tf: 6.782329983125268 },
            "lightudq.schemas.FactCheckOutput.source": { tf: 1.7320508075688772 },
            "lightudq.schemas.FactCheckOutput.target": { tf: 1.7320508075688772 },
            "lightudq.schemas.FactCheckOutput.model_config": { tf: 2 },
            "lightudq.schemas.MissingQuestions": { tf: 6.782329983125268 },
            "lightudq.schemas.MissingQuestions.questions": { tf: 1.7320508075688772 },
            "lightudq.schemas.MissingQuestions.model_config": { tf: 2 },
            "lightudq.schemas.PIIPresence": { tf: 6.782329983125268 },
            "lightudq.schemas.PIIPresence.present": { tf: 1.7320508075688772 },
            "lightudq.schemas.PIIPresence.metadata": { tf: 1.7320508075688772 },
            "lightudq.schemas.PIIPresence.count": { tf: 1.7320508075688772 },
            "lightudq.schemas.PIIPresence.model_config": { tf: 2 },
            "lightudq.schemas.DocumentProfile": { tf: 6.782329983125268 },
            "lightudq.schemas.DocumentProfile.title": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.wordCount": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.qnaPairs": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.summary": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.fileType": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.fileSize": { tf: 1.7320508075688772 },
            "lightudq.schemas.DocumentProfile.model_config": { tf: 2 },
            "lightudq.schemas.DocumentQualityCheckResult": { tf: 6.782329983125268 },
            "lightudq.schemas.DocumentQualityCheckResult.profile": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.DocumentQualityCheckResult.inconsistency": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.DocumentQualityCheckResult.pii": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.DocumentQualityCheckResult.incompleteness": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.DocumentQualityCheckResult.inaccuracy": {
              tf: 1.7320508075688772,
            },
            "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 2 },
            "lightudq.utils": { tf: 1.7320508075688772 },
            "lightudq.utils.read_markdown_to_text": { tf: 1.7320508075688772 },
            "lightudq.utils.read_pdf_to_text": { tf: 1.7320508075688772 },
            "lightudq.utils.read_document": { tf: 1.4142135623730951 },
          },
          df: 78,
          a: {
            docs: {
              lightudq: { tf: 3.7416573867739413 },
              "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
              "lightudq.document_quality.DocumentQuality.compare": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                tf: 1.7320508075688772,
              },
              "lightudq.document_quality.DocumentQuality.extract_qna": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                tf: 1,
              },
              "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
              "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                tf: 1.4142135623730951,
              },
              "lightudq.document_quality.DocumentQuality.get_document_profile": {
                tf: 1.4142135623730951,
              },
              "lightudq.schemas.QnAPair": { tf: 2.6457513110645907 },
              "lightudq.schemas.QnAPair.model_config": { tf: 1 },
              "lightudq.schemas.QnAPairs": { tf: 2.6457513110645907 },
              "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
              "lightudq.schemas.FactCompare": { tf: 2.6457513110645907 },
              "lightudq.schemas.FactCompare.model_config": { tf: 1 },
              "lightudq.schemas.InconsistentFacts": { tf: 2.6457513110645907 },
              "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
              "lightudq.schemas.FactCheckOutput": { tf: 2.6457513110645907 },
              "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
              "lightudq.schemas.MissingQuestions": { tf: 2.6457513110645907 },
              "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
              "lightudq.schemas.PIIPresence": { tf: 2.6457513110645907 },
              "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
              "lightudq.schemas.DocumentProfile": { tf: 2.6457513110645907 },
              "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
              "lightudq.schemas.DocumentQualityCheckResult": { tf: 2.6457513110645907 },
              "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
            },
            df: 30,
            s: {
              docs: { lightudq: { tf: 1.7320508075688772 } },
              df: 1,
              s: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            c: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                  },
                },
              },
              h: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    v: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
            },
            n: {
              docs: { lightudq: { tf: 1.4142135623730951 } },
              df: 1,
              d: {
                docs: {
                  lightudq: { tf: 4.795831523312719 },
                  "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.extract_qna": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1,
                  },
                  "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                  "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                  "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                  "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                  "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                  "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                  "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                  "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                  "lightudq.schemas.DocumentQualityCheckResult": {
                    tf: 1.7320508075688772,
                  },
                },
                df: 15,
              },
              a: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  y: {
                    docs: {},
                    df: 0,
                    z: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: { lightudq: { tf: 1 } },
                        df: 1,
                        d: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: { lightudq: { tf: 2.23606797749979 } },
                      df: 1,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1.4142135623730951 },
                          },
                          df: 2,
                        },
                      },
                      s: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
              y: {
                docs: {
                  lightudq: { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1,
                  },
                },
                df: 3,
              },
            },
            i: {
              docs: {
                lightudq: { tf: 4.69041575982343 },
                "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
              },
              df: 2,
            },
            d: {
              docs: {},
              df: 0,
              v: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                      },
                    },
                    t: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              d: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            l: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: { docs: { lightudq: { tf: 2.449489742783178 } }, df: 1 },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            t: {
              docs: { lightudq: { tf: 1.7320508075688772 } },
              df: 1,
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    b: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            s: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 2 },
                                "lightudq.schemas.QnAPairs": { tf: 2 },
                                "lightudq.schemas.FactCompare": { tf: 2 },
                                "lightudq.schemas.InconsistentFacts": { tf: 2 },
                                "lightudq.schemas.FactCheckOutput": { tf: 2 },
                                "lightudq.schemas.MissingQuestions": { tf: 2 },
                                "lightudq.schemas.PIIPresence": { tf: 2 },
                                "lightudq.schemas.DocumentProfile": { tf: 2 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 2,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            p: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        m: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              l: {
                docs: { lightudq: { tf: 1.7320508075688772 } },
                df: 1,
                o: {
                  docs: {},
                  df: 0,
                  w: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 9,
                    s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                  },
                },
              },
            },
            g: {
              docs: {},
              df: 0,
              g: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          v: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              l: {
                                docs: {},
                                df: 0,
                                y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1.4142135623730951 },
                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                            { tf: 1 },
                        },
                        df: 3,
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {
                  lightudq: { tf: 1.7320508075688772 },
                  "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                    tf: 1,
                  },
                  "lightudq.schemas.QnAPair": { tf: 1 },
                  "lightudq.schemas.QnAPairs": { tf: 1 },
                  "lightudq.schemas.FactCompare": { tf: 1 },
                  "lightudq.schemas.InconsistentFacts": { tf: 1 },
                  "lightudq.schemas.FactCheckOutput": { tf: 1 },
                  "lightudq.schemas.MissingQuestions": { tf: 1 },
                  "lightudq.schemas.PIIPresence": { tf: 1 },
                  "lightudq.schemas.DocumentProfile": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                },
                df: 11,
              },
              g: {
                docs: {},
                df: 0,
                s: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 10,
                },
              },
            },
            b: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {
                      lightudq: { tf: 1.4142135623730951 },
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 10,
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
              },
            },
            v: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      b: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.document_quality.DocumentQuality.__init__": {
                                tf: 1,
                              },
                            },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          p: {
            docs: {},
            df: 0,
            y: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  o: { docs: {}, df: 0, n: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
              d: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.compare": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1.4142135623730951 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 4.358898943540674 },
                            "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 4.358898943540674 },
                            "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 4.358898943540674 },
                            "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": {
                              tf: 4.358898943540674,
                            },
                            "lightudq.schemas.InconsistentFacts.model_config": {
                              tf: 1,
                            },
                            "lightudq.schemas.FactCheckOutput": {
                              tf: 4.358898943540674,
                            },
                            "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": {
                              tf: 4.358898943540674,
                            },
                            "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 4.358898943540674 },
                            "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": {
                              tf: 4.358898943540674,
                            },
                            "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": {
                              tf: 4.358898943540674,
                            },
                            "lightudq.schemas.DocumentQualityCheckResult.model_config":
                              { tf: 1 },
                          },
                          df: 27,
                        },
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                v: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: { lightudq: { tf: 1.4142135623730951 } },
                        df: 1,
                        s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                        d: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          lightudq: { tf: 2.23606797749979 },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 2,
                          },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1.4142135623730951 },
                        },
                        df: 3,
                      },
                    },
                    t: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: { docs: { lightudq: { tf: 2.23606797749979 } }, df: 1 },
                },
                m: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                v: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 2 },
                          "lightudq.schemas.QnAPairs": { tf: 2 },
                          "lightudq.schemas.FactCompare": { tf: 2 },
                          "lightudq.schemas.InconsistentFacts": { tf: 2 },
                          "lightudq.schemas.FactCheckOutput": { tf: 2 },
                          "lightudq.schemas.MissingQuestions": { tf: 2 },
                          "lightudq.schemas.PIIPresence": { tf: 2 },
                          "lightudq.schemas.DocumentProfile": { tf: 2 },
                          "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      c: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1.4142135623730951 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              i: {
                docs: {
                  lightudq: { tf: 1.4142135623730951 },
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1.7320508075688772,
                  },
                },
                df: 2,
                p: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {
                                  "lightudq.document_quality.DocumentQuality.pii_presence_check":
                                    { tf: 1 },
                                },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              p: { docs: { lightudq: { tf: 1 } }, df: 1 },
              o: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    e: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
            },
            d: {
              docs: {},
              df: 0,
              f: {
                docs: { lightudq: { tf: 1 } },
                df: 1,
                s: { docs: { lightudq: { tf: 1 } }, df: 1 },
              },
            },
            a: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.extract_qna": {
                        tf: 1,
                      },
                    },
                    df: 2,
                  },
                },
              },
              r: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          h: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              p: {
                                docs: {},
                                df: 0,
                                s: {
                                  docs: { lightudq: { tf: 1.4142135623730951 } },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                a: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        p: {
                          docs: {},
                          df: 0,
                          h: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                        },
                      },
                    },
                  },
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {},
                            df: 0,
                            s: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.compare": {
                                  tf: 1,
                                },
                                "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                  { tf: 1 },
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                              },
                              df: 13,
                            },
                          },
                        },
                      },
                    },
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                        { tf: 1 },
                    },
                    df: 1,
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                        "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                        "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                        "lightudq.schemas.InconsistentFacts": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                        "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                        "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentQualityCheckResult": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 9,
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {
                    lightudq: { tf: 1.4142135623730951 },
                    "lightudq.document_quality.DocumentQuality.__init__": {
                      tf: 1.4142135623730951,
                    },
                  },
                  df: 2,
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  h: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        a: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
                t: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                    "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                    "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1.4142135623730951 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                    "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                    "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                    "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                    "lightudq.schemas.DocumentQualityCheckResult": {
                      tf: 1.4142135623730951,
                    },
                  },
                  df: 9,
                },
              },
              i: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPairs": { tf: 1 },
                          "lightudq.schemas.FactCompare": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                          "lightudq.schemas.MissingQuestions": { tf: 1 },
                          "lightudq.schemas.PIIPresence": { tf: 1 },
                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
            },
          },
          l: {
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              b: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      y: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    },
                  },
                },
              },
              g: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        q: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                    "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                      tf: 1.4142135623730951,
                    },
                  },
                  df: 3,
                  "[": {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1 },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: { docs: { lightudq: { tf: 2 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              w: { docs: { lightudq: { tf: 1 } }, df: 1 },
            },
            e: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                d: {
                  docs: {},
                  df: 0,
                  e: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  e: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              m: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1.4142135623730951,
                  },
                },
                df: 2,
              },
            },
          },
          f: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {
                  lightudq: { tf: 2.8284271247461903 },
                  "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                    tf: 1,
                  },
                  "lightudq.schemas.QnAPair": { tf: 2.23606797749979 },
                  "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                  "lightudq.schemas.QnAPairs": { tf: 2.23606797749979 },
                  "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                  "lightudq.schemas.FactCompare": { tf: 2.23606797749979 },
                  "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                  "lightudq.schemas.InconsistentFacts": { tf: 2.23606797749979 },
                  "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                  "lightudq.schemas.FactCheckOutput": { tf: 2.23606797749979 },
                  "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                  "lightudq.schemas.MissingQuestions": { tf: 2.23606797749979 },
                  "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                  "lightudq.schemas.PIIPresence": { tf: 2.23606797749979 },
                  "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                  "lightudq.schemas.DocumentProfile": { tf: 2.23606797749979 },
                  "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult": {
                    tf: 2.23606797749979,
                  },
                  "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
                },
                df: 24,
                m: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        b: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              u: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                    },
                    df: 2,
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    lightudq: { tf: 1.4142135623730951 },
                    "lightudq.document_quality.DocumentQuality.__init__": {
                      tf: 1.4142135623730951,
                    },
                    "lightudq.utils.read_document": { tf: 1 },
                  },
                  df: 3,
                  s: {
                    docs: { lightudq: { tf: 1 } },
                    df: 1,
                    i: {
                      docs: {},
                      df: 0,
                      z: {
                        docs: {},
                        df: 0,
                        e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                  t: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              c: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 4 } }, df: 1 } },
              n: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          l: { docs: { lightudq: { tf: 2 } }, df: 1 },
                        },
                      },
                      e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                    },
                  },
                  l: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
              r: {
                docs: {},
                df: 0,
                m: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              },
              g: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: { lightudq: { tf: 1.4142135623730951 } },
                      df: 1,
                      s: { docs: { lightudq: { tf: 2 } }, df: 1 },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  a: { docs: {}, df: 0, l: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
              e: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                      "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                      "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1.4142135623730951 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                      "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                      "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                      "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                      "lightudq.schemas.DocumentQualityCheckResult": {
                        tf: 1.4142135623730951,
                      },
                    },
                    df: 9,
                    s: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 2.6457513110645907 },
                        "lightudq.schemas.QnAPairs": { tf: 2.6457513110645907 },
                        "lightudq.schemas.FactCompare": { tf: 2.6457513110645907 },
                        "lightudq.schemas.InconsistentFacts": {
                          tf: 2.6457513110645907,
                        },
                        "lightudq.schemas.FactCheckOutput": { tf: 2.6457513110645907 },
                        "lightudq.schemas.MissingQuestions": { tf: 2.6457513110645907 },
                        "lightudq.schemas.PIIPresence": { tf: 2.6457513110645907 },
                        "lightudq.schemas.DocumentProfile": { tf: 2.6457513110645907 },
                        "lightudq.schemas.DocumentQualityCheckResult": {
                          tf: 2.6457513110645907,
                        },
                      },
                      df: 9,
                    },
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        f: {
                          docs: {},
                          df: 0,
                          o: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                            "`": {
                              docs: {},
                              df: 0,
                              "]": {
                                docs: {},
                                df: 0,
                                "[": {
                                  docs: {},
                                  df: 0,
                                  p: {
                                    docs: {},
                                    df: 0,
                                    y: {
                                      docs: {},
                                      df: 0,
                                      d: {
                                        docs: {},
                                        df: 0,
                                        a: {
                                          docs: {},
                                          df: 0,
                                          n: {
                                            docs: {},
                                            df: 0,
                                            t: {
                                              docs: {},
                                              df: 0,
                                              i: {
                                                docs: {},
                                                df: 0,
                                                c: {
                                                  docs: {
                                                    "lightudq.schemas.QnAPair": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.QnAPairs": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.FactCompare": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.InconsistentFacts":
                                                      { tf: 1 },
                                                    "lightudq.schemas.FactCheckOutput":
                                                      { tf: 1 },
                                                    "lightudq.schemas.MissingQuestions":
                                                      { tf: 1 },
                                                    "lightudq.schemas.PIIPresence": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.DocumentProfile":
                                                      { tf: 1 },
                                                    "lightudq.schemas.DocumentQualityCheckResult":
                                                      { tf: 1 },
                                                  },
                                                  df: 9,
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                m: {
                  docs: {
                    lightudq: { tf: 1.4142135623730951 },
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                    "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 12,
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  e: { docs: {}, df: 0, d: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
              n: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: { lightudq: { tf: 1.4142135623730951 } },
                  df: 1,
                  s: {
                    docs: {
                      lightudq: { tf: 1.7320508075688772 },
                      "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                        tf: 2,
                      },
                    },
                    df: 2,
                  },
                },
              },
            },
          },
          u: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: { lightudq: { tf: 1.4142135623730951 } },
                                  df: 1,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              d: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: { docs: { lightudq: { tf: 1 } }, df: 1 },
                  f: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            s: {
              docs: {},
              df: 0,
              e: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                },
                df: 1,
                d: {
                  docs: {
                    lightudq: { tf: 1 },
                    "lightudq.schemas.QnAPair": { tf: 2 },
                    "lightudq.schemas.QnAPairs": { tf: 2 },
                    "lightudq.schemas.FactCompare": { tf: 2 },
                    "lightudq.schemas.InconsistentFacts": { tf: 2 },
                    "lightudq.schemas.FactCheckOutput": { tf: 2 },
                    "lightudq.schemas.MissingQuestions": { tf: 2 },
                    "lightudq.schemas.PIIPresence": { tf: 2 },
                    "lightudq.schemas.DocumentProfile": { tf: 2 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                  },
                  df: 10,
                },
              },
              a: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 10,
                  },
                },
              },
            },
            t: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    z: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                      a: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          i: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              n: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          d: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                a: {
                  docs: {
                    lightudq: { tf: 1 },
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 10,
                },
                e: { docs: { lightudq: { tf: 1 } }, df: 1 },
              },
            },
            o: {
              docs: {},
              df: 0,
              c: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {
                            lightudq: { tf: 3.4641016151377544 },
                            "lightudq.document_quality.DocumentQuality": { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.__init__": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.run": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.document_quality.DocumentQuality.compare": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1.4142135623730951 },
                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                              { tf: 1.7320508075688772 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1.4142135623730951 },
                            "lightudq.document_quality.DocumentQuality.get_word_count":
                              { tf: 1.4142135623730951 },
                            "lightudq.document_quality.DocumentQuality.get_doc_summary":
                              { tf: 1.4142135623730951 },
                            "lightudq.document_quality.DocumentQuality.get_custom_metric":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.get_document_profile":
                              { tf: 1.4142135623730951 },
                            "lightudq.utils.read_document": { tf: 1 },
                          },
                          df: 14,
                          s: { docs: { lightudq: { tf: 2 } }, df: 1 },
                          q: {
                            docs: {},
                            df: 0,
                            u: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      y: {
                                        docs: {
                                          lightudq: { tf: 2.23606797749979 },
                                          "lightudq.document_quality.DocumentQuality.__init__":
                                            { tf: 1 },
                                        },
                                        df: 2,
                                        c: {
                                          docs: {},
                                          df: 0,
                                          h: {
                                            docs: {},
                                            df: 0,
                                            e: {
                                              docs: {},
                                              df: 0,
                                              c: {
                                                docs: {},
                                                df: 0,
                                                k: {
                                                  docs: {},
                                                  df: 0,
                                                  r: {
                                                    docs: {},
                                                    df: 0,
                                                    e: {
                                                      docs: {},
                                                      df: 0,
                                                      s: {
                                                        docs: {},
                                                        df: 0,
                                                        u: {
                                                          docs: {},
                                                          df: 0,
                                                          l: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {
                                                                "lightudq.document_quality.DocumentQuality.run":
                                                                  { tf: 1 },
                                                                "lightudq.document_quality.DocumentQuality.compare":
                                                                  { tf: 1 },
                                                              },
                                                              df: 2,
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          p: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                f: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {
                                          "lightudq.document_quality.DocumentQuality.compare":
                                            { tf: 1 },
                                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                                            { tf: 1 },
                                        },
                                        df: 2,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.schemas.QnAPair": { tf: 1 },
                                      "lightudq.schemas.QnAPairs": { tf: 1 },
                                      "lightudq.schemas.FactCompare": { tf: 1 },
                                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                                      "lightudq.schemas.PIIPresence": { tf: 1 },
                                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                                      "lightudq.schemas.DocumentQualityCheckResult": {
                                        tf: 1,
                                      },
                                    },
                                    df: 9,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                s: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
              },
            },
            q: { docs: { lightudq: { tf: 2.449489742783178 } }, df: 1 },
            e: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          i: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              n: { docs: { lightudq: { tf: 2 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              c: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    },
                  },
                },
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {},
                            df: 0,
                            s: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                                "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                                "lightudq.schemas.FactCompare": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.InconsistentFacts": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.FactCheckOutput": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.MissingQuestions": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.PIIPresence": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentProfile": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1.4142135623730951,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              v: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        m: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              t: {
                                docs: { lightudq: { tf: 1.4142135623730951 } },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                "/": {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        "/": {
                          docs: {},
                          df: 0,
                          m: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              d: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  l: {
                                    docs: {},
                                    df: 0,
                                    s: {
                                      docs: {},
                                      df: 0,
                                      "/": {
                                        docs: {},
                                        df: 0,
                                        b: {
                                          docs: {},
                                          df: 0,
                                          a: {
                                            docs: {},
                                            df: 0,
                                            s: {
                                              docs: {},
                                              df: 0,
                                              e: {
                                                docs: {},
                                                df: 0,
                                                "/": {
                                                  docs: {},
                                                  df: 0,
                                                  "#": {
                                                    docs: {},
                                                    df: 0,
                                                    p: {
                                                      docs: {},
                                                      df: 0,
                                                      y: {
                                                        docs: {},
                                                        df: 0,
                                                        d: {
                                                          docs: {},
                                                          df: 0,
                                                          a: {
                                                            docs: {},
                                                            df: 0,
                                                            n: {
                                                              docs: {},
                                                              df: 0,
                                                              t: {
                                                                docs: {},
                                                                df: 0,
                                                                i: {
                                                                  docs: {},
                                                                  df: 0,
                                                                  c: {
                                                                    docs: {
                                                                      "lightudq.document_quality.DocumentQuality.__init__":
                                                                        { tf: 1 },
                                                                    },
                                                                    df: 1,
                                                                  },
                                                                },
                                                              },
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.__init__": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                            { tf: 1 },
                        },
                        df: 2,
                      },
                    },
                  },
                },
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                          "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                          "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                          "lightudq.schemas.InconsistentFacts": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.FactCheckOutput": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.MissingQuestions": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                          "lightudq.schemas.DocumentProfile": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult": {
                            tf: 1.7320508075688772,
                          },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                v: {
                  docs: {},
                  df: 0,
                  e: { docs: {}, df: 0, n: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              f: {
                docs: {},
                df: 0,
                f: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              r: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  c: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
              c: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                                "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                                "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                                "lightudq.schemas.FactCompare": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.InconsistentFacts.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.FactCheckOutput": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.FactCheckOutput.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.MissingQuestions": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.MissingQuestions.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.PIIPresence": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.DocumentProfile.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1.7320508075688772,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                  { tf: 1 },
                              },
                              df: 18,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 9,
                },
              },
              r: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
          },
          q: {
            docs: {},
            df: 0,
            u: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      y: {
                        docs: {
                          lightudq: { tf: 1.7320508075688772 },
                          "lightudq.document_quality.DocumentQuality": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.run": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 4,
                      },
                    },
                  },
                },
              },
              o: {
                docs: {},
                df: 0,
                t: { docs: { lightudq: { tf: 6.324555320336759 } }, df: 1 },
              },
              e: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: { lightudq: { tf: 2.23606797749979 } },
                          df: 1,
                          s: {
                            docs: {
                              lightudq: { tf: 1.4142135623730951 },
                              "lightudq.document_quality.DocumentQuality.extract_qna": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                { tf: 2 },
                            },
                            df: 3,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            n: {
              docs: {},
              df: 0,
              a: {
                docs: { lightudq: { tf: 1 } },
                df: 1,
                p: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.extract_qna": {
                              tf: 1,
                            },
                          },
                          df: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          i: {
            docs: {},
            df: 0,
            t: {
              docs: { lightudq: { tf: 2 } },
              df: 1,
              s: { docs: { lightudq: { tf: 1 } }, df: 1 },
            },
            n: {
              docs: {
                lightudq: { tf: 4.47213595499958 },
                "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                "lightudq.schemas.QnAPair": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
              },
              df: 13,
              c: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                o: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                c: {
                                  docs: {},
                                  df: 0,
                                  y: {
                                    docs: { lightudq: { tf: 2.23606797749979 } },
                                    df: 1,
                                  },
                                },
                                t: {
                                  docs: {
                                    lightudq: { tf: 1.7320508075688772 },
                                    "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                      { tf: 1 },
                                  },
                                  df: 2,
                                  f: {
                                    docs: {},
                                    df: 0,
                                    a: {
                                      docs: {},
                                      df: 0,
                                      c: {
                                        docs: {},
                                        df: 0,
                                        t: {
                                          docs: {},
                                          df: 0,
                                          s: {
                                            docs: {
                                              "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                                { tf: 1 },
                                            },
                                            df: 1,
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  m: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  s: {
                                    docs: {},
                                    df: 0,
                                    s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                    e: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: { lightudq: { tf: 1 } },
                        df: 1,
                        a: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                n: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                    n: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 10,
                          s: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                              "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                              "lightudq.schemas.FactCompare": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.InconsistentFacts": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.FactCheckOutput": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.MissingQuestions": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.PIIPresence": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.DocumentProfile": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.DocumentQualityCheckResult": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 9,
                          },
                        },
                      },
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.schemas.QnAPair": { tf: 1 },
                                      "lightudq.schemas.QnAPairs": { tf: 1 },
                                      "lightudq.schemas.FactCompare": { tf: 1 },
                                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                                      "lightudq.schemas.PIIPresence": { tf: 1 },
                                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                                      "lightudq.schemas.DocumentQualityCheckResult": {
                                        tf: 1,
                                      },
                                    },
                                    df: 9,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  r: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                p: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPairs": { tf: 1 },
                          "lightudq.schemas.FactCompare": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                          "lightudq.schemas.MissingQuestions": { tf: 1 },
                          "lightudq.schemas.PIIPresence": { tf: 1 },
                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
              d: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        y: { docs: { lightudq: { tf: 2.23606797749979 } }, df: 1 },
                      },
                    },
                  },
                },
                i: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              v: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: { lightudq: { tf: 1 } },
                      df: 1,
                      m: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: { lightudq: { tf: 1.7320508075688772 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  v: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          v: {
                            docs: {},
                            df: 0,
                            e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                },
                df: 1,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          i: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: { lightudq: { tf: 1.4142135623730951 } },
                                df: 1,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 2.23606797749979 },
                    "lightudq.schemas.QnAPairs": { tf: 2.23606797749979 },
                    "lightudq.schemas.FactCompare": { tf: 2.23606797749979 },
                    "lightudq.schemas.InconsistentFacts": { tf: 2.23606797749979 },
                    "lightudq.schemas.FactCheckOutput": { tf: 2.23606797749979 },
                    "lightudq.schemas.MissingQuestions": { tf: 2.23606797749979 },
                    "lightudq.schemas.PIIPresence": { tf: 2.23606797749979 },
                    "lightudq.schemas.DocumentProfile": { tf: 2.23606797749979 },
                    "lightudq.schemas.DocumentQualityCheckResult": {
                      tf: 2.23606797749979,
                    },
                  },
                  df: 9,
                  i: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          z: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.__init__": {
                                  tf: 1,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            m: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    t: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                  },
                },
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          v: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            s: {
              docs: {
                lightudq: { tf: 3.872983346207417 },
                "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentQualityCheckResult": {
                  tf: 1.7320508075688772,
                },
              },
              df: 10,
            },
            f: {
              docs: {
                "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                  tf: 1,
                },
                "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                  tf: 1,
                },
                "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentQualityCheckResult": {
                  tf: 1.7320508075688772,
                },
              },
              df: 11,
            },
          },
          t: {
            docs: {},
            df: 0,
            o: {
              docs: {
                lightudq: { tf: 3 },
                "lightudq.document_quality.DocumentQuality.__init__": {
                  tf: 1.7320508075688772,
                },
                "lightudq.document_quality.DocumentQuality.compare": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                  tf: 1.7320508075688772,
                },
                "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                  tf: 1,
                },
                "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                  tf: 1,
                },
                "lightudq.schemas.QnAPair": { tf: 2 },
                "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 2 },
                "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 2 },
                "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 2 },
                "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 2 },
                "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 2 },
                "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 2 },
                "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 2 },
                "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
              },
              df: 24,
              o: {
                docs: {},
                df: 0,
                l: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              },
            },
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {
                  lightudq: { tf: 6.4031242374328485 },
                  "lightudq.document_quality.DocumentQuality": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.__init__": {
                    tf: 2.23606797749979,
                  },
                  "lightudq.document_quality.DocumentQuality.run": { tf: 2 },
                  "lightudq.document_quality.DocumentQuality.compare": {
                    tf: 2.23606797749979,
                  },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1.7320508075688772,
                  },
                  "lightudq.document_quality.DocumentQuality.extract_qna": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                    tf: 2.23606797749979,
                  },
                  "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                    tf: 2,
                  },
                  "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.get_word_count": {
                    tf: 1.7320508075688772,
                  },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.get_document_profile": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.schemas.QnAPair": { tf: 4.795831523312719 },
                  "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                  "lightudq.schemas.QnAPairs": { tf: 4.795831523312719 },
                  "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                  "lightudq.schemas.FactCompare": { tf: 4.795831523312719 },
                  "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                  "lightudq.schemas.InconsistentFacts": { tf: 4.795831523312719 },
                  "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                  "lightudq.schemas.FactCheckOutput": { tf: 4.795831523312719 },
                  "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                  "lightudq.schemas.MissingQuestions": { tf: 4.795831523312719 },
                  "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                  "lightudq.schemas.PIIPresence": { tf: 4.795831523312719 },
                  "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                  "lightudq.schemas.DocumentProfile": { tf: 4.795831523312719 },
                  "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult": {
                    tf: 4.795831523312719,
                  },
                  "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
                },
                df: 31,
                m: { docs: { lightudq: { tf: 1 } }, df: 1 },
                i: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {
                      lightudq: { tf: 1.7320508075688772 },
                      "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                      "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                      "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1.4142135623730951 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                      "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                      "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                      "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                      "lightudq.schemas.DocumentQualityCheckResult": {
                        tf: 1.4142135623730951,
                      },
                    },
                    df: 10,
                  },
                },
                r: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 10,
                  },
                },
                s: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 9,
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                s: {
                  docs: {
                    lightudq: { tf: 1 },
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 10,
                },
              },
              r: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {},
                      df: 0,
                      h: {
                        docs: { lightudq: { tf: 1 } },
                        df: 1,
                        o: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              x: {
                docs: {},
                df: 0,
                t: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                a: {
                  docs: {},
                  df: 0,
                  s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    "/": {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          c: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              c: {
                docs: {},
                df: 0,
                h: {
                  docs: { lightudq: { tf: 2.449489742783178 } },
                  df: 1,
                  n: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          g: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                m: { docs: { lightudq: { tf: 2.8284271247461903 } }, df: 1 },
              },
            },
            x: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 2 } }, df: 1 } },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                l: { docs: {}, df: 0, e: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              },
              m: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
            },
            w: { docs: {}, df: 0, o: { docs: { lightudq: { tf: 2 } }, df: 1 } },
            a: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    t: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                  },
                },
              },
            },
            r: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    f: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          m: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              u: { docs: {}, df: 0, e: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
            y: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  "[": {
                    docs: {},
                    df: 0,
                    b: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            m: {
                              docs: {},
                              df: 0,
                              o: {
                                docs: {},
                                df: 0,
                                d: {
                                  docs: {},
                                  df: 0,
                                  e: {
                                    docs: {},
                                    df: 0,
                                    l: {
                                      docs: {
                                        "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                                          { tf: 1 },
                                      },
                                      df: 1,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
          },
          e: {
            docs: {},
            df: 0,
            v: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                n: {
                  docs: { lightudq: { tf: 1 } },
                  df: 1,
                  t: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            m: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              p: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    y: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 2.449489742783178 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
            },
            x: {
              docs: {},
              df: 0,
              p: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              c: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  p: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            a: {
                              docs: {},
                              df: 0,
                              l: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                      "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                      "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                      "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                      "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                      "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                      "lightudq.schemas.DocumentQualityCheckResult": {
                        tf: 1.7320508075688772,
                      },
                    },
                    df: 9,
                    c: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                        },
                        df: 1,
                      },
                    },
                    "`": {
                      docs: {},
                      df: 0,
                      "]": {
                        docs: {},
                        df: 0,
                        "[": {
                          docs: {},
                          df: 0,
                          p: {
                            docs: {},
                            df: 0,
                            y: {
                              docs: {},
                              df: 0,
                              d: {
                                docs: {},
                                df: 0,
                                a: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {},
                                    df: 0,
                                    t: {
                                      docs: {},
                                      df: 0,
                                      i: {
                                        docs: {},
                                        df: 0,
                                        c: {
                                          docs: {
                                            "lightudq.schemas.QnAPair": { tf: 1 },
                                            "lightudq.schemas.QnAPairs": { tf: 1 },
                                            "lightudq.schemas.FactCompare": { tf: 1 },
                                            "lightudq.schemas.InconsistentFacts": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.FactCheckOutput": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.MissingQuestions": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.PIIPresence": { tf: 1 },
                                            "lightudq.schemas.DocumentProfile": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.DocumentQualityCheckResult":
                                              { tf: 1 },
                                          },
                                          df: 9,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: { "lightudq.utils.read_document": { tf: 1 } },
                            df: 1,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              s: { docs: {}, df: 0, y: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              r: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    e: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
            },
            n: {
              docs: {},
              df: 0,
              v: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        m: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                b: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            f: {
              docs: {},
              df: 0,
              f: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: {
                  docs: {},
                  df: 0,
                  e: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
          },
          o: {
            docs: {},
            df: 0,
            f: {
              docs: {
                lightudq: { tf: 4.69041575982343 },
                "lightudq.document_quality.DocumentQuality": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.compare": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.extract_qna": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                  tf: 1,
                },
                "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                  tf: 1.7320508075688772,
                },
                "lightudq.document_quality.DocumentQuality.get_word_count": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                  tf: 1.4142135623730951,
                },
                "lightudq.document_quality.DocumentQuality.get_document_profile": {
                  tf: 1.4142135623730951,
                },
                "lightudq.schemas.QnAPair": { tf: 3.605551275463989 },
                "lightudq.schemas.QnAPairs": { tf: 3.605551275463989 },
                "lightudq.schemas.FactCompare": { tf: 3.605551275463989 },
                "lightudq.schemas.InconsistentFacts": { tf: 3.605551275463989 },
                "lightudq.schemas.FactCheckOutput": { tf: 3.605551275463989 },
                "lightudq.schemas.MissingQuestions": { tf: 3.605551275463989 },
                "lightudq.schemas.PIIPresence": { tf: 3.605551275463989 },
                "lightudq.schemas.DocumentProfile": { tf: 3.605551275463989 },
                "lightudq.schemas.DocumentQualityCheckResult": {
                  tf: 3.605551275463989,
                },
              },
              df: 21,
            },
            v: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                r: {
                  docs: { lightudq: { tf: 1.4142135623730951 } },
                  df: 1,
                  s: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                  h: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        d: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            n: {
              docs: {
                lightudq: { tf: 1.4142135623730951 },
                "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                "lightudq.schemas.DocumentQualityCheckResult": {
                  tf: 1.7320508075688772,
                },
                "lightudq.utils.read_document": { tf: 1 },
              },
              df: 11,
              l: {
                docs: {},
                df: 0,
                y: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
              },
            },
            p: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                      e: {
                        docs: {},
                        df: 0,
                        s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
                n: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      ":": {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {},
                          df: 0,
                          p: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.__init__": {
                                  tf: 1,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        l: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
              },
            },
            t: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
            },
            r: {
              docs: {
                lightudq: { tf: 1.7320508075688772 },
                "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                  tf: 1,
                },
                "lightudq.schemas.QnAPair": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
              },
              df: 11,
              i: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                      },
                      df: 9,
                      a: {
                        docs: {},
                        df: 0,
                        l: { docs: { lightudq: { tf: 2.449489742783178 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                          { tf: 1.7320508075688772 },
                      },
                      df: 1,
                    },
                  },
                },
              },
            },
            b: {
              docs: {},
              df: 0,
              j: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  c: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                          "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                          "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                          "lightudq.schemas.InconsistentFacts": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.FactCheckOutput": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.MissingQuestions": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                          "lightudq.schemas.DocumentProfile": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
            },
          },
          c: {
            docs: {},
            df: 0,
            h: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  k: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                        tf: 1,
                      },
                      "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                        { tf: 1.4142135623730951 },
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                    },
                    df: 4,
                    s: {
                      docs: {
                        lightudq: { tf: 1 },
                        "lightudq.document_quality.DocumentQuality": { tf: 1 },
                        "lightudq.document_quality.DocumentQuality.run": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.document_quality.DocumentQuality.compare": { tf: 1 },
                        "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                          { tf: 1 },
                      },
                      df: 5,
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            c: {
                              docs: {},
                              df: 0,
                              y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                            t: {
                              docs: {
                                lightudq: { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                  { tf: 1 },
                              },
                              df: 2,
                            },
                          },
                        },
                      },
                    },
                  },
                },
                t: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: { docs: { lightudq: { tf: 1 } }, df: 1 },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: { lightudq: { tf: 1 } },
                        df: 1,
                        s: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 10,
                        },
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.run": {
                                  tf: 1,
                                },
                                "lightudq.document_quality.DocumentQuality.compare": {
                                  tf: 1,
                                },
                                "lightudq.document_quality.DocumentQuality.extract_qna":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.pii_presence_check":
                                  { tf: 1 },
                                "lightudq.document_quality.DocumentQuality.get_document_profile":
                                  { tf: 1 },
                                "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                                "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                                "lightudq.schemas.FactCompare": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.InconsistentFacts": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.FactCheckOutput": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.MissingQuestions": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.PIIPresence": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentProfile": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1.4142135623730951,
                                },
                              },
                              df: 16,
                            },
                          },
                        },
                      },
                    },
                  },
                  e: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          r: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                      t: { docs: { "lightudq.utils.read_document": { tf: 1 } }, df: 1 },
                    },
                  },
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {},
                                    df: 0,
                                    s: {
                                      docs: { lightudq: { tf: 1.4142135623730951 } },
                                      df: 1,
                                    },
                                  },
                                },
                                n: {
                                  docs: {},
                                  df: 0,
                                  g: {
                                    docs: { lightudq: { tf: 1.4142135623730951 } },
                                    df: 1,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                d: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        v: {
                          docs: {},
                          df: 0,
                          e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                c: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                f: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                          tf: 1,
                        },
                      },
                      df: 18,
                      d: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPair.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.QnAPairs.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.FactCompare.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.MissingQuestions.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.PIIPresence.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentProfile.model_config": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                  { tf: 1.4142135623730951 },
                              },
                              df: 18,
                            },
                          },
                        },
                      },
                      u: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {
                                      "lightudq.schemas.QnAPair.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.QnAPairs.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.FactCompare.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.InconsistentFacts.model_config":
                                        { tf: 1 },
                                      "lightudq.schemas.FactCheckOutput.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.MissingQuestions.model_config":
                                        { tf: 1 },
                                      "lightudq.schemas.PIIPresence.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.DocumentProfile.model_config": {
                                        tf: 1,
                                      },
                                      "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                        { tf: 1 },
                                    },
                                    df: 9,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                  o: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      m: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: {
                                "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                                "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                                "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.FactCheckOutput.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.MissingQuestions.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                                "lightudq.schemas.DocumentProfile.model_config": {
                                  tf: 1,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult.model_config":
                                  { tf: 1 },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                          n: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                          d: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                  a: {
                    docs: {},
                    df: 0,
                    n: { docs: {}, df: 0, y: { docs: { lightudq: { tf: 2 } }, df: 1 } },
                    c: {
                      docs: {},
                      df: 0,
                      t: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    },
                    r: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          lightudq: { tf: 1.4142135623730951 },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 2,
                      },
                    },
                  },
                  u: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                            "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                            "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                            "lightudq.schemas.InconsistentFacts": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.schemas.FactCheckOutput": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.schemas.MissingQuestions": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                            "lightudq.schemas.DocumentProfile": {
                              tf: 1.4142135623730951,
                            },
                            "lightudq.schemas.DocumentQualityCheckResult": {
                              tf: 1.4142135623730951,
                            },
                          },
                          df: 9,
                          f: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  d: {
                                    docs: {},
                                    df: 0,
                                    i: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        f: {
                                          docs: {},
                                          df: 0,
                                          o: {
                                            docs: {
                                              "lightudq.schemas.QnAPair": { tf: 1 },
                                              "lightudq.schemas.QnAPairs": { tf: 1 },
                                              "lightudq.schemas.FactCompare": { tf: 1 },
                                              "lightudq.schemas.InconsistentFacts": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.FactCheckOutput": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.MissingQuestions": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.PIIPresence": { tf: 1 },
                                              "lightudq.schemas.DocumentProfile": {
                                                tf: 1,
                                              },
                                              "lightudq.schemas.DocumentQualityCheckResult":
                                                { tf: 1 },
                                            },
                                            df: 9,
                                            "`": {
                                              docs: {},
                                              df: 0,
                                              "]": {
                                                docs: {},
                                                df: 0,
                                                "[": {
                                                  docs: {},
                                                  df: 0,
                                                  p: {
                                                    docs: {},
                                                    df: 0,
                                                    y: {
                                                      docs: {},
                                                      df: 0,
                                                      d: {
                                                        docs: {},
                                                        df: 0,
                                                        a: {
                                                          docs: {},
                                                          df: 0,
                                                          n: {
                                                            docs: {},
                                                            df: 0,
                                                            t: {
                                                              docs: {},
                                                              df: 0,
                                                              i: {
                                                                docs: {},
                                                                df: 0,
                                                                c: {
                                                                  docs: {
                                                                    "lightudq.schemas.QnAPair":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.QnAPairs":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.FactCompare":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.InconsistentFacts":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.FactCheckOutput":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.MissingQuestions":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.PIIPresence":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.DocumentProfile":
                                                                      { tf: 1 },
                                                                    "lightudq.schemas.DocumentQualityCheckResult":
                                                                      { tf: 1 },
                                                                  },
                                                                  df: 9,
                                                                },
                                                              },
                                                            },
                                                          },
                                                        },
                                                      },
                                                    },
                                                  },
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              r: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  u: {
                    docs: {},
                    df: 0,
                    p: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {},
                      df: 0,
                      p: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            d: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                n: {
                                  docs: {},
                                  df: 0,
                                  g: {
                                    docs: {
                                      "lightudq.schemas.QnAPair": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.QnAPairs": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.FactCompare": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.InconsistentFacts": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.FactCheckOutput": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.MissingQuestions": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.PIIPresence": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.DocumentProfile": {
                                        tf: 1.4142135623730951,
                                      },
                                      "lightudq.schemas.DocumentQualityCheckResult": {
                                        tf: 1.4142135623730951,
                                      },
                                    },
                                    df: 9,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                e: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 2 },
                    "lightudq.schemas.QnAPairs": { tf: 2 },
                    "lightudq.schemas.FactCompare": { tf: 2 },
                    "lightudq.schemas.InconsistentFacts": { tf: 2 },
                    "lightudq.schemas.FactCheckOutput": { tf: 2 },
                    "lightudq.schemas.MissingQuestions": { tf: 2 },
                    "lightudq.schemas.PIIPresence": { tf: 2 },
                    "lightudq.schemas.DocumentProfile": { tf: 2 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                  },
                  df: 9,
                },
              },
              l: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    b: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            t: {
                              docs: {},
                              df: 0,
                              i: {
                                docs: {},
                                df: 0,
                                o: {
                                  docs: {},
                                  df: 0,
                                  n: {
                                    docs: {},
                                    df: 0,
                                    s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              u: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                      "lightudq.document_quality.DocumentQuality.get_word_count": {
                        tf: 1,
                      },
                    },
                    df: 3,
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                t: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              },
            },
            a: { docs: {}, df: 0, n: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            i: {
              docs: {},
              df: 0,
              t: { docs: {}, df: 0, y: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
            f: {
              docs: {},
              df: 0,
              o: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
            },
            r: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {
                            lightudq: { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 10,
                        },
                      },
                    },
                  },
                },
              },
            },
            l: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: { lightudq: { tf: 1 } },
                    df: 1,
                    l: { docs: {}, df: 0, y: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                      "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                      "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                      "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                      "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                      "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                      "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                      "lightudq.schemas.DocumentQualityCheckResult": {
                        tf: 1.7320508075688772,
                      },
                    },
                    df: 10,
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                        "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                        "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                        "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                        "lightudq.schemas.InconsistentFacts": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                        "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                        "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentQualityCheckResult": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 10,
                    },
                  },
                },
              },
            },
          },
          b: {
            docs: {},
            df: 0,
            e: {
              docs: {
                lightudq: { tf: 1 },
                "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                "lightudq.schemas.QnAPair": { tf: 1 },
                "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 1 },
                "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 1 },
                "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 1 },
                "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 1 },
                "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 1 },
                "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult.model_config": { tf: 1 },
              },
              df: 20,
              e: {
                docs: {},
                df: 0,
                n: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
              },
              t: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    e: { docs: {}, df: 0, n: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  f: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              l: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
            y: {
              docs: {
                lightudq: { tf: 1.7320508075688772 },
                "lightudq.document_quality.DocumentQuality.__init__": { tf: 1 },
                "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                  tf: 1,
                },
                "lightudq.schemas.QnAPair": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
              },
              df: 12,
            },
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 9,
                  d: {
                    docs: {
                      lightudq: { tf: 1 },
                      "lightudq.utils.read_document": { tf: 1 },
                    },
                    df: 2,
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                g: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              t: { docs: { lightudq: { tf: 2 } }, df: 1 },
              i: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        g: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
              },
            },
            i: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                t: { docs: {}, df: 0, h: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              },
            },
          },
          s: {
            docs: { lightudq: { tf: 2 } },
            df: 1,
            u: {
              docs: {},
              df: 0,
              c: { docs: {}, df: 0, h: { docs: { lightudq: { tf: 1 } }, df: 1 } },
              p: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              m: {
                docs: {},
                df: 0,
                m: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      y: {
                        docs: {
                          lightudq: { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 2,
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        "/": {
                          docs: {},
                          df: 0,
                          c: {
                            docs: {},
                            df: 0,
                            o: {
                              docs: {},
                              df: 0,
                              r: {
                                docs: {},
                                df: 0,
                                r: {
                                  docs: {},
                                  df: 0,
                                  u: {
                                    docs: {},
                                    df: 0,
                                    p: {
                                      docs: {},
                                      df: 0,
                                      t: {
                                        docs: { lightudq: { tf: 1.4142135623730951 } },
                                        df: 1,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                          b: {
                            docs: {},
                            df: 0,
                            a: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                e: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                e: { docs: { lightudq: { tf: 1 } }, df: 1 },
              },
            },
            o: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    i: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 2 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              m: {
                docs: {},
                df: 0,
                e: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
              },
            },
            m: {
              docs: {},
              df: 0,
              i: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  h: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  e: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
              g: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    f: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            n: {
                              docs: {},
                              df: 0,
                              t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                            },
                          },
                        },
                      },
                    },
                  },
                  a: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                              "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                              "lightudq.schemas.FactCompare": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.InconsistentFacts": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.FactCheckOutput": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.MissingQuestions": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.PIIPresence": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.DocumentProfile": {
                                tf: 1.7320508075688772,
                              },
                              "lightudq.schemas.DocumentQualityCheckResult": {
                                tf: 1.7320508075688772,
                              },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                },
              },
              z: { docs: {}, df: 0, e: { docs: { lightudq: { tf: 2 } }, df: 1 } },
              m: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1 },
                          "lightudq.schemas.QnAPairs": { tf: 1 },
                          "lightudq.schemas.FactCompare": { tf: 1 },
                          "lightudq.schemas.InconsistentFacts": { tf: 1 },
                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                          "lightudq.schemas.MissingQuestions": { tf: 1 },
                          "lightudq.schemas.PIIPresence": { tf: 1 },
                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                          "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                        },
                        df: 9,
                      },
                    },
                  },
                },
              },
            },
            t: {
              docs: {},
              df: 0,
              r: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.__init__": {
                    tf: 1.4142135623730951,
                  },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                },
                df: 3,
                a: {
                  docs: {},
                  df: 0,
                  t: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          c: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                          e: {
                            docs: {},
                            df: 0,
                            s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
                i: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                          { tf: 1 },
                      },
                      df: 1,
                    },
                  },
                },
              },
              e: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
              a: {
                docs: {},
                df: 0,
                n: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: { lightudq: { tf: 1 } },
                          df: 1,
                          s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                b: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    },
                  },
                  e: {
                    docs: {},
                    df: 0,
                    s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    m: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              i: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                    },
                    df: 9,
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {
                  lightudq: { tf: 1 },
                  "lightudq.schemas.QnAPair": { tf: 2 },
                  "lightudq.schemas.QnAPairs": { tf: 2 },
                  "lightudq.schemas.FactCompare": { tf: 2 },
                  "lightudq.schemas.InconsistentFacts": { tf: 2 },
                  "lightudq.schemas.FactCheckOutput": { tf: 2 },
                  "lightudq.schemas.MissingQuestions": { tf: 2 },
                  "lightudq.schemas.PIIPresence": { tf: 2 },
                  "lightudq.schemas.DocumentProfile": { tf: 2 },
                  "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                },
                df: 10,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: { docs: {}, df: 0, g: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              p: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    m: {
                      docs: {},
                      df: 0,
                      b: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          r: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                d: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
              r: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        z: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            r: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
                u: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {
                        "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                        "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                        "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                        "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                        "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                          tf: 1,
                        },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
            p: {
              docs: {},
              df: 0,
              e: {
                docs: {},
                df: 0,
                c: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    f: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        c: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            y: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  h: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          z: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              d: {
                                docs: {
                                  "lightudq.schemas.QnAPair": { tf: 1 },
                                  "lightudq.schemas.QnAPairs": { tf: 1 },
                                  "lightudq.schemas.FactCompare": { tf: 1 },
                                  "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                  "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                  "lightudq.schemas.MissingQuestions": { tf: 1 },
                                  "lightudq.schemas.PIIPresence": { tf: 1 },
                                  "lightudq.schemas.DocumentProfile": { tf: 1 },
                                  "lightudq.schemas.DocumentQualityCheckResult": {
                                    tf: 1,
                                  },
                                },
                                df: 9,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            c: {
              docs: {},
              df: 0,
              h: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  m: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                        "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                        "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                        "lightudq.schemas.InconsistentFacts": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                        "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                        "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentQualityCheckResult": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 9,
                      s: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              a: {
                                docs: {},
                                df: 0,
                                l: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    z: {
                                      docs: {},
                                      df: 0,
                                      e: {
                                        docs: {},
                                        df: 0,
                                        r: {
                                          docs: {
                                            "lightudq.schemas.QnAPair": { tf: 1 },
                                            "lightudq.schemas.QnAPairs": { tf: 1 },
                                            "lightudq.schemas.FactCompare": { tf: 1 },
                                            "lightudq.schemas.InconsistentFacts": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.FactCheckOutput": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.MissingQuestions": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.PIIPresence": { tf: 1 },
                                            "lightudq.schemas.DocumentProfile": {
                                              tf: 1,
                                            },
                                            "lightudq.schemas.DocumentQualityCheckResult":
                                              { tf: 1 },
                                          },
                                          df: 9,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                      v: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {},
                              df: 0,
                              d: {
                                docs: {},
                                df: 0,
                                a: {
                                  docs: {},
                                  df: 0,
                                  t: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      r: {
                                        docs: {
                                          "lightudq.schemas.QnAPair": { tf: 1 },
                                          "lightudq.schemas.QnAPairs": { tf: 1 },
                                          "lightudq.schemas.FactCompare": { tf: 1 },
                                          "lightudq.schemas.InconsistentFacts": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                          "lightudq.schemas.MissingQuestions": {
                                            tf: 1,
                                          },
                                          "lightudq.schemas.PIIPresence": { tf: 1 },
                                          "lightudq.schemas.DocumentProfile": { tf: 1 },
                                          "lightudq.schemas.DocumentQualityCheckResult":
                                            { tf: 1 },
                                        },
                                        df: 9,
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          m: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                k: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      w: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                  e: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
                g: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  g: {
                    docs: {},
                    df: 0,
                    e: { docs: {}, df: 0, s: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
              y: {
                docs: {
                  "lightudq.schemas.QnAPair": { tf: 1 },
                  "lightudq.schemas.QnAPairs": { tf: 1 },
                  "lightudq.schemas.FactCompare": { tf: 1 },
                  "lightudq.schemas.InconsistentFacts": { tf: 1 },
                  "lightudq.schemas.FactCheckOutput": { tf: 1 },
                  "lightudq.schemas.MissingQuestions": { tf: 1 },
                  "lightudq.schemas.PIIPresence": { tf: 1 },
                  "lightudq.schemas.DocumentProfile": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                },
                df: 9,
              },
            },
            i: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            s: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      g: {
                        docs: {},
                        df: 0,
                        q: {
                          docs: {},
                          df: 0,
                          u: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              s: {
                                docs: {},
                                df: 0,
                                t: {
                                  docs: {},
                                  df: 0,
                                  i: {
                                    docs: {},
                                    df: 0,
                                    o: {
                                      docs: {},
                                      df: 0,
                                      n: {
                                        docs: {},
                                        df: 0,
                                        s: {
                                          docs: {
                                            "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                                              { tf: 1 },
                                          },
                                          df: 1,
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              n: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          d: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                        },
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: { lightudq: { tf: 1.4142135623730951 } },
                              df: 1,
                            },
                          },
                        },
                        s: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                      },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                a: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        a: {
                          docs: {
                            lightudq: { tf: 1.7320508075688772 },
                            "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                              { tf: 1 },
                            "lightudq.document_quality.DocumentQuality.pii_presence_check":
                              { tf: 1 },
                            "lightudq.schemas.QnAPair": { tf: 2 },
                            "lightudq.schemas.QnAPairs": { tf: 2 },
                            "lightudq.schemas.FactCompare": { tf: 2 },
                            "lightudq.schemas.InconsistentFacts": { tf: 2 },
                            "lightudq.schemas.FactCheckOutput": { tf: 2 },
                            "lightudq.schemas.MissingQuestions": { tf: 2 },
                            "lightudq.schemas.PIIPresence": { tf: 2 },
                            "lightudq.schemas.DocumentProfile": { tf: 2 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                          },
                          df: 12,
                        },
                      },
                    },
                  },
                },
                r: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                          tf: 1,
                        },
                      },
                      df: 1,
                    },
                  },
                },
                h: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    d: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                      },
                      df: 9,
                    },
                  },
                },
              },
              s: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    g: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                            { tf: 1.4142135623730951 },
                        },
                        df: 1,
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              l: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    p: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        e: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            o: {
              docs: {},
              df: 0,
              d: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.__init__": {
                        tf: 1.4142135623730951,
                      },
                      "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.compare": { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                        { tf: 2 },
                      "lightudq.document_quality.DocumentQuality.extract_qna": {
                        tf: 1,
                      },
                      "lightudq.document_quality.DocumentQuality.compute_fact_checks": {
                        tf: 1,
                      },
                      "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                        { tf: 1 },
                      "lightudq.document_quality.DocumentQuality.pii_presence_check": {
                        tf: 1,
                      },
                      "lightudq.document_quality.DocumentQuality.get_document_profile":
                        { tf: 1 },
                      "lightudq.schemas.QnAPair": { tf: 4.123105625617661 },
                      "lightudq.schemas.QnAPair.model_config": { tf: 1 },
                      "lightudq.schemas.QnAPairs": { tf: 4.123105625617661 },
                      "lightudq.schemas.QnAPairs.model_config": { tf: 1 },
                      "lightudq.schemas.FactCompare": { tf: 4.123105625617661 },
                      "lightudq.schemas.FactCompare.model_config": { tf: 1 },
                      "lightudq.schemas.InconsistentFacts": { tf: 4.123105625617661 },
                      "lightudq.schemas.InconsistentFacts.model_config": { tf: 1 },
                      "lightudq.schemas.FactCheckOutput": { tf: 4.123105625617661 },
                      "lightudq.schemas.FactCheckOutput.model_config": { tf: 1 },
                      "lightudq.schemas.MissingQuestions": { tf: 4.123105625617661 },
                      "lightudq.schemas.MissingQuestions.model_config": { tf: 1 },
                      "lightudq.schemas.PIIPresence": { tf: 4.123105625617661 },
                      "lightudq.schemas.PIIPresence.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentProfile": { tf: 4.123105625617661 },
                      "lightudq.schemas.DocumentProfile.model_config": { tf: 1 },
                      "lightudq.schemas.DocumentQualityCheckResult": {
                        tf: 4.123105625617661,
                      },
                      "lightudq.schemas.DocumentQualityCheckResult.model_config": {
                        tf: 1,
                      },
                    },
                    df: 27,
                    s: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.__init__": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.schemas.QnAPair": { tf: 2 },
                        "lightudq.schemas.QnAPairs": { tf: 2 },
                        "lightudq.schemas.FactCompare": { tf: 2 },
                        "lightudq.schemas.InconsistentFacts": { tf: 2 },
                        "lightudq.schemas.FactCheckOutput": { tf: 2 },
                        "lightudq.schemas.MissingQuestions": { tf: 2 },
                        "lightudq.schemas.PIIPresence": { tf: 2 },
                        "lightudq.schemas.DocumentProfile": { tf: 2 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                      },
                      df: 10,
                    },
                  },
                },
                u: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1 },
                        "lightudq.schemas.QnAPairs": { tf: 1 },
                        "lightudq.schemas.FactCompare": { tf: 1 },
                        "lightudq.schemas.InconsistentFacts": { tf: 1 },
                        "lightudq.schemas.FactCheckOutput": { tf: 1 },
                        "lightudq.schemas.MissingQuestions": { tf: 1 },
                        "lightudq.schemas.PIIPresence": { tf: 1 },
                        "lightudq.schemas.DocumentProfile": { tf: 1 },
                        "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
            s: {
              docs: {},
              df: 0,
              g: {
                docs: {
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                },
                df: 1,
              },
            },
          },
          r: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              s: {
                docs: { lightudq: { tf: 2.6457513110645907 } },
                df: 1,
                p: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          b: {
                            docs: {},
                            df: 0,
                            l: {
                              docs: {},
                              df: 0,
                              e: {
                                docs: { lightudq: { tf: 1.4142135623730951 } },
                                df: 1,
                              },
                            },
                          },
                        },
                        e: {
                          docs: {
                            "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                              { tf: 1 },
                          },
                          df: 1,
                        },
                      },
                    },
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {},
                        df: 0,
                        h: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                      },
                    },
                  },
                },
                u: {
                  docs: {},
                  df: 0,
                  l: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      s: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.run": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                        },
                        df: 2,
                      },
                    },
                  },
                },
              },
              v: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      e: { docs: { lightudq: { tf: 3.7416573867739413 } }, df: 1 },
                    },
                  },
                },
              },
              t: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {
                        lightudq: { tf: 1.4142135623730951 },
                        "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                      },
                      df: 2,
                      s: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.compare": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.extract_qna": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.incompleteness_metric":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.pii_presence_check":
                            { tf: 1 },
                          "lightudq.document_quality.DocumentQuality.get_word_count": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                            tf: 1,
                          },
                          "lightudq.document_quality.DocumentQuality.get_document_profile":
                            { tf: 1 },
                        },
                        df: 10,
                      },
                    },
                  },
                },
              },
              a: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  o: {
                    docs: {},
                    df: 0,
                    n: {
                      docs: {},
                      df: 0,
                      i: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          g: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                        },
                      },
                    },
                  },
                },
                d: { docs: { "lightudq.utils.read_document": { tf: 1 } }, df: 1 },
              },
              p: {
                docs: {},
                df: 0,
                o: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    t: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        d: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
                l: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    c: {
                      docs: {},
                      df: 0,
                      e: {
                        docs: {},
                        df: 0,
                        s: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                        d: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
              },
              f: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              lightudq: { tf: 2.23606797749979 },
                              "lightudq.document_quality.DocumentQuality.compare": {
                                tf: 2,
                              },
                            },
                            df: 2,
                            s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              b: {
                docs: {},
                df: 0,
                u: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        i: {
                          docs: {},
                          df: 0,
                          n: {
                            docs: {},
                            df: 0,
                            g: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1 },
                                "lightudq.schemas.QnAPairs": { tf: 1 },
                                "lightudq.schemas.FactCompare": { tf: 1 },
                                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                                "lightudq.schemas.MissingQuestions": { tf: 1 },
                                "lightudq.schemas.PIIPresence": { tf: 1 },
                                "lightudq.schemas.DocumentProfile": { tf: 1 },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              n: {
                docs: {
                  lightudq: { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.run": { tf: 1 },
                },
                df: 2,
              },
            },
            o: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                t: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                    "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                    "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1.7320508075688772 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1.7320508075688772 },
                    "lightudq.schemas.MissingQuestions": { tf: 1.7320508075688772 },
                    "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                    "lightudq.schemas.DocumentProfile": { tf: 1.7320508075688772 },
                    "lightudq.schemas.DocumentQualityCheckResult": {
                      tf: 1.7320508075688772,
                    },
                  },
                  df: 9,
                  m: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      d: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          l: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                            "`": {
                              docs: {},
                              df: 0,
                              "]": {
                                docs: {},
                                df: 0,
                                "[": {
                                  docs: {},
                                  df: 0,
                                  p: {
                                    docs: {},
                                    df: 0,
                                    y: {
                                      docs: {},
                                      df: 0,
                                      d: {
                                        docs: {},
                                        df: 0,
                                        a: {
                                          docs: {},
                                          df: 0,
                                          n: {
                                            docs: {},
                                            df: 0,
                                            t: {
                                              docs: {},
                                              df: 0,
                                              i: {
                                                docs: {},
                                                df: 0,
                                                c: {
                                                  docs: {
                                                    "lightudq.schemas.QnAPair": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.QnAPairs": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.FactCompare": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.InconsistentFacts":
                                                      { tf: 1 },
                                                    "lightudq.schemas.FactCheckOutput":
                                                      { tf: 1 },
                                                    "lightudq.schemas.MissingQuestions":
                                                      { tf: 1 },
                                                    "lightudq.schemas.PIIPresence": {
                                                      tf: 1,
                                                    },
                                                    "lightudq.schemas.DocumentProfile":
                                                      { tf: 1 },
                                                    "lightudq.schemas.DocumentQualityCheckResult":
                                                      { tf: 1 },
                                                  },
                                                  df: 9,
                                                },
                                              },
                                            },
                                          },
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          w: {
            docs: {},
            df: 0,
            o: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                d: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_word_count": {
                      tf: 1,
                    },
                  },
                  df: 1,
                  c: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      u: {
                        docs: {},
                        df: 0,
                        n: {
                          docs: {},
                          df: 0,
                          t: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                  },
                  s: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_word_count": {
                        tf: 1,
                      },
                    },
                    df: 1,
                  },
                },
              },
            },
            h: {
              docs: {},
              df: 0,
              a: {
                docs: {},
                df: 0,
                t: { docs: { lightudq: { tf: 2.23606797749979 } }, df: 1 },
              },
              o: { docs: { lightudq: { tf: 1 } }, df: 1 },
              i: {
                docs: {},
                df: 0,
                l: {
                  docs: {},
                  df: 0,
                  e: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                },
              },
              e: {
                docs: {},
                df: 0,
                t: {
                  docs: {},
                  df: 0,
                  h: {
                    docs: {},
                    df: 0,
                    e: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {
                          "lightudq.document_quality.DocumentQuality.compute_fact_checks":
                            { tf: 1 },
                          "lightudq.schemas.QnAPair": { tf: 1.7320508075688772 },
                          "lightudq.schemas.QnAPairs": { tf: 1.7320508075688772 },
                          "lightudq.schemas.FactCompare": { tf: 1.7320508075688772 },
                          "lightudq.schemas.InconsistentFacts": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.FactCheckOutput": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.MissingQuestions": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.PIIPresence": { tf: 1.7320508075688772 },
                          "lightudq.schemas.DocumentProfile": {
                            tf: 1.7320508075688772,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult": {
                            tf: 1.7320508075688772,
                          },
                        },
                        df: 10,
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                h: { docs: { lightudq: { tf: 3.4641016151377544 } }, df: 1 },
              },
            },
          },
          k: {
            docs: {},
            df: 0,
            n: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: { lightudq: { tf: 1.4142135623730951 } },
                    df: 1,
                    m: {
                      docs: {},
                      df: 0,
                      o: {
                        docs: {},
                        df: 0,
                        d: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {},
                            df: 0,
                            l: {
                              docs: {},
                              df: 0,
                              n: {
                                docs: {},
                                df: 0,
                                a: {
                                  docs: {},
                                  df: 0,
                                  m: {
                                    docs: {},
                                    df: 0,
                                    e: {
                                      docs: {
                                        "lightudq.document_quality.DocumentQuality.__init__":
                                          { tf: 1 },
                                      },
                                      df: 1,
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              e: { docs: {}, df: 0, p: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
          },
          h: {
            docs: {},
            df: 0,
            e: {
              docs: { lightudq: { tf: 1 } },
              df: 1,
              a: {
                docs: {},
                df: 0,
                d: {
                  docs: {},
                  df: 0,
                  q: {
                    docs: {},
                    df: 0,
                    u: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        r: {
                          docs: {},
                          df: 0,
                          t: {
                            docs: {},
                            df: 0,
                            e: {
                              docs: {},
                              df: 0,
                              r: {
                                docs: {},
                                df: 0,
                                e: {
                                  docs: {},
                                  df: 0,
                                  d: {
                                    docs: { lightudq: { tf: 1.7320508075688772 } },
                                    df: 1,
                                  },
                                },
                                s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              s: {
                docs: {
                  lightudq: { tf: 1.7320508075688772 },
                  "lightudq.schemas.QnAPair": { tf: 1 },
                  "lightudq.schemas.QnAPairs": { tf: 1 },
                  "lightudq.schemas.FactCompare": { tf: 1 },
                  "lightudq.schemas.InconsistentFacts": { tf: 1 },
                  "lightudq.schemas.FactCheckOutput": { tf: 1 },
                  "lightudq.schemas.MissingQuestions": { tf: 1 },
                  "lightudq.schemas.PIIPresence": { tf: 1 },
                  "lightudq.schemas.DocumentProfile": { tf: 1 },
                  "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                },
                df: 10,
              },
              v: { docs: {}, df: 0, e: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
            i: {
              docs: {},
              df: 0,
              s: { docs: { lightudq: { tf: 1 } }, df: 1 },
              g: {
                docs: {},
                df: 0,
                h: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
              },
            },
            o: { docs: {}, df: 0, w: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            t: {
              docs: {},
              df: 0,
              t: {
                docs: {},
                df: 0,
                p: {
                  docs: {},
                  df: 0,
                  s: {
                    docs: {},
                    df: 0,
                    ":": {
                      docs: {},
                      df: 0,
                      "/": {
                        docs: {},
                        df: 0,
                        "/": {
                          docs: {},
                          df: 0,
                          a: {
                            docs: {},
                            df: 0,
                            i: {
                              docs: {
                                "lightudq.document_quality.DocumentQuality.__init__": {
                                  tf: 1,
                                },
                              },
                              df: 1,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          v: {
            1: {
              docs: {
                "lightudq.schemas.QnAPair": { tf: 1 },
                "lightudq.schemas.QnAPairs": { tf: 1 },
                "lightudq.schemas.FactCompare": { tf: 1 },
                "lightudq.schemas.InconsistentFacts": { tf: 1 },
                "lightudq.schemas.FactCheckOutput": { tf: 1 },
                "lightudq.schemas.MissingQuestions": { tf: 1 },
                "lightudq.schemas.PIIPresence": { tf: 1 },
                "lightudq.schemas.DocumentProfile": { tf: 1 },
                "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
              },
              df: 9,
            },
            docs: {},
            df: 0,
            i: {
              docs: {},
              df: 0,
              b: {
                docs: {},
                df: 0,
                r: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    n: { docs: {}, df: 0, t: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                  },
                },
              },
            },
            s: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
            e: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                s: {
                  docs: {},
                  df: 0,
                  i: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      n: {
                        docs: {},
                        df: 0,
                        s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                      },
                    },
                  },
                },
              },
            },
            a: {
              docs: {},
              df: 0,
              r: {
                docs: {},
                df: 0,
                s: {
                  docs: {
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 9,
                },
                i: {
                  docs: {},
                  df: 0,
                  a: {
                    docs: {},
                    df: 0,
                    b: {
                      docs: {},
                      df: 0,
                      l: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                },
              },
              l: {
                docs: {},
                df: 0,
                i: {
                  docs: {},
                  df: 0,
                  d: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        o: {
                          docs: {},
                          df: 0,
                          r: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1 },
                              "lightudq.schemas.QnAPairs": { tf: 1 },
                              "lightudq.schemas.FactCompare": { tf: 1 },
                              "lightudq.schemas.InconsistentFacts": { tf: 1 },
                              "lightudq.schemas.FactCheckOutput": { tf: 1 },
                              "lightudq.schemas.MissingQuestions": { tf: 1 },
                              "lightudq.schemas.PIIPresence": { tf: 1 },
                              "lightudq.schemas.DocumentProfile": { tf: 1 },
                              "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                            },
                            df: 9,
                            s: {
                              docs: {
                                "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                                "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                                "lightudq.schemas.FactCompare": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.InconsistentFacts": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.FactCheckOutput": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.MissingQuestions": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.PIIPresence": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentProfile": {
                                  tf: 1.4142135623730951,
                                },
                                "lightudq.schemas.DocumentQualityCheckResult": {
                                  tf: 1.4142135623730951,
                                },
                              },
                              df: 9,
                            },
                          },
                        },
                        e: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
                u: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    s: {
                      docs: {
                        "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                        "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                        "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                        "lightudq.schemas.InconsistentFacts": {
                          tf: 1.4142135623730951,
                        },
                        "lightudq.schemas.FactCheckOutput": { tf: 1.4142135623730951 },
                        "lightudq.schemas.MissingQuestions": { tf: 1.4142135623730951 },
                        "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentProfile": { tf: 1.4142135623730951 },
                        "lightudq.schemas.DocumentQualityCheckResult": {
                          tf: 1.4142135623730951,
                        },
                      },
                      df: 9,
                    },
                  },
                },
              },
            },
          },
          j: {
            docs: {},
            df: 0,
            a: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  s: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
                },
              },
            },
          },
          n: {
            docs: {},
            df: 0,
            o: {
              docs: { lightudq: { tf: 1 } },
              df: 1,
              t: {
                docs: {
                  lightudq: { tf: 1.4142135623730951 },
                  "lightudq.document_quality.DocumentQuality.incompleteness_metric": {
                    tf: 1.4142135623730951,
                  },
                },
                df: 2,
                a: {
                  docs: {},
                  df: 0,
                  b: {
                    docs: {},
                    df: 0,
                    l: {
                      docs: {},
                      df: 0,
                      e: { docs: { lightudq: { tf: 1.4142135623730951 } }, df: 1 },
                    },
                  },
                },
                e: {
                  docs: {},
                  df: 0,
                  w: {
                    docs: {},
                    df: 0,
                    o: {
                      docs: {},
                      df: 0,
                      r: {
                        docs: {},
                        df: 0,
                        t: {
                          docs: {},
                          df: 0,
                          h: {
                            docs: {},
                            df: 0,
                            y: { docs: { lightudq: { tf: 1 } }, df: 1 },
                          },
                        },
                      },
                    },
                  },
                },
              },
              n: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                      tf: 1,
                    },
                  },
                  df: 1,
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              w: { docs: { lightudq: { tf: 2 } }, df: 1 },
              t: { docs: { lightudq: { tf: 1.7320508075688772 } }, df: 1 },
            },
            a: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                e: {
                  docs: {
                    lightudq: { tf: 1 },
                    "lightudq.document_quality.DocumentQuality.__init__": {
                      tf: 1.4142135623730951,
                    },
                    "lightudq.schemas.QnAPair": { tf: 1 },
                    "lightudq.schemas.QnAPairs": { tf: 1 },
                    "lightudq.schemas.FactCompare": { tf: 1 },
                    "lightudq.schemas.InconsistentFacts": { tf: 1 },
                    "lightudq.schemas.FactCheckOutput": { tf: 1 },
                    "lightudq.schemas.MissingQuestions": { tf: 1 },
                    "lightudq.schemas.PIIPresence": { tf: 1 },
                    "lightudq.schemas.DocumentProfile": { tf: 1 },
                    "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                  },
                  df: 11,
                  s: {
                    docs: {
                      "lightudq.schemas.QnAPair": { tf: 2 },
                      "lightudq.schemas.QnAPairs": { tf: 2 },
                      "lightudq.schemas.FactCompare": { tf: 2 },
                      "lightudq.schemas.InconsistentFacts": { tf: 2 },
                      "lightudq.schemas.FactCheckOutput": { tf: 2 },
                      "lightudq.schemas.MissingQuestions": { tf: 2 },
                      "lightudq.schemas.PIIPresence": { tf: 2 },
                      "lightudq.schemas.DocumentProfile": { tf: 2 },
                      "lightudq.schemas.DocumentQualityCheckResult": { tf: 2 },
                    },
                    df: 9,
                    p: {
                      docs: {},
                      df: 0,
                      a: {
                        docs: {},
                        df: 0,
                        c: {
                          docs: {},
                          df: 0,
                          e: {
                            docs: {
                              "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                              "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                              "lightudq.schemas.FactCompare": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.InconsistentFacts": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.FactCheckOutput": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.MissingQuestions": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.PIIPresence": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.DocumentProfile": {
                                tf: 1.4142135623730951,
                              },
                              "lightudq.schemas.DocumentQualityCheckResult": {
                                tf: 1.4142135623730951,
                              },
                            },
                            df: 9,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            u: {
              docs: {},
              df: 0,
              m: {
                docs: {},
                df: 0,
                b: {
                  docs: {},
                  df: 0,
                  e: {
                    docs: {},
                    df: 0,
                    r: {
                      docs: {
                        "lightudq.document_quality.DocumentQuality.get_word_count": {
                          tf: 1,
                        },
                      },
                      df: 1,
                      s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                    },
                  },
                },
              },
            },
          },
          g: {
            docs: {},
            df: 0,
            r: {
              docs: {},
              df: 0,
              o: {
                docs: {},
                df: 0,
                w: {
                  docs: {},
                  df: 0,
                  t: { docs: {}, df: 0, h: { docs: { lightudq: { tf: 1 } }, df: 1 } },
                },
              },
            },
            e: {
              docs: {},
              df: 0,
              t: {
                docs: {
                  lightudq: { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_response_from_llm": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_word_count": { tf: 1 },
                  "lightudq.document_quality.DocumentQuality.get_doc_summary": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_custom_metric": {
                    tf: 1,
                  },
                  "lightudq.document_quality.DocumentQuality.get_document_profile": {
                    tf: 1,
                  },
                },
                df: 6,
              },
              n: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  r: {
                    docs: {},
                    df: 0,
                    a: {
                      docs: {},
                      df: 0,
                      t: {
                        docs: {},
                        df: 0,
                        e: {
                          docs: {},
                          df: 0,
                          s: { docs: { lightudq: { tf: 1 } }, df: 1 },
                        },
                      },
                    },
                    i: {
                      docs: {},
                      df: 0,
                      c: {
                        docs: {
                          "lightudq.schemas.QnAPair": { tf: 1.4142135623730951 },
                          "lightudq.schemas.QnAPairs": { tf: 1.4142135623730951 },
                          "lightudq.schemas.FactCompare": { tf: 1.4142135623730951 },
                          "lightudq.schemas.InconsistentFacts": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.FactCheckOutput": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.MissingQuestions": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.PIIPresence": { tf: 1.4142135623730951 },
                          "lightudq.schemas.DocumentProfile": {
                            tf: 1.4142135623730951,
                          },
                          "lightudq.schemas.DocumentQualityCheckResult": {
                            tf: 1.4142135623730951,
                          },
                        },
                        df: 9,
                        s: {
                          docs: {
                            "lightudq.schemas.QnAPair": { tf: 1 },
                            "lightudq.schemas.QnAPairs": { tf: 1 },
                            "lightudq.schemas.FactCompare": { tf: 1 },
                            "lightudq.schemas.InconsistentFacts": { tf: 1 },
                            "lightudq.schemas.FactCheckOutput": { tf: 1 },
                            "lightudq.schemas.MissingQuestions": { tf: 1 },
                            "lightudq.schemas.PIIPresence": { tf: 1 },
                            "lightudq.schemas.DocumentProfile": { tf: 1 },
                            "lightudq.schemas.DocumentQualityCheckResult": { tf: 1 },
                          },
                          df: 9,
                        },
                      },
                    },
                  },
                },
              },
            },
            i: {
              docs: {},
              df: 0,
              v: {
                docs: {},
                df: 0,
                e: {
                  docs: {},
                  df: 0,
                  n: {
                    docs: {
                      "lightudq.document_quality.DocumentQuality.get_response_from_llm":
                        { tf: 1 },
                    },
                    df: 1,
                  },
                },
              },
            },
          },
          y: {
            docs: {},
            df: 0,
            e: {
              docs: {},
              df: 0,
              a: { docs: {}, df: 0, r: { docs: { lightudq: { tf: 1 } }, df: 1 } },
            },
          },
        },
      },
    },
    pipeline: ["trimmer"],
    _isPrebuiltIndex: true,
  };

  // mirrored in build-search-index.js (part 1)
  // Also split on html tags. this is a cheap heuristic, but good enough.
  elasticlunr.tokenizer.setSeperator(/[\s\-.;&_'"=,()]+|<[^>]*>/);

  let searchIndex;
  if (docs._isPrebuiltIndex) {
    console.info("using precompiled search index");
    searchIndex = elasticlunr.Index.load(docs);
  } else {
    console.time("building search index");
    // mirrored in build-search-index.js (part 2)
    searchIndex = elasticlunr(function () {
      this.pipeline.remove(elasticlunr.stemmer);
      this.pipeline.remove(elasticlunr.stopWordFilter);
      this.addField("qualname");
      this.addField("fullname");
      this.addField("annotation");
      this.addField("default_value");
      this.addField("signature");
      this.addField("bases");
      this.addField("doc");
      this.setRef("fullname");
    });
    for (let doc of docs) {
      searchIndex.addDoc(doc);
    }
    console.timeEnd("building search index");
  }

  return (term) =>
    searchIndex.search(term, {
      fields: {
        qualname: { boost: 4 },
        fullname: { boost: 2 },
        annotation: { boost: 2 },
        default_value: { boost: 2 },
        signature: { boost: 2 },
        bases: { boost: 2 },
        doc: { boost: 1 },
      },
      expand: true,
    });
})();
